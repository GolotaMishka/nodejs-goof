# Froomle Recommendation Platform

## Deployment

Application is deployed on Google Cloud Platform (GCP) using service account. This service account has the necessary privileges to push docker images to eu.gcr.io/froomle-demo-1 and deploy managed cloud run services. Here is a list of cloud run services:

| SERVICE           |                        URL                        |       REGION |
| ----------------- | :-----------------------------------------------: | -----------: |
| recopo-production | https://recopo-production-wwqcmrdpmq-ew.a.run.app | europe-west1 |
| recopo-staging    |  https://recopo-staging-wwqcmrdpmq-ew.a.run.app   | europe-west1 |
| recopo-storybook  | https://recopo-storybook-wwqcmrdpmq-ew.a.run.app  | europe-west1 |
| hello             |       https://hello-wwqcmrdpmq-ew.a.run.app       | europe-west1 |

There are 2 docker files called **Dockerfile.app** and **Dockerfile.storybook**. Both storybook and app are built as a static web-app to folders called _storybook-dist_ and _dist_ respectively.

You should have _panenco-service-account.json_ with credentials. To push a docker image manually follow these steps:

1. Activate service-account

```
gcloud auth activate-service-account --key-file=panenco-service-account.json
```

2. Configure project

```
gcloud config configurations create froomle-demo-1
gcloud config set project froomle-demo-1
gcloud config set compute/zone europe-west1-d
gcloud config set compute/region europe-west1
gcloud config set account panenco@froomle-demo-1.iam.gserviceaccount.com
```

3. Configure docker credentials helper

```
gcloud auth configure-docker
```

4. Build docker image(s)

```
docker build -f Dockerfile.app -t app-image .
docker build -f Dockerfile.storybook -t storybook-image .
```

5. Tag and push docker image(s)

```
docker tag app-image:latest eu.gcr.io/froomle-demo-1/{SERVICE_NAME}:latest
```

6. Run deploy exposing port 80

```
gcloud run deploy hello --port 80 --image eu.gcr.io/froomle-demo-1/{SERVICE_NAME} --platform managed --region europe-west1
```
