declare module "*.scss";
declare module "*.svg";
declare module "*.md";
declare module "*.png";
declare module "*.jpg";
declare module "*.json";
