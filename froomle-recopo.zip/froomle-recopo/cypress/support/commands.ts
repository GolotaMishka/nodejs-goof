import { idGenerator } from "app/utils/helpers";
import { PersonaEntity } from "data/utils/types";
import { setAuthStorage } from "data/utils";
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-namespace */
declare global {
  namespace Cypress {
    interface Chainable {
      login: () => void;
      getCy: (selector: string) => Cypress.Chainable;
      createPersona: (
        alias: string,
        companyId?: string,
        envId?: string | number
      ) => Cypress.Chainable<PersonaEntity>;
      removePersona: (
        id: string | number,
        companyId?: string,
        envId?: string | number
      ) => void;
      getAuthToken: () => Cypress.Chainable;
    }
  }
}

const email: string = Cypress.env("AUTH0_TEST_USER");
const password: string = Cypress.env("AUTH0_TEST_PASSWORD");

const onboardingApiUrl = `${Cypress.env("ONBOARDING_API_BASE_URL")}`;

const getAuthorizationHeader = (token: string) => `Bearer ${token}`;

const createApiUrl = (str: string): string => Cypress.env("API_BASE_URL") + str;

export const getLocalStorageAuthKey = (): string => `auth`;

Cypress.Commands.add("login", () => {
  return cy
    .request({
      method: "POST",
      url: `${onboardingApiUrl}/authentication/login`,
      body: {
        email,
        password,
      },
    })
    .then((resp) => {
      const { body, headers } = resp;

      setAuthStorage(
        headers["x-id-token"],
        headers["x-access-token"],
        headers["x-refresh-token"],
        body
      );
    });
});

Cypress.Commands.add("getCy", (selector: string) =>
  cy.get(`[data-cy=${selector}]`)
);

Cypress.Commands.add("getAuthToken", () => {
  cy.window().then((win) => {
    const auth = win.localStorage.getItem(getLocalStorageAuthKey());

    const { accessToken } = JSON.parse(auth as string);

    return cy.wrap(accessToken);
  });
});

Cypress.Commands.add(
  "createPersona",
  (
    alias: string,
    projectId: string | number = 1,
    envId: string | number = 1
  ) => {
    cy.getAuthToken().then((token) => {
      cy.request({
        method: "POST",
        url: createApiUrl(
          `/projects/${projectId}/environments/${envId}/personas`
        ),
        body: {
          name: idGenerator(),
          role: idGenerator(),
          version_id: 7,
        },
        headers: {
          authorization: getAuthorizationHeader(token),
        },
      }).then((resp) => {
        return cy.wrap(resp.body).as(alias);
      });
    });
  }
);

Cypress.Commands.add(
  "removePersona",
  (
    id: string | number,
    projectId: string | number = 1,
    envId: string | number = 1
  ) => {
    cy.getAuthToken().then((token) => {
      return cy.request({
        method: "DELETE",
        url: createApiUrl(
          `/projects/${projectId}/environments/${envId}/personas/${id}`
        ),
        headers: {
          authorization: getAuthorizationHeader(token),
        },
      });
    });
  }
);
