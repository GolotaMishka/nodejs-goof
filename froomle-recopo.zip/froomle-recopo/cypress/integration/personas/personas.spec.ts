import { idGenerator } from "app/utils/helpers";
import { PersonaEntity } from "data/utils/types";
import { personasPath } from "app/constants/url";

describe("/personas", () => {
  beforeEach(() => {
    cy.login();
    cy.createPersona("testPersona");
  });

  afterEach(() => {
    cy.get<PersonaEntity>("@testPersona").then((persona) => {
      cy.removePersona(persona.id);
    });
  });

  it("allows to create and remove persona", () => {
    const body: Partial<PersonaEntity> = {
      name: idGenerator(),
      role: "Test role",
    };
    cy.intercept("GET", "**/personas").as("getPersonas");
    cy.intercept("DELETE", "**/personas/**").as("removePersona");
    cy.intercept("POST", "**/personas").as("createPersona");

    cy.visit(personasPath(1, 1));

    cy.wait("@getPersonas").then(({ response }) => {
      expect(response?.statusCode).to.equal(200);
    });

    cy.getCy("add-persona").click();

    cy.get("input[name=name]").type(body.name as string);
    cy.get("input[name=role]").type(body.role as string);
    cy.getCy("version-select").type("{enter}{enter}");

    cy.wait("@createPersona").then(({ response }) => {
      expect(response?.body.name).to.equal(body.name);
      expect(response?.body.role).to.equal(body.role);
      expect(response?.body.items).to.have.length(0);
      expect(response?.statusCode).to.equal(201);
      cy.wrap(response?.body.id).as("personaId");
    });

    cy.getCy("cancel-history").click();

    cy.get<string>("@personaId").then((personaId) => {
      cy.getCy(`remove-persona-${personaId}`).click();
      cy.getCy("confirm-modal").click();

      cy.wait("@removePersona").then(({ response, request }) => {
        expect(request.url).to.include(personaId);
        expect(response?.statusCode).to.equal(200);
      });
    });
  });

  it("allows to edit persona", () => {
    cy.intercept("PUT", "**/personas/**").as("updatePersona");
    cy.intercept("GET", "**/personas").as("getPersonas");

    cy.visit(personasPath(1, 1));

    cy.wait("@getPersonas").then(({ response }) => {
      expect(response?.statusCode).to.equal(200);
    });

    cy.get<PersonaEntity>("@testPersona").then((persona) => {
      cy.getCy(`enable-persona-${persona.id}`).click();
      cy.wait("@updatePersona").then(({ response, request }) => {
        expect(request.body.is_enabled).to.equal(false);
        expect(response?.statusCode).to.equal(200);
      });

      cy.getCy(`enable-persona-${persona.id}`).click();
      cy.wait("@updatePersona").then(({ response, request }) => {
        expect(request.body.is_enabled).to.equal(true);
        expect(response?.statusCode).to.equal(200);
      });

      const newPersona: Partial<PersonaEntity> = {
        name: "Test_name",
        role: "Test_role",
      };

      cy.getCy(`edit-persona-${persona.id}`).click();
      cy.get("input[name=name]")
        .clear()
        .type(newPersona.name as string);
      cy.get("input[name=role]")
        .clear()
        .type(newPersona.role as string);
      cy.get("button[type=submit]").click();

      cy.wait("@updatePersona").then(({ response }) => {
        expect(response?.body.name).to.equal(newPersona.name);
        expect(response?.body.role).to.equal(newPersona.role);
        expect(response?.body.id).to.equal(persona.id);
      });
    });
  });

  it("allows to clone and remove persona", () => {
    cy.intercept("DELETE", "**/personas/**").as("removePersona");
    cy.intercept("POST", "**/personas").as("createPersona");
    cy.intercept("GET", "**/personas").as("getPersonas");

    cy.visit(personasPath(1, 1));

    cy.wait("@getPersonas").then(({ response }) => {
      expect(response?.statusCode).to.equal(200);
    });

    cy.get<PersonaEntity>("@testPersona").then((persona) => {
      cy.getCy(`clone-persona-${persona.id}`).click();
      cy.wait("@createPersona").then(({ response }) => {
        expect(response?.body.id).to.not.equal(persona.id);
        expect(response?.body.role).to.equal(persona.role);
        expect(response?.statusCode).to.equal(201);
        cy.wrap(response?.body.id).as("createdPersonaId");
      });

      cy.get<PersonaEntity>("@createdPersonaId").then((id) => {
        cy.getCy(`remove-persona-${id}`).click();
        cy.getCy("confirm-modal").click();

        cy.wait("@removePersona").then(({ request }) => {
          expect(request.url).to.include(id);
        });
      });
    });
  });

  it("allows to manage persona history", () => {
    cy.intercept("PUT", "**/personas/**").as("updatePersona");
    cy.intercept("GET", "personas").as("getPersonas");
    cy.intercept("search-items").as("searchItems");
    cy.visit(personasPath(1, 1));

    cy.get<PersonaEntity>("@testPersona").then((persona) => {
      cy.getCy(`manage-history-${persona.id}`).click();
      const search = "ase";
      cy.getCy("history-select-input").type(search);
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(300);
      cy.wait("@searchItems").then(({ request, response }) => {
        expect(request.url).to.contain("order_by_popularity=true");
        expect(response?.body).to.have.length(10);
      });

      cy.getCy("history-select-option-0").click();
      cy.getCy("history-select-option-1").click();
      cy.getCy("history-select-option-2").click();

      cy.getCy("history-select-submit").click();

      cy.getCy("history-select-input").type(search);
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(300);
      cy.wait("@searchItems").then(({ request, response }) => {
        expect(request.url).to.contain("order_by_popularity=true");
        expect(response?.body).to.have.length(10);
      });

      cy.getCy("history-select-option-0").click();
      cy.getCy("history-select-option-1").click();
      cy.getCy("history-select-option-2").click();

      cy.getCy("history-select-submit").click();

      cy.getCy("history-item").should("have.length", 3);

      cy.getCy("remove-history-item").first().click();

      cy.getCy("history-item").should("have.length", 2);

      cy.getCy("save-history").click();

      cy.wait(["@updatePersona", "@getPersonas"]).spread(({ request }) => {
        expect(request.body.items).to.have.length(2);
      });
    });
  });
});
