import { TemplateEntity } from "data/utils/types";
import { templatesPath, recommendationsPath } from "app/constants/url";

describe("/templates", () => {
  beforeEach(() => {
    cy.login();
  });

  it("allows to select template", () => {
    cy.intercept(/(?=.*api)(?=.*templates)/).as("getTemplates");
    cy.visit(templatesPath(1, 1));
    cy.wait("@getTemplates").then(({ response }) => {
      expect(response?.statusCode).to.equal(200);
      cy.wrap(response?.body[0]).as("firstTemplate");
    });
    cy.getCy("next-button")
      .as("nextButton")
      .should((button) => {
        const classes = Cypress.$(button).attr("class");

        expect(classes).to.contain("disabled");
      });
    cy.getCy("template-selected").should("not.exist");

    cy.getCy("template").first().click();
    cy.getCy("template-selected").should("be.visible");

    cy.get("@nextButton").should("not.be.disabled").click();

    cy.get<TemplateEntity>("@firstTemplate").then((selectedTemplate) => {
      cy.url().should(
        "contain",
        recommendationsPath(1, 1, selectedTemplate.id)
      );
    });
  });
});
