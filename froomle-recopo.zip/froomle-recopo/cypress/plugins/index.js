/* eslint-disable global-require */
/* eslint-disable @typescript-eslint/no-var-requires */
const paths = require("../../config/paths");

module.exports = (_, config) => {
  const configWithDotenv = require("dotenv").config({ path: paths.env });
  if (configWithDotenv.error) {
    throw configWithDotenv.error;
  }

  const env = { ...config.env, ...configWithDotenv.parsed };
  const result = { ...config, env };
  return result;
};
