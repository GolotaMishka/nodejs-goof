import createStore from "data/store";
import { EnvEntity, TemplateEntity } from "data/utils/types";

type State = {
  env: EnvEntity | null;
  template: TemplateEntity | null;
};

const initialState: State = {
  env: null,
  template: null,
};

export const useStore = createStore(
  initialState,
  (set) => ({
    setEnv: (env: EnvEntity) =>
      set((draft) => {
        draft.env = env;
      }),
    setTemplate: (template: TemplateEntity | null) =>
      set((draft) => {
        draft.template = template;
      }),
  }),
  "state"
);
