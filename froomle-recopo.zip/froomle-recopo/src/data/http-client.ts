/* eslint-disable camelcase */
import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from "axios";
import { camelizeKeys, decamelizeKeys } from "humps";
import { StoreApi } from "zustand";
import * as jwt from "jsonwebtoken";

import type { ApiExtraConfig, NotificationStore } from "./utils/types";
import { refresh } from "./api";
import { getAuthStorage, setAuthStorage } from "./utils";

class HttpClient {
  private readonly axios: AxiosInstance;

  private readonly store: StoreApi<NotificationStore>;

  private readonly extraConfig?: ApiExtraConfig;

  public constructor(
    config: AxiosRequestConfig,
    store: StoreApi<NotificationStore>,
    extraConfig?: ApiExtraConfig
  ) {
    this.axios = axios.create(config);
    this.store = store;
    this.extraConfig = extraConfig;
    this.axios.interceptors.response.use(
      this.successInterceptor,
      this.errorInterceptor
    );

    this.axios.interceptors.request.use(this.requestInterceptor);
  }

  private requestInterceptor = (config: AxiosRequestConfig) => {
    const newConfig = { ...config };
    if (newConfig.headers["Content-Type"] === "multipart/form-data")
      return newConfig;

    if (this.extraConfig?.snakeCase) {
      if (config.params) {
        newConfig.params = decamelizeKeys(config.params);
      }
      if (config.data) {
        newConfig.data = decamelizeKeys(config.data);
      }
    }

    const auth = getAuthStorage();
    if (auth) {
      const { accessToken, refreshToken } = auth;
      if (refreshToken) {
        const exp = accessToken && (jwt.decode(accessToken)?.exp as number);
        const tokenHasExpired = accessToken
          ? new Date().getTime() / 1000 > Number(exp) - 5
          : true;

        if (tokenHasExpired) {
          if (!this.isRefreshUrl(config.url)) {
            if (!this.store.getState().isRefreshing) {
              const { companyId } = auth;
              refresh(refreshToken, companyId);
              this.store.setState({ isRefreshing: true });
            }
            return {
              ...config,
              cancelToken: new axios.CancelToken((cancel) =>
                cancel("Cancel request")
              ),
            };
          }
        } else {
          newConfig.headers.common["x-auth"] = `${accessToken}`;
          newConfig.headers.common.Authorization = `Bearer ${accessToken}`;
        }
      } else if (
        !this.isAuthUrl(config.url) &&
        !this.isRefreshUrl(config.url)
      ) {
        localStorage.clear();
        window.location.reload();
      }
    }

    return newConfig;
  };

  private successInterceptor = (res: AxiosResponse) => {
    let { data } = res;
    const { request } = res;
    if (
      this.extraConfig?.snakeCase &&
      data &&
      res.headers["content-type"] === "application/json"
    ) {
      data = camelizeKeys(res.data);
    }

    if (this.isAuthUrl(request.responseURL)) {
      setAuthStorage(
        res.headers["x-id-token"],
        res.headers["x-access-token"],
        res.headers["x-refresh-token"],
        data
      );
    }

    return data;
  };

  private errorInterceptor = (error): void => {
    if (error?.response?.data) {
      this.store.setState({ error: error.response.data });
    } else if (error?.message !== "Cancel request") {
      this.store.setState({
        error: {
          message: "Connection error",
        },
      });
      throw new Error("No connection");
    }

    throw error;
  };

  setAuthorizationHeader = (authToken: string): void => {
    this.axios.defaults.headers.common.Authorization = `Bearer ${authToken}`;
    this.axios.defaults.headers.common["x-auth"] = `${authToken}`;
  };

  removeAuthorizationHeader = (): void => {
    delete this.axios.defaults.headers.common.Authorization;
  };

  isAuthUrl = (url?: string): boolean => {
    return new RegExp(
      /\/authentication\/login|\/authentication\/register|\/authentication\/refresh|\/invites\/.*\/register/
    ).test(url || "");
  };

  isRefreshUrl = (url?: string): boolean => {
    return new RegExp(/\/authentication\/refresh/).test(url || "");
  };

  get = (...args) => this.axios.get.apply(this, args);

  post = (...args) => this.axios.post.apply(this, args);

  patch = (...args) => this.axios.patch.apply(this, args);

  put = (...args) => this.axios.put.apply(this, args);

  delete = (...args) => this.axios.delete.apply(this, args);
}

export default HttpClient;
