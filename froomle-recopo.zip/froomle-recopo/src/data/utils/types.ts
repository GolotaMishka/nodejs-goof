/* eslint-disable no-use-before-define */
import {
  BenchMarkType,
  CompanyInviteStatus,
  CompanyInviteType,
  CompanyStatus,
  CreationStep,
  EventIntegrationType,
  Industry,
  IntegrationLocation,
  ItemIntegrationType,
  PageType,
  PlanType,
  RecommendationIntegrationType,
  RoleType,
} from "./enums";

export type AppLanguage = "nl" | "fr";

export type EnvEntity = { name: string; id: string; language?: AppLanguage };

export type TimeStampEntity = { createdAt: Date; updatedAt: Date };

export type UserEntity = {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  companyName?: string;
  phone?: string;
  role?: RoleType;
  linked?: string;
} & TimeStampEntity;

export type VersionEntity = {
  id: string;
  description: string;
  name: string;
};

export type Environment = {
  id: string;
  name: string;
  displayName: string;
  project: string;
} & TimeStampEntity;

export type Member = {
  name: string;
  picture: string;
};
export type OnboardingEnvironment = {
  id: string;
  name: string;
  displayName: string;
  project: string;
  recopoId: string;
};
export type CompanyEntity = {
  id: string;
  name: string;
  logo?: string;
  status: CompanyStatus;
  environments?: OnboardingEnvironment[];
  members?: Member[];
  isDemo?: boolean;
  recopoProjectId: string;
  invitedEmails?: string[];
} & TimeStampEntity;

export type CompanyInviteEntity = {
  id: string;
  email: string;
  answeredAt?: string;
  type?: CompanyInviteType;
  status: CompanyInviteStatus;
  createdBy?: UserEntity;
  company?: CompanyEntity;
  roles?: RoleEntity;
  step?: CreationStep;
  existingUser?: boolean;
};

// is it needed anymore?
export type ItemEntity = {
  title: string;
  id: string;
  titleMap: {
    [key in AppLanguage]?: string;
  };
  images: string[] | null;
  clientItemId: string;
  froomleItemId: number;
  categories: string[];
  uri: string;
  uriMap: {
    [key in AppLanguage]?: string;
  };
};

export type ExtendedItemEntity = ItemEntity & { isInPersonaHistory: boolean };

export type HistoryItemEntity = {
  itemId?: string;
  isEnabled?: boolean;
  personaId?: string;
  item: ItemEntity;
  secondsAgo: number;
};

export type PersonaEntity = {
  id: string;
  avatar?: string;
  isEnabled: boolean;
  name: string;
  rank: number;
  role: string;
  version?: VersionEntity;
  environmentId?: string;
  versionId?: string;
  items: HistoryItemEntity[];
  isNew?: boolean;
};

export type RecommendationListItem = {
  description: string;
};

export type RecommendationList = {
  listName: string;
  items: RecommendationListItem[];
};

export type IError = {
  message: string;
  status?: number;
  title?: string;
  type?: string;
};

export type NotificationStore = {
  error: null | IError;
  success: null | string;
  isRefreshing?: boolean;
};

export type ModuleEntity = {
  configurationId: string;
  name: string;
  id: string;
};

export type TemplateEntity = {
  description: string;
  hasContextCategory: boolean;
  hasContextItem: boolean;
  language?: AppLanguage;
  name: string;
  pageType: string;
  id: string;
  modules: ModuleEntity[];
};

export type RecommendationEntity = {
  items: ItemEntity[];
  persona: PersonaEntity;
  raw: Record<string, any>[];
};

export type RecommendationsList = {
  modules: {
    module: ModuleEntity;
    recommendations: RecommendationEntity[];
  }[];
};

export type ApiExtraConfig = {
  snakeCase?: boolean;
};

export type RoleEntity = {
  id: string;
  name: string;
  description: string;
};

export type InviteEntity = {
  email: string;
  status: string;
  createdBy: UserEntity;
};
export type GeneralInfo = {
  name: string;
  industry: Industry;
  planType?: PlanType;
  monthlyPageViews: string;
  monthlyRevenue?: string;
};
export type BusinessInfo = {
  objectives: string;
  shouldCompare: boolean;
  benchmarkType?: BenchMarkType;
  benchmarkBaseline?: string;
  remarks?: string;
};

export type BillingInfo = {
  legalName?: string;
  vatNumber?: string;
  poReferences?: string[];
  billingAddress?: Address;
  billingPerson?: Person;
};
export type Address = {
  address1: string;
  address2?: string;
  postalCode: number;
  region: string;
  country: string;
  city: string;
};

export type Person = {
  firstName: string;
  lastName: string;
  email: string;
};

export type IntegrationInfo = {
  itemIntegrationType: ItemIntegrationType;
  eventIntegrationType: EventIntegrationType;
  recommendationIntegrationType: RecommendationIntegrationType;
  eventSdkFramework?: string;
  recommendationSdkFramework?: string;
  recommendationIntegrationLocation?: IntegrationLocation;
  serverLocation?: string;
  metadata?: string;
  otherInfo?: string;
  constraints?: ModuleConstraints;
};

export type ModuleConstraints = {
  maxAge?: number;
  minStock?: string;
  ignoredCategories?: string[];
  ignoredTags?: string[];
  other?: string;
};

export type DateInfo = {
  activatedAt: Date;
  trialStartsAt: Date;
};

export type ModuleTypeEntity = {
  id: string;
  name: string;
  description: string;
  froomleReference: string;
};

export type ModuleInfo = {
  label: string;
  placement: ModulePlacement;
  module: ModuleTypeEntity;
};

export type ModulePlacement = {
  pageType: PageType;
  position: string;
};

export type CompanyDetail = {
  id: string;
  name: string;
  status: CompanyStatus;
  environments?: Environment[];
  members?: Member[];
  logo?: string;
  generalInfo?: GeneralInfo;
  businessInfo?: BusinessInfo;
  billingInfo?: BillingInfo;
  integrationInfo?: IntegrationInfo;
  dateInfo?: DateInfo;
  modules?: ModuleInfo[];
  isDemo?: string;
  isConfirmed?: string;
};

export type CompanySecrets = {
  clientSecret: string;
  clientId: string;
  apiUrl: string;
};
