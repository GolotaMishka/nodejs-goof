export enum Industry {
  eCommerce = "eCommerce",
  news = "News",
  streaming = "Streaming",
  other = "Other",
}

export enum CompanyStatus {
  onboarding = "onboarding",
  inpreparation = "inpreparation",
  active = "active",
}

export enum CompanyInviteType {
  company = "company",
  admin = "admin",
}

export enum CompanyInviteStatus {
  pending = "pending",
  declined = "declined",
  accepted = "accepted",
}
export enum CreationStep {
  general = "general",
  business = "business",
  billing = "billing",
  integration = "integration",
  date = "date",
}

export enum RoleType {
  Business = "Business",
  Marketing = "Marketing",
  Product = "Product",
  Engineering = "Engineering",
  Development = "Development",
  DataScience = "Data Science",
  Other = "Other",
}

export enum PlanType {
  trial = "trial",
  subscription = "subscription",
}

export enum BenchMarkType {
  froomleDistributes = "froomleDistributes",
  customerDistributes = "customerDistributes",
}

export enum ItemIntegrationType {
  apiCalls = "apiCalls",
  SFTP = "SFTP",
}

export enum EventIntegrationType {
  /**
   * Events API integration
   */
  api = "api",
  /**
   * GTM Template provided by froomle
   */
  gtmTemplate = "gtmTemplate",
  /**
   * SDK provided by Froomle - each with short explanation
   */
  sdk = "sdk",
}

export enum RecommendationIntegrationType {
  /**
   * Recommendation API
   */
  recommendationApi = "recommendationApi",
  /**
   * SDK provided by Froomlen
   */
  sdk = "sdk",
  /**
   * Batch recommendation request (newsletters only) - each with a short explanation
   */
  batch = "batch",
}

export enum IntegrationLocation {
  backend = "backend",
  frontend = "frontend",
}

// Temporary type, should come from Configuration api
export enum PageType {
  article = "article",
  category = "category",
  home = "home",
  product = "product",
  basket = "basket",
  checkout = "checkout",
  other = "other",
}
