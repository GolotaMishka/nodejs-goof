import * as Yup from "yup";

export const SignUpSchema = Yup.object().shape({
  firstName: Yup.string().required("First name is required"),
  lastName: Yup.string().required("Last name is required"),
  email: Yup.string().email("Email is not valid").required("Email is required"),
  password: Yup.string()
    .matches(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/,
      "At least 8 characters, one uppercase, one lowercase, one number and one special character (eg. !@#$%^&*)"
    )
    .required("Required"),
  repeatPassword: Yup.string()
    .oneOf([Yup.ref("password")], "Passwords do not match")
    .required("Required"),
});

export const SignInNewSchema = Yup.object().shape({
  email: Yup.string()
    .email("Email is not valid")
    .required("Email is required")
    .nullable(),
  password: Yup.string().required("Required").nullable(),
});

export const ForgotPassSchema = Yup.object().shape({
  email: Yup.string().email("Email is not valid").required("Email is required"),
});

export const InviteSchema = Yup.object().shape({
  email: Yup.string().email("Email is not valid").required("Email is required"),
  role: Yup.string().required("Role is required"),
});

export const EditPersonaSchema = Yup.object().shape({
  isEnabled: Yup.boolean().required(),
  name: Yup.string().required("Name is required"),
  role: Yup.string().required("Role is required"),
  versionId: Yup.object()
    .shape({
      label: Yup.string().defined(),
      value: Yup.string().defined(),
    })
    .required("Version is required")
    .nullable(),
});

export const RecommendationSchema = Yup.object().shape({
  hasContextCategory: Yup.bool(),
  hasContextItem: Yup.bool(),
  contextItem: Yup.object()
    .when("hasContextItem", {
      is: true,
      then: Yup.object()
        .shape({
          froomleItemId: Yup.number(),
          clientItemId: Yup.string(),
        })
        .nullable()
        .required("Context item is required"),
    })
    .nullable(),
  contextCategory: Yup.object().when("hasContextCategory", {
    is: true,
    then: Yup.object()
      .shape({
        froomleItemId: Yup.number(),
        clientItemId: Yup.string(),
      })
      .nullable()
      .required("Context category is required"),
    otherwise: Yup.object().nullable(),
  }),
});

export const GeneralInfoSchema = Yup.object().shape({
  generalInfo: Yup.object()
    .shape({
      name: Yup.string().required("Required"),
      industry: Yup.string().required("Required"),
      monthlyPageViews: Yup.string().required("Required"),
      brands: Yup.array()
        .min(1, "Provide at least one")
        .of(
          Yup.string()
            .required("Required")
            .matches(/^[a-zA-Z ]*$/, "Use only letters")
        )
        .test("Unique", "Brands need te be unique", (values) => {
          return new Set(values).size === values?.length;
        })
        .required("Required"),
    })
    .required(),
});

export const BusinessInfoSchema = Yup.object().shape({
  businessInfo: Yup.object()
    .shape({
      objectives: Yup.string().required("Required"),
      shouldCompare: Yup.boolean().required("Required"),
      // benchmarkType: Yup.string().required("Required"),
      // benchmarkBaseline: Yup.string().required("Required"),
      remarks: Yup.string(),
    })
    .required(),
  modules: Yup.array().min(1, "Select at least one").required("Required"),
});

export const BillingInfoSchema = Yup.object().shape({
  billingInfo: Yup.object().shape({
    billingAddress: Yup.object().shape({
      address1: Yup.string().required("Required"),
      city: Yup.string().required("Required"),
      country: Yup.string().required("Required"),
      postalCode: Yup.string().required("Required"),
    }),
    billingPerson: Yup.object().shape({
      email: Yup.string().email("Email is not valid").required("Required"),
      firstName: Yup.string().required("Required"),
      lastName: Yup.string().required("Required"),
    }),
    legalName: Yup.string().required("Required"),
    vatNumber: Yup.string()
      .matches(
        /^(^$|ATU[0-9]{8}|BE[01][0-9]{9}|BG[0-9]{9,10}|HR[0-9]{11}|CY[A-Z0-9]{9}|CZ[0-9]{8,10}|DK[0-9]{8}|EE[0-9]{9}|FI[0-9]{8}|FR[0-9A-Z]{2}[0-9]{9}|DE[0-9]{9}|EL[0-9]{9}|HU[0-9]{8}|IE([0-9]{7}[A-Z]{1,2}|[0-9][A-Z][0-9]{5}[A-Z])|IT[0-9]{11}|LV[0-9]{11}|LT([0-9]{9}|[0-9]{12})|LU[0-9]{8}|MT[0-9]{8}|NL[0-9]{9}B[0-9]{2}|PL[0-9]{10}|PT[0-9]{9}|RO[0-9]{2,10}|SK[0-9]{10}|SI[0-9]{8}|ES[A-Z]([0-9]{8}|[0-9]{7}[A-Z])|SE[0-9]{12}|GB([0-9]{9}|[0-9]{12}|GD[0-4][0-9]{2}|HA[5-9][0-9]{2}))$/,
        "VAT is not valid"
      )
      .required("Required"),
  }),
});

export const IntegrationInfoSchema = Yup.object().shape({
  integrationInfo: Yup.object().shape({
    itemIntegrationType: Yup.string().required("Required"),
    eventIntegrationType: Yup.string().required("Required"),
    recommendationIntegrationType: Yup.string().required("Required"),
    eventSdkFramework: Yup.string()
      .when("eventIntegrationType", {
        is: "sdk",
        then: Yup.string().required("Required"),
      })
      .nullable(),
    recommendationSdkFramework: Yup.string().when(
      "recommendationIntegrationType",
      {
        is: "sdk",
        then: Yup.string().required("Required"),
      }
    ),
    recommendationIntegrationLocation: Yup.string().required("Required"),
    serverLocation: Yup.string().when("recommendationIntegrationLocation", {
      is: "backend",
      then: Yup.string().required("Required"),
    }),
  }),
  environments: Yup.array()
    .min(1, "Provide at least one")
    .of(
      Yup.object().shape({
        name: Yup.string()
          .required("Required")
          .matches(
            /^[a-z]+(_[a-z]+)*$/,
            "Use only lowercase letters and underscores"
          ),
      })
    )
    .test("Unique", "Environments need te be unique", (values) => {
      return new Set(values).size === values?.length;
    })
    .required("Required"),
});
export const DateInfoSchema = Yup.object().shape({
  dateInfo: Yup.object()
    .shape({
      activatedAt: Yup.date()
        .min(
          new Date(
            new Date(new Date().setHours(0, 0, 0, 0)).getTime() +
              1000 * 60 * 60 * 24 * 3
          ),
          "Must be at least 3 days in the future"
        )
        .required("Required"),
      trialStartsAt: Yup.date()
        .when("activatedAt", (activatedAt: Date) => {
          return (
            activatedAt &&
            Yup.date()
              .min(activatedAt, "Must be after activation date")
              .max(
                new Date(activatedAt.getTime() + 3600 * 1000 * 24 * 5),
                "Cannot be more than 5 days after activation date"
              )
          );
        })

        .required("Required"),
    })
    .required(),
});
