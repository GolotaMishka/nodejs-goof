/* eslint-disable camelcase */
import { User } from "@auth0/auth0-react";
import * as jwt from "jsonwebtoken";
import { RoleEntity } from "./types";

export interface AuthContext {
  isAuthenticated: boolean;
  user: User;
  roles?: RoleEntity[];
  organizationId?: string;
  accessToken: string;
  refreshToken: string;
  companyId?: string;
  companyName?: string;
  projectId?: string;
}
export const setAuthStorage = (
  idToken: string,
  accessToken: string,
  refreshToken: string,
  user: any
): void => {
  const claims = jwt.decode(idToken);
  const accessClaims = accessToken && jwt.decode(accessToken);

  const {
    nickname,
    name,
    picture,
    updated_at,
    email,
    email_verified,
    sub,
  } = claims;

  const organizationId =
    accessClaims?.[`${process.env.AUTH0_AUDIENCE}/organization_id`];
  const roles =
    accessClaims?.[`${process.env.AUTH0_AUDIENCE}/organization_roles`];

  const generalAuthData = {
    user: {
      nickname,
      name,
      picture,
      updated_at,
      email,
      email_verified,
      sub,
      id: user.id,
    },
    refreshToken,
  };

  const sessionAuthData = {
    accessToken,
    organizationId,
    roles,
    companyId: user.companyId,
    companyName: user.companyName,
    projectId: user.recopoProjectId,
  };

  window.localStorage.setItem("auth", JSON.stringify(generalAuthData));
  window.sessionStorage.setItem("auth", JSON.stringify(sessionAuthData));
};

export const getAuthStorage = (): AuthContext => {
  let auth;

  try {
    const generalAuthStorage = localStorage.getItem("auth");
    const sessionAuthStorage = sessionStorage.getItem("auth");
    const generalAuthData =
      generalAuthStorage && JSON.parse(generalAuthStorage);
    const sessionAuthData =
      sessionAuthStorage && JSON.parse(sessionAuthStorage);
    auth = generalAuthData && {
      ...generalAuthData,
      ...(sessionAuthData || {}),
    };
  } catch (e) {
    localStorage.removeItem("auth");
    sessionStorage.removeItem("auth");
  }

  return {
    isAuthenticated: !!auth,
    ...auth,
  };
};
