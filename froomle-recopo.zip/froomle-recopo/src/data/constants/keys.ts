const prefix = (name: string): string => `froomle/${name}`;

export const PERSONAS = prefix("personas");
export const VERSIONS = prefix("versions");
export const ENVIRONMENTS = prefix("environments");
export const TEMPLATES = prefix("templates");
export const RECOMMENDATIONS = prefix("recommendations");
export const HISTORY_ITEMS = prefix("historyItems");
export const CATEGORIES = prefix("categories");
export const COMPANIES = prefix("companies");
export const ROLES = prefix("roles");
export const INVITES = prefix("invites");
export const MODULES = prefix("modules");
export const PING = prefix("ping");
