import { EnvEntity, IError } from "data/utils/types";
import { UseQueryResult, UseQueryOptions, useQuery } from "react-query";
import * as api from "../api";
import * as constants from "../constants/keys";

export const useListEnvironments = (
  projectId: string,
  config?: UseQueryOptions<unknown, IError, EnvEntity[]>
): UseQueryResult<EnvEntity[], IError> => {
  return useQuery(
    [constants.ENVIRONMENTS, projectId],
    api.fetchEnvironments.bind(null, projectId),
    config
  );
};
