import { CompanyInviteStatus } from "data/utils/enums";
import { CompanyEntity, CompanyInviteEntity, IError } from "data/utils/types";
import { useQuery, UseQueryResult } from "react-query";

import * as api from "../api";
import * as constants from "../constants/keys";

export const useListCompanies = (
  userId?: string
): UseQueryResult<CompanyEntity[], IError> => {
  return useQuery(constants.COMPANIES, () => api.fetchCompanies(userId), {
    enabled: !!userId,
    staleTime: 5000,
  });
};

export const useListInvites = (
  userId?: string,
  status?: CompanyInviteStatus
): UseQueryResult<CompanyInviteEntity[], IError> => {
  return useQuery(constants.INVITES, () =>
    api.fetchInvites(userId, { status })
  );
};
