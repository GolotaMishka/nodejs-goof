import {
  BusinessInfoValues,
  GeneralInfoValues,
  InviteFormValues,
} from "app/utils/types";
import {
  BillingInfo,
  BusinessInfo,
  CompanyDetail,
  CompanyEntity,
  CompanySecrets,
  DateInfo,
  GeneralInfo,
  IError,
  IntegrationInfo,
} from "data";
import {
  useMutation,
  UseMutationResult,
  useQuery,
  useQueryClient,
  UseQueryResult,
} from "react-query";
import * as api from "../api";
import * as constants from "../constants/keys";

export const useCreateCompany = (): UseMutationResult<
  CompanyDetail,
  IError,
  GeneralInfoValues,
  unknown
> => {
  return useMutation(async (values) => {
    return api.createCompany(values);
  });
};

export const useCreateInvite = (
  companyId: string
): UseMutationResult<void, IError, InviteFormValues, unknown> => {
  const qc = useQueryClient();
  return useMutation(
    async (values) => {
      return api.createInvite(companyId, values);
    },
    {
      onMutate: (values) =>
        qc.setQueryData(constants.COMPANIES, (old: CompanyEntity[]) =>
          old.map((x) =>
            x.id === companyId
              ? {
                  ...x,
                  invitedEmails: [...(x.invitedEmails || []), values.email],
                }
              : x
          )
        ),
    }
  );
};

export const useCompanyDetail = (
  companyId?: string | null
): UseQueryResult<CompanyDetail, IError> => {
  return useQuery(
    [constants.COMPANIES, companyId],
    () => api.fetchCompany(companyId),
    { enabled: !!companyId, keepPreviousData: true, staleTime: 500 }
  );
};

export const useUpdateCompanyGeneral = (
  companyId: string
): UseMutationResult<GeneralInfo, IError, GeneralInfoValues, unknown> => {
  const qc = useQueryClient();
  return useMutation(
    async (values) => {
      return api.updateCompanyGeneral(companyId, values);
    },
    { onSuccess: () => qc.refetchQueries([constants.COMPANIES, companyId]) }
  );
};

export const useUpdateCompanyBusiness = (
  companyId: string
): UseMutationResult<BusinessInfo, IError, BusinessInfoValues, unknown> => {
  const qc = useQueryClient();
  return useMutation(
    async (values) => {
      return api.updateCompanyBusiness(companyId, values);
    },
    { onSuccess: () => qc.refetchQueries([constants.COMPANIES, companyId]) }
  );
};

export const useUpdateCompanyBilling = (
  companyId: string
): UseMutationResult<BillingInfo, IError, BillingInfo, unknown> => {
  const qc = useQueryClient();
  return useMutation(
    async (values) => {
      return api.updateCompanyBilling(companyId, values);
    },
    { onSuccess: () => qc.refetchQueries([constants.COMPANIES, companyId]) }
  );
};

export const useUpdateCompanyIntegration = (
  companyId: string
): UseMutationResult<IntegrationInfo, IError, IntegrationInfo, unknown> => {
  const qc = useQueryClient();
  return useMutation(
    async (values) => {
      return api.updateCompanyIntegration(companyId, values);
    },
    { onSuccess: () => qc.refetchQueries([constants.COMPANIES, companyId]) }
  );
};

export const useUpdateCompanyDates = (
  companyId: string
): UseMutationResult<DateInfo, IError, DateInfo, unknown> => {
  const qc = useQueryClient();
  return useMutation(
    async (values) => {
      return api.updateCompanyDates(companyId, values);
    },
    { onSuccess: () => qc.refetchQueries([constants.COMPANIES, companyId]) }
  );
};

export const useConfirmCompany = (
  companyId: string
): UseMutationResult<CompanyDetail, IError, void, unknown> => {
  return useMutation(async () => {
    return api.confirmCompany(companyId);
  });
};

export const useMeetingLink = (): UseQueryResult<string, IError> => {
  return useQuery([constants.COMPANIES, "meetingLink"], () =>
    api.getMeetingLink()
  );
};

export const useSecrets = (
  companyId: string
): UseQueryResult<CompanySecrets, IError> => {
  return useQuery([constants.COMPANIES, "secrets"], () =>
    api.getSecrets(companyId)
  );
};
