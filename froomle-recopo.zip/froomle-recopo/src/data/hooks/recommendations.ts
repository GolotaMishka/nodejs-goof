import { RecommendationsList, IError } from "data/utils/types";
import { useMutation, UseMutationResult } from "react-query";

import { useParams } from "react-router-dom";
import type { RecommendationParamsType } from "app/utils/types";
import * as api from "../api";
import { useAuth } from "./auth";

export const useCreateRecommendation = <Values>(): UseMutationResult<
  RecommendationsList,
  IError,
  Values,
  unknown
> => {
  const { envId, templateId } = useParams<RecommendationParamsType>();
  const { projectId } = useAuth();

  return useMutation(
    api.createRecommendation.bind(null, projectId, envId, templateId)
  );
};
