import { ParamsType } from "app/utils/types";
import { useParams } from "react-router-dom";
import { PersonaEntity, useAuth } from "data";
import {
  useQueryClient,
  UseMutationResult,
  UseQueryResult,
  useQuery,
  useMutation,
} from "react-query";
import arrayMove from "array-move";
import { idGenerator } from "app/utils/helpers";
import type { IError } from "../utils/types";
import * as api from "../api";
import { useListVersions } from "./versions";
import * as queryKeys from "../constants/keys";

type QueryContext = { previousPersonas: PersonaEntity[] };

export const useListPersonas = (): UseQueryResult<PersonaEntity[], IError> => {
  const { envId } = useParams<ParamsType>();
  const { projectId } = useAuth();

  return useQuery(
    queryKeys.PERSONAS,
    api.fetchPersonas.bind(null, projectId, envId)
  );
};

export const useCreatePersona = (): UseMutationResult<
  PersonaEntity,
  IError,
  Partial<PersonaEntity>,
  QueryContext
> => {
  const queryClient = useQueryClient();

  const { envId } = useParams<ParamsType>();
  const { projectId } = useAuth();

  const { data: versions } = useListVersions();

  return useMutation(api.createPersona.bind(null, projectId, envId), {
    onSuccess: () => {
      queryClient.invalidateQueries(queryKeys.PERSONAS);
    },
    onMutate: async (newPersona: Partial<PersonaEntity>) => {
      await queryClient.cancelQueries(queryKeys.PERSONAS);

      const previousPersonas = queryClient.getQueryData(
        queryKeys.PERSONAS
      ) as PersonaEntity[];

      queryClient.setQueryData(queryKeys.PERSONAS, (old: PersonaEntity[]) => {
        const newItem = {
          rank: old.length,
          items: [],
          id: idGenerator(),
          ...newPersona,
          version: versions?.find(
            (version) => String(version.id) === String(newPersona.versionId)
          ),
        } as PersonaEntity;

        const newItems: PersonaEntity[] = [
          ...old.slice(0, newItem.rank),
          newItem,
          ...old.slice(newItem.rank),
        ];

        return newItems;
      });

      return { previousPersonas };
    },
    onError: (_, __, context) => {
      queryClient.setQueryData(queryKeys.PERSONAS, context?.previousPersonas);
    },
  });
};

type UpdatePersonaVariables = {
  personaId: string;
  values: Partial<PersonaEntity>;
};

export const useUpdatePersona = (): UseMutationResult<
  PersonaEntity,
  IError,
  UpdatePersonaVariables,
  QueryContext
> => {
  const queryClient = useQueryClient();

  const { envId } = useParams<ParamsType>();
  const { projectId } = useAuth();

  return useMutation(api.updatePersona.bind(null, projectId, envId), {
    onSuccess: () => {
      queryClient.invalidateQueries(queryKeys.PERSONAS);
    },
    onMutate: async (variables: {
      personaId: string;
      values: Partial<PersonaEntity>;
    }) => {
      await queryClient.cancelQueries(queryKeys.PERSONAS);

      const previousPersonas = queryClient.getQueryData(
        queryKeys.PERSONAS
      ) as PersonaEntity[];

      // in case of reordering personas - we have to reorder other personas as well

      if (Number.isInteger(variables.values.rank)) {
        queryClient.setQueryData(queryKeys.PERSONAS, (old: PersonaEntity[]) => {
          const oldIndex = old.findIndex(
            (persona) => String(persona.id) === String(variables.personaId)
          );

          const newIndex = variables.values.rank as number;

          return arrayMove(old, oldIndex, newIndex);
        });
      }

      // in case of editing persona - we just need to replace old persona with new values

      queryClient.setQueryData(queryKeys.PERSONAS, (old: PersonaEntity[]) =>
        old.map((persona) => {
          if (String(persona.id) === String(variables.personaId)) {
            return {
              ...persona,
              ...variables.values,
            };
          }
          return persona;
        })
      );

      return { previousPersonas };
    },

    onError: (_, __, context) => {
      queryClient.setQueryData(queryKeys.PERSONAS, context?.previousPersonas);
    },
  });
};

export const useRemovePersona = (): UseMutationResult<
  PersonaEntity,
  IError,
  string,
  QueryContext
> => {
  const queryClient = useQueryClient();

  const { envId } = useParams<ParamsType>();
  const { projectId } = useAuth();

  return useMutation(api.removePersona.bind(null, projectId, envId), {
    onSuccess: () => {
      queryClient.invalidateQueries(queryKeys.PERSONAS);
    },
    onMutate: async (id: string) => {
      await queryClient.cancelQueries(queryKeys.PERSONAS);

      const previousPersonas = queryClient.getQueryData(
        queryKeys.PERSONAS
      ) as PersonaEntity[];

      queryClient.setQueryData(queryKeys.PERSONAS, (old: PersonaEntity[]) =>
        old.filter((persona) => String(persona.id) !== String(id))
      );
      return { previousPersonas };
    },
    onError: (_, __, context) => {
      queryClient.setQueryData(queryKeys.PERSONAS, context?.previousPersonas);
    },
  });
};

type PersonasInfoType = {
  totalPersonasCount: number;
  activePersonasCount: number;
};

export const usePersonasInfo = (): PersonasInfoType => {
  const { data: personas } = useListPersonas();

  return {
    totalPersonasCount: personas?.length ?? 0,
    activePersonasCount: personas?.filter((p) => p.isEnabled).length ?? 0,
  };
};
