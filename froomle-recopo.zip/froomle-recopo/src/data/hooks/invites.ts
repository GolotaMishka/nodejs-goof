import { CompanyInviteEntity, IError } from "data/utils/types";
import {
  useMutation,
  UseMutationResult,
  useQuery,
  UseQueryResult,
} from "react-query";

import * as api from "../api";
import * as constants from "../constants/keys";

export const useInvite = (
  inviteId?: string | null
): UseQueryResult<CompanyInviteEntity, IError> => {
  return useQuery(
    [constants.INVITES, inviteId],
    () => api.fetchInvite(inviteId),
    { enabled: !!inviteId }
  );
};

export const useAcceptInvite = (): UseMutationResult<
  void,
  IError,
  string | null | undefined
> => {
  return useMutation((inviteId) => api.acceptInvite(inviteId));
};

export const useDeclineInvite = (): UseMutationResult<
  void,
  IError,
  string | null | undefined
> => {
  return useMutation((inviteId) => api.declineInvite(inviteId));
};
