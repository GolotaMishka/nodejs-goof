import { TemplateEntity, IError } from "data/utils/types";
import { useQuery, UseQueryResult } from "react-query";

import { useParams } from "react-router-dom";
import type { ParamsType } from "app/utils/types";
import * as api from "../api";

import * as constants from "../constants/keys";
import { useAuth } from "./auth";

export const useListTemplates = (): UseQueryResult<
  TemplateEntity[],
  IError
> => {
  const { envId } = useParams<ParamsType>();
  const { projectId } = useAuth();

  return useQuery(
    constants.TEMPLATES,
    api.fetchTemplates.bind(null, projectId, envId)
  );
};
