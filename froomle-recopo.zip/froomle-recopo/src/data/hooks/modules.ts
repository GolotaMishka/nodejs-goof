import { Industry } from "data";
import { IError, ModuleTypeEntity } from "data/utils/types";
import { useQuery, UseQueryResult } from "react-query";
import * as api from "../api";
import * as constants from "../constants/keys";

export const useListModules = (
  industry?: Industry
): UseQueryResult<ModuleTypeEntity[], IError> => {
  return useQuery([constants.MODULES, industry], () =>
    api.fetchModules(industry)
  );
};
