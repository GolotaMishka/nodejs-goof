import { signInPath } from "app/constants/url";
import {
  SignUpFormValues,
  SignInFormValues,
  SignInByCodeFormValues,
  ForgotPassFormValues,
} from "app/utils/types";
import { IError, RoleEntity, UserEntity } from "data";
import { AuthContext, getAuthStorage } from "data/utils";
import { useCallback } from "react";
import {
  useMutation,
  UseMutationResult,
  useQuery,
  UseQueryResult,
} from "react-query";
import { useHistory } from "react-router-dom";
import * as api from "../api";
import * as constants from "../constants/keys";

type LogoutFunc = () => void;

export const useAuth = (): AuthContext => {
  return getAuthStorage();
};

export const useLogout = (): LogoutFunc => {
  const history = useHistory();
  return useCallback(() => {
    localStorage.clear();
    sessionStorage.clear();
    history.push(signInPath);
  }, []);
};

export const useRegister = (): UseMutationResult<
  void,
  IError,
  SignUpFormValues,
  unknown
> => {
  return useMutation((values) => api.register(values));
};

export const useRegisterFromInvite = (
  inviteId?: string
): UseMutationResult<void, IError, SignUpFormValues, unknown> => {
  return useMutation((values) => api.registerFromInvite(values, inviteId));
};

export const useLogin = (): UseMutationResult<
  void,
  IError,
  SignInFormValues,
  unknown
> => {
  return useMutation((values) => api.login(values));
};

export const useRefresh = (): UseMutationResult<
  AuthContext,
  IError,
  { token: string; companyId?: string },
  unknown
> => {
  return useMutation(async (values) => {
    await api.refresh(values.token, values.companyId);
    const a = useAuth;
    return a();
  });
};

export const useRequestPassword = (): UseMutationResult<
  void,
  IError,
  ForgotPassFormValues,
  unknown
> => {
  return useMutation((values) => api.requestPassword(values));
};

export const useLoginByCode = (): UseMutationResult<
  UserEntity,
  IError,
  SignInByCodeFormValues,
  unknown
> => {
  return useMutation((values) => api.loginByCode(values));
};

export const useListRoles = (): UseQueryResult<RoleEntity[], IError> => {
  return useQuery(constants.ROLES, () => api.fetchRoles());
};

export const usePingApis = (): UseQueryResult<void, null> => {
  return useQuery(constants.PING, () => api.pingApis());
};
