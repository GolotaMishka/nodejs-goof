import { ParamsType } from "app/utils/types";
import { useParams } from "react-router-dom";
import { PersonaEntity, useAuth } from "data";
import {
  useQueryClient,
  UseMutationResult,
  UseQueryResult,
  UseQueryOptions,
  useMutation,
  useQuery,
} from "react-query";
import { HistoryItemEntity, ItemEntity, IError } from "../utils/types";
import * as api from "../api";
import * as queryKeys from "../constants/keys";

type RemoveVariables = {
  personaId: string;
  itemId: string;
};

type QueryContext = { previousPersonas: PersonaEntity[] };

export const useRemoveHistoryItem = (): UseMutationResult<
  void,
  IError,
  RemoveVariables,
  QueryContext
> => {
  const queryClient = useQueryClient();

  const { envId } = useParams<ParamsType>();
  const { projectId } = useAuth();

  return useMutation<void, IError, RemoveVariables, QueryContext>(
    api.deleteHistoryItem.bind(null, projectId!, envId),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(queryKeys.PERSONAS);
      },
      onMutate: async ({ personaId, itemId }: RemoveVariables) => {
        await queryClient.cancelQueries(queryKeys.PERSONAS);

        const previousPersonas = queryClient.getQueryData(
          queryKeys.PERSONAS
        ) as PersonaEntity[];

        queryClient.setQueryData(queryKeys.PERSONAS, (old: PersonaEntity[]) => {
          return old.map((persona) => {
            if (String(persona.id) === String(personaId)) {
              return {
                ...persona,
                items: persona.items.filter(
                  (item) => String(item.itemId) !== String(itemId)
                ),
              };
            }
            return persona;
          });
        });

        return { previousPersonas };
      },
      onError: (_, __, context) => {
        queryClient.setQueryData(queryKeys.PERSONAS, context?.previousPersonas);
      },
    }
  );
};

type UpdateVariables = {
  personaId: string;
  itemId: string;
  values: Partial<HistoryItemEntity>;
};

export const useUpdateHistoryItem = (): UseMutationResult<
  HistoryItemEntity,
  IError,
  UpdateVariables,
  QueryContext
> => {
  const queryClient = useQueryClient();
  const { envId } = useParams<ParamsType>();
  const { projectId } = useAuth();

  return useMutation<HistoryItemEntity, IError, UpdateVariables, QueryContext>(
    api.updateHistoryItem.bind(null, projectId!, envId),
    {
      onSuccess: () => {
        queryClient.invalidateQueries(queryKeys.PERSONAS);
      },
      onMutate: async ({ personaId, itemId, values }: UpdateVariables) => {
        await queryClient.cancelQueries(queryKeys.PERSONAS);

        const previousPersonas = queryClient.getQueryData(
          queryKeys.PERSONAS
        ) as PersonaEntity[];

        queryClient.setQueryData(queryKeys.PERSONAS, (old: PersonaEntity[]) => {
          return old.map((persona) => {
            if (persona.id === personaId) {
              return {
                ...persona,
                items: persona.items.map((item) => {
                  if (item.itemId === itemId) {
                    return { ...item, ...values };
                  }
                  return item;
                }),
              };
            }
            return persona;
          });
        });
        return { previousPersonas };
      },
    }
  );
};

export const useListHistoryItems = (
  search = "",
  limit = 10,
  orderByPopularity = true
): UseQueryResult<ItemEntity[], IError> => {
  const { envId } = useParams<ParamsType>();
  const { projectId } = useAuth();
  return useQuery(
    [queryKeys.HISTORY_ITEMS, search, orderByPopularity],
    () =>
      api.fetchHistoryItems(projectId!, envId, {
        title: search,
        limit,
        orderByPopularity,
      }),
    { enabled: search.length > 2 || search === "" }
  );
};

type ImportItemsVariables = {
  froomleItemIds: number[];
  clientItemIds: string[];
};

export const useImportHistoryItemsByIds = (): UseMutationResult<
  ItemEntity[],
  IError,
  ImportItemsVariables
> => {
  const { envId } = useParams<ParamsType>();
  const { projectId } = useAuth();

  return useMutation(api.importHistoryItemsByIds.bind(null, projectId!, envId));
};

export const useListCategories = (
  config?: UseQueryOptions<unknown, IError, string[]>
): UseQueryResult<string[], IError> => {
  const { envId } = useParams<ParamsType>();
  const { projectId } = useAuth();
  return useQuery(
    [queryKeys.CATEGORIES],
    () => api.fetchCategories(projectId!, envId),
    config
  );
};
