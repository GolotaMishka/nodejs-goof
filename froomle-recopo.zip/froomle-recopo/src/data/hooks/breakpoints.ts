import breakpoints from "ui/styles/_breakpoints.scss";
import { useMediaQuery } from "react-responsive";

type Breakpoins = {
  isSmallMobile?: boolean;
  isMobile?: boolean;
  isTablet?: boolean;
  isSmallDesktop?: boolean;
  isDesktop?: boolean;
};

export const useBreakpoints = (): Breakpoins => {
  const isSmallMobile = useMediaQuery({
    query: `(max-width: ${breakpoints.mobile})`,
  });

  const isMobile = useMediaQuery({
    query: `(max-width: ${breakpoints.tablet})`,
  });

  const isTablet = useMediaQuery({
    query: `(min-width: ${parseInt(breakpoints.tablet, 10) + 1}px)`,
  });

  const isSmallDesktop = useMediaQuery({
    query: `(min-width: ${parseInt(breakpoints.smallDesktop, 10) + 1}px)`,
  });

  const isDesktop = useMediaQuery({
    query: `(min-width: ${parseInt(breakpoints.desktop, 10) + 1}px)`,
  });

  return { isSmallMobile, isMobile, isTablet, isSmallDesktop, isDesktop };
};
