import { useLocation } from "react-router-dom";

type Pages = {
  isHomePage?: boolean;
  isPersonasPage?: boolean;
  isModulesPage?: boolean;
  isRecommendationsPage?: boolean;
  isInsightsPage?: boolean;
  isSelectEnvironmentPage?: boolean;
  isCurrentPage: (a: string) => boolean;
};

export const useCurrentPage = (): Pages => {
  const { pathname } = useLocation();

  const check = (page: string) => pathname.endsWith(`/${page}`);

  return {
    isHomePage: check("home"),
    isPersonasPage: check("personas"),
    isModulesPage: check("templates"),
    isInsightsPage: check("insights"),
    isSelectEnvironmentPage: check("project"),
    isCurrentPage: check,
  };
};
