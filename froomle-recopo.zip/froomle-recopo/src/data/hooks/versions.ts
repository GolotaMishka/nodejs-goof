import { VersionEntity } from "data/utils/types";
import { useQuery, UseQueryResult } from "react-query";
import { useParams } from "react-router-dom";
import type { ParamsType } from "app/utils/types";
import type { IError } from "../utils/types";
import * as queryKeys from "../constants/keys";
import * as api from "../api";
import { useAuth } from "./auth";

export const useListVersions = (): UseQueryResult<VersionEntity[], IError> => {
  const { envId } = useParams<ParamsType>();
  const { projectId } = useAuth();

  return useQuery(
    queryKeys.VERSIONS,
    api.fetchVersions.bind(null, projectId, envId)
  );
};
