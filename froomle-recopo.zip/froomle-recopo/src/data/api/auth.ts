import {
  ForgotPassFormValues,
  SignInByCodeFormValues,
  SignInFormValues,
  SignUpFormValues,
} from "app/utils/types";
import axios, { AxiosResponse } from "axios";
import { RoleEntity, UserEntity } from "data";
import { onboardingApi } from "data/store";

export const register = (values: SignUpFormValues): Promise<void> => {
  return onboardingApi.post(`/authentication/register`, values);
};

export const registerFromInvite = (
  values: SignUpFormValues,
  inviteId?: string
): Promise<void> => {
  return onboardingApi.post(`/invites/${inviteId}/register`, values);
};

export const login = (values: SignInFormValues): Promise<void> =>
  onboardingApi.post(`/authentication/login`, values);

export const refresh = (
  token: string | null,
  companyId?: string
): Promise<AxiosResponse<any>> =>
  onboardingApi.post(`/authentication/refresh`, { token, companyId });

export const loginByCode = (
  values: SignInByCodeFormValues
): Promise<UserEntity> =>
  onboardingApi.post(`/authentication/login/code`, values);

export const requestPassword = (values: ForgotPassFormValues): Promise<void> =>
  onboardingApi.post(`/authentication/request-password`, values);

export const fetchRoles = (): Promise<RoleEntity[]> =>
  onboardingApi.get(`/authentication/roles`);

export const pingApis = async (): Promise<unknown> =>
  Promise.all([
    new Promise((res) =>
      axios
        .get(process.env.ONBOARDING_API_BASE_URL as string)
        .then(res)
        .catch(res)
    ),
    new Promise((res) =>
      axios
        .get(process.env.API_BASE_URL as string)
        .then(res)
        .catch(res)
    ),
  ]);
