import {
  BusinessInfoValues,
  GeneralInfoValues,
  InviteFormValues,
} from "app/utils/types";
import {
  BillingInfo,
  BusinessInfo,
  CompanyDetail,
  CompanySecrets,
  DateInfo,
  GeneralInfo,
  IntegrationInfo,
} from "data";
import { onboardingApi } from "data/store";

// TODO: cleanup and split off types
export const createCompany = (
  values: GeneralInfoValues
): Promise<CompanyDetail> => {
  return onboardingApi.post(`/companies`, { generalInfo: values });
};

export const createInvite = (
  companyId: string,
  values: InviteFormValues
): Promise<void> => {
  return onboardingApi.post(`/companies/${companyId}/invites`, values);
};

export const fetchCompany = (
  companyId?: string | null
): Promise<CompanyDetail> => onboardingApi.get(`/companies/${companyId}`);

export const updateCompanyGeneral = (
  companyId: string,
  values: GeneralInfoValues
): Promise<GeneralInfo> => {
  return onboardingApi.patch(`/companies/${companyId}/general`, values);
};

export const updateCompanyBusiness = (
  companyId: string,
  values: BusinessInfoValues
): Promise<BusinessInfo> => {
  return onboardingApi.patch(`/companies/${companyId}/business`, values);
};

export const updateCompanyBilling = (
  companyId: string,
  values: BillingInfo
): Promise<BillingInfo> => {
  return onboardingApi.patch(`/companies/${companyId}/billing`, values);
};

export const updateCompanyIntegration = (
  companyId: string,
  values: IntegrationInfo
): Promise<IntegrationInfo> => {
  return onboardingApi.patch(`/companies/${companyId}/integration`, values);
};

export const updateCompanyDates = (
  companyId: string,
  values: DateInfo
): Promise<DateInfo> => {
  return onboardingApi.patch(`/companies/${companyId}/date`, values);
};

export const confirmCompany = (companyId: string): Promise<CompanyDetail> => {
  return onboardingApi.patch(`/companies/${companyId}/confirm`);
};

export const getMeetingLink = async (): Promise<string> => {
  return (await onboardingApi.get(`/meetings/links`)).link;
};

export const getSecrets = (companyId: string): Promise<CompanySecrets> => {
  return onboardingApi.get(`/companies/${companyId}/secrets`);
};
