import { CompanyInviteStatus } from "data";
import { onboardingApi } from "data/store";

import type { CompanyEntity, CompanyInviteEntity } from "../utils/types";

export const fetchCompanies = (userId?: string): Promise<CompanyEntity[]> =>
  onboardingApi.get(`/users/${userId}/companies`);

export const fetchInvites = (
  userId?: string,
  body?: { status?: CompanyInviteStatus }
): Promise<CompanyInviteEntity[]> =>
  onboardingApi.get(`/users/${userId}/invites`, {
    params: body,
  });
