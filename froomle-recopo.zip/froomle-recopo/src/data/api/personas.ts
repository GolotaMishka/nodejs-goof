import { PersonaEntity } from "data/utils/types";
import { api } from "data/store";

export const fetchPersonas = (
  projectId: string,
  envId: string
): Promise<PersonaEntity[]> =>
  api.get(`/projects/${projectId}/environments/${envId}/personas`);

export const createPersona = (
  projectId: string,
  envId: string,
  values: Partial<PersonaEntity>
): Promise<PersonaEntity> =>
  api.post(`/projects/${projectId}/environments/${envId}/personas`, {
    ...values,
    isNew: undefined,
  });

export const updatePersona = (
  projectId: string,
  envId: string,
  config: {
    personaId: string;
    values: Partial<PersonaEntity>;
  }
): Promise<PersonaEntity> =>
  api.put(
    `/projects/${projectId}/environments/${envId}/personas/${config.personaId}`,
    config.values
  );

export const removePersona = (
  projectId: string,
  envId: string,
  personaId: string
): Promise<void> =>
  api.delete(
    `/projects/${projectId}/environments/${envId}/personas/${personaId}`
  );

export const fetchPersona = (
  projectId: string,
  envId: string,
  personaId: string
): Promise<PersonaEntity> =>
  api.get(`/projects/${projectId}/environments/${envId}/personas/${personaId}`);
