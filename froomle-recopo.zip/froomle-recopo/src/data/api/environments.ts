import { EnvEntity } from "data/utils/types";
import { api } from "data/store";

export const fetchEnvironments = (projectId: string): Promise<EnvEntity[]> =>
  api.get(`/projects/${projectId}/environments`);
