import { api } from "data/store";
import type { TemplateEntity } from "../utils/types";

export const fetchTemplates = (
  projectId: string,
  envId: string
): Promise<TemplateEntity[]> =>
  api.get(`/projects/${projectId}/environments/${envId}/templates`);
