import { api } from "data/store";
import type { RecommendationEntity } from "../utils/types";

type RequestValues = {
  contextCategory?: string;
  contextItem?: {
    clientItemId?: string;
    froomleItemId?: number;
  };
};

export const createRecommendation = (
  projectId: string,
  envId: string,
  templateId: string,
  values: RequestValues
): Promise<RecommendationEntity[]> =>
  api.post(
    `/projects/${projectId}/environments/${envId}/templates/${templateId}/recommendations`,
    values
  );
