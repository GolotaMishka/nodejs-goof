import { CompanyInviteEntity } from "data";
import { onboardingApi } from "data/store";

export const fetchInvite = (
  inviteId?: string | null
): Promise<CompanyInviteEntity> => onboardingApi.get(`/invites/${inviteId}`);

export const acceptInvite = (inviteId?: string | null): Promise<void> => {
  return onboardingApi.post(`/invites/${inviteId}/accept`);
};

export const declineInvite = (inviteId?: string | null): Promise<void> => {
  return onboardingApi.delete(`/invites/${inviteId}`);
};
