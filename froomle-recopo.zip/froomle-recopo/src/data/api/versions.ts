import { VersionEntity } from "data/utils/types";
import { api } from "data/store";

export const fetchVersions = (
  projectId: string,
  envId: string
): Promise<VersionEntity[]> =>
  api.get(`/projects/${projectId}/environments/${envId}/versions`);
