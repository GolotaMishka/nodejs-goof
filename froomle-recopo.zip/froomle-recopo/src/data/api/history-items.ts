import { api } from "data/store";
import { HistoryItemEntity } from "data/utils/types";

export const updateHistoryItem = (
  projectId: string,
  envId: string,
  config: {
    personaId: string;
    values: Partial<HistoryItemEntity>;
    itemId: string;
  }
): Promise<HistoryItemEntity> =>
  api.put(
    `/projects/${projectId}/environments/${envId}/personas/${config.personaId}/items/${config.itemId}`,
    config.values
  );

export const deleteHistoryItem = (
  projectId: string,
  envId: string,
  config: {
    personaId: string;
    itemId: string;
  }
): Promise<void> =>
  api.delete(
    `/projects/${projectId}/environments/${envId}/personas/${config.personaId}/items/${config.itemId}`
  );

export const fetchHistoryItems = (
  projectId: string,
  envId: string,
  params: { title: string; limit?: number; orderByPopularity?: boolean }
): Promise<HistoryItemEntity[]> =>
  api.get(`/projects/${projectId}/environments/${envId}/items/search-items`, {
    params,
  });

export const importHistoryItemsByIds = (
  projectId: string,
  envId: string,
  body: { froomleItemIds: number[]; clientItemIds: string[] }
): Promise<HistoryItemEntity[]> =>
  api.post(
    `/projects/${projectId}/environments/${envId}/items/import-items`,
    body
  );

export const fetchCategories = (
  projectId: string,
  envId: string
): Promise<string[]> =>
  api.get(`/projects/${projectId}/environments/${envId}/categories`);
