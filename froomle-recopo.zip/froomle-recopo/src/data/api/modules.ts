import { Industry } from "data";
import { onboardingApi } from "data/store";
import { ModuleTypeEntity } from "data/utils/types";

export const fetchModules = (
  industry?: Industry
): Promise<ModuleTypeEntity[]> =>
  onboardingApi.get(`/modules`, { params: { industry } });
