export type SimpleSpread<L, R> = R & Pick<L, Exclude<keyof L, keyof R>>;

export type SelectOption<V = string | number> = {
  label: string;
  value: V;
};
