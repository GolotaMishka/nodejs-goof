import { useEffect, useRef } from "react";

const MOUSELEAVE = "mouseleave";
const SCROLL = "scroll";

type HandledEvents = [typeof MOUSELEAVE, typeof SCROLL];
type HandledEventsType = HandledEvents[number];
type PossibleEvent = {
  [Type in HandledEventsType]: HTMLElementEventMap[Type];
}[HandledEventsType];
type Handler = (event: PossibleEvent) => void;

const useEventListener = (
  type: HandledEventsType,
  ref: React.RefObject<HTMLElement>,
  handler: Handler
): void => {
  const handlerRef = useRef(handler);

  useEffect(() => {
    handlerRef.current = handler;
  });

  useEffect(() => {
    const listener = (event: PossibleEvent) => {
      handlerRef.current(event);
    };

    ref.current?.addEventListener(type, listener);

    return () => {
      ref.current?.removeEventListener(type, listener);
    };
  }, [handler]);
};

export default useEventListener;
