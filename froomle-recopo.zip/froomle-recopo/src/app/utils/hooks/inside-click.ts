import { useEffect } from "react";

const useInsideClick = (
  ref: React.RefObject<HTMLElement>,
  callback: () => void
): void => {
  const handler = (e: MouseEvent) => {
    if (ref.current && ref.current === e.target) {
      callback();
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handler);
    return () => {
      document.removeEventListener("mousedown", handler);
    };
  }, []);
};

export default useInsideClick;
