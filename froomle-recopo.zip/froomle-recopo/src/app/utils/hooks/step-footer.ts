import { useContext, useEffect } from "react";
import StepFooterContext, {
  StepFooterProviderType,
  StepFooterStateType,
} from "../context/step-footer";

const useStepFooter = (
  newState: StepFooterStateType,
  dependencies: any[] = []
): StepFooterProviderType => {
  const context = useContext(StepFooterContext);

  useEffect(() => {
    context.setStepFooterState(newState);
  }, dependencies);

  return context;
};

export default useStepFooter;
