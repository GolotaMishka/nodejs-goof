import { useCallback, useRef, useState, TouchEvent } from "react";

type LongTouchFunc = (e: TouchEvent, ...context: any) => void;
type ReleaseFunc = (e: TouchEvent) => void;

type EventHandlers = {
  onTouchStart: (e: TouchEvent) => void;
  onTouchEnd: (e: TouchEvent) => void;
};

type EventHandlerCreator = (...context: any) => EventHandlers;

const useLongTouch = (
  onLongPress: LongTouchFunc,
  onRelease: ReleaseFunc,
  delay = 300
): EventHandlerCreator => {
  const [longPressTriggered, setLongPressTriggered] = useState(false);
  const timeout = useRef<NodeJS.Timeout | null>(null);

  const start = useCallback(
    (event: TouchEvent, ...context: any) => {
      timeout.current = setTimeout(() => {
        onLongPress(event, ...context);
        setLongPressTriggered(true);
      }, delay);
    },
    [onLongPress, delay]
  );

  const clear = useCallback(
    (e: TouchEvent) => {
      if (timeout.current) clearTimeout(timeout.current);
      if (onRelease && longPressTriggered) onRelease(e);
      setLongPressTriggered(false);
    },
    [onRelease, longPressTriggered]
  );

  return (...context: any) => ({
    onTouchStart: (e: TouchEvent) => start(e, ...context),
    onTouchEnd: (e: TouchEvent) => clear(e),
  });
};

export default useLongTouch;
