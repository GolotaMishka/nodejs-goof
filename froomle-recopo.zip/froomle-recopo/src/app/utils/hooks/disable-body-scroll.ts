import { useCallback, useEffect } from "react";

const useDisableBodyScroll = (condition?: boolean): void => {
  const disable = useCallback(() => {
    document.body.style.overflow = "hidden";
  }, []);

  const enable = useCallback(() => {
    document.body.style.overflow = "visible";
  }, []);

  useEffect(() => {
    disable();

    return enable;
  }, []);

  useEffect(() => {
    if (typeof condition === "undefined") return;
    if (condition) {
      disable();
    } else {
      enable();
    }
  }, [condition]);
};

export default useDisableBodyScroll;
