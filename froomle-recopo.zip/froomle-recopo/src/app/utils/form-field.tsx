import React, { ComponentType } from "react";
import { useFormikContext, useField } from "formik";

export interface FormFieldProps {
  component: ComponentType;
  name: string;
  value?: any;
  type?: string;
  ref?: (instance: any) => void;
  valueAdapter?: (...args: any) => any;
  onChangeAdapter: (...args: any) => string;
  id: string;
  children: React.ReactNode;
  className?: string;
  placeholder?: string;
  title?: string;
  [key: string]: any;
  onBlur: (...args: any) => void;
  dataCy?: string;
}

const Field = React.forwardRef<HTMLElement, FormFieldProps>(
  (props: FormFieldProps, ref) => {
    const formik = useFormikContext();
    const [field, meta] = useField(props);

    const {
      component,
      valueAdapter,
      onChangeAdapter,
      children,
      error: errorFromProps,
      ...leftProps
    } = props;

    const onChange = (...args) => {
      formik.setFieldValue(props.name, onChangeAdapter(...args));
    };

    const onBlur = () => {
      if (props.onBlur) {
        props.onBlur();
      }
      formik.setFieldTouched(props.name as never, true);
    };

    const { error, touched, initialError, initialTouched, initialValue } = meta;

    const fieldProps = {
      ...field,
      ...leftProps,
      error: touched && (errorFromProps || error),
      touched: touched.toString(),
      initialtouched: initialTouched.toString(),
      initialvalue: initialValue,
      initialerror: initialError,
      value: valueAdapter ? valueAdapter(field.value) : field.value,
      onChange,
      onBlur,
      ref,
    };

    return React.createElement(component, fieldProps as any, children);
  }
);

Field.defaultProps = {
  onChangeAdapter: (e) => e?.target.value,
};

Field.displayName = "Field";

export default Field;
