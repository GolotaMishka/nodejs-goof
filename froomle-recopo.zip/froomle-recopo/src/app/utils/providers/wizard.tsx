import React, { ReactElement, ReactNode, useState } from "react";
import WizardContext, { defaultContext } from "app/utils/context/wizard";

interface IProps {
  children: ReactNode;
}

const WizardProvider = ({ children }: IProps): ReactElement => {
  const [step, setStep] = useState(defaultContext.step);
  const [meta, setMeta] = useState(defaultContext.meta);

  return (
    <WizardContext.Provider
      value={{ steps: defaultContext.steps, step, setStep, meta, setMeta }}
    >
      {children}
    </WizardContext.Provider>
  );
};

export default WizardProvider;
