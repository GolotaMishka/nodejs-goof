import React, { ReactElement, ReactNode, useState } from "react";
import StepFooterContext, { defaultState } from "app/utils/context/step-footer";

interface IProps {
  children: ReactNode;
}

const StepFooterProvider = ({ children }: IProps): ReactElement => {
  const [stepFooterState, setStepFooterState] = useState(defaultState);

  return (
    <StepFooterContext.Provider value={{ stepFooterState, setStepFooterState }}>
      {children}
    </StepFooterContext.Provider>
  );
};

export default StepFooterProvider;
