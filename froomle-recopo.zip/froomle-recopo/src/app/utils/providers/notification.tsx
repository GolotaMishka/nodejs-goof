import { notificationStore } from "data";
import React, { ReactElement, useCallback, useEffect } from "react";
import { NotificationContainer, toast, ErrorMessage } from "ui";

const NotificationProvider = (): ReactElement => {
  const dispatchErrorNotification = useCallback(() => {
    const { error } = notificationStore.getState();
    (toast as any).error(<ErrorMessage message={error?.message as string} />);
  }, []);

  const dispatchSuccessNotification = useCallback(() => {
    const { success: successMessage } = notificationStore.getState();
    (toast as any).success(<div>{successMessage}</div>);
  }, []);

  useEffect(() => {
    const unsubFromError = notificationStore.subscribe(
      dispatchErrorNotification,
      (state) => state.error
    );

    const unsubFromSuccess = notificationStore.subscribe(
      dispatchSuccessNotification,
      (state) => state.success
    );

    return () => {
      unsubFromError();
      unsubFromSuccess();
      notificationStore.destroy();
    };
  }, []);

  return (
    <NotificationContainer
      // style={{ marginBottom: 48 }}
      // TODO: fix panenco-ui and revert this change
      position="bottom-right"
    />
  );
};

export default NotificationProvider;
