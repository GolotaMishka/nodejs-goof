import React, { ReactElement, useState } from "react";
import Tour from "reactour";
import TourContext from "app/utils/context/tour";
import { AppThemeType, useTheme } from "ui";
import { homePath } from "app/constants/url";
import { useBreakpoints } from "data/hooks/breakpoints";
import { useAuth, useStore } from "data";
import { useHistory } from "react-router-dom";
import { useDisableBodyScroll } from "../hooks";

const steps = [
  {
    content:
      "Create and manage the personas for which you want to simulate recommendations.",
    selector: "[data-tour=personas-wizard-card]",
    position: "bottom",
  },
  {
    content: "Have a look at your available Froomle Modules.",
    selector: "[data-tour=modules-wizard-card]",
    position: "bottom",
  },
  {
    content:
      "Experience which recommendations your personas would see for the module you selected.",
    selector: "[data-tour=reccomendations-wizard-card]",
    position: "bottom",
  },
  {
    content:
      "Obtain insights about your online channels and about the adoption and performance of your Froomle modules.",
    selector: "[data-tour=insights-info-card]",
    position: "left",
  },
  {
    content: "Contact Froomle support in case you have questions or remarks.",
    selector: "[data-tour=contact-button]",
    position: "top",
  },
];

const TourProvider: React.FC = ({ children }): ReactElement => {
  const history = useHistory();
  const { env } = useStore();
  const { isMobile } = useBreakpoints();
  const [step, setStep] = useState(0);
  const [isOpened, setIsOpened] = useState(false);
  const { companyId } = useAuth();

  const isFinished = () => localStorage?.getItem("tour") === "finished";

  const theme: AppThemeType = useTheme();

  const closeTour = () => {
    localStorage?.setItem("tour", "finished");
    setStep(0);
    setIsOpened(false);
  };

  // to prevent tour from opening in dev envirionment
  if (process.env.NODE_ENV === "development") {
    localStorage?.setItem("tour", "finished");
  }

  const goToNextStep = () => {
    setStep(step + 1);
  };

  const start = () => {
    history.push(homePath(companyId!, env?.id as string));
    localStorage.removeItem("tour");
    setIsOpened(true);
  };

  useDisableBodyScroll(!isMobile && isOpened);

  return (
    <TourContext.Provider
      value={{
        goToNextStep,
        isOpen: isOpened,
        goToStep: setStep,
        currentStep: step,
        isFinished,
        start,
      }}
    >
      {isOpened && (
        <Tour
          isOpen
          steps={steps}
          goToStep={step}
          onRequestClose={closeTour}
          disableFocusLock
          accentColor={theme.colors.accent}
          disableDotsNavigation
          showPrevNextButtons
        />
      )}
      {children}
    </TourContext.Provider>
  );
};

export default TourProvider;
