import { getRandomArrayElement } from "./helpers";

const topTypeOptions = [
  "NoHair",
  "Eyepatch",
  "Hat",
  "Hijab",
  "Turban",
  "WinterHat1",
  "WinterHat2",
  "WinterHat3",
  "WinterHat4",
  "LongHairBigHair",
  "LongHairBob",
  "LongHairBun",
  "LongHairCurly",
  "LongHairCurvy",
  "LongHairDreads",
  "LongHairFrida",
  "LongHairFro",
  "LongHairFroBand",
  "LongHairNotTooLong",
  "LongHairShavedSides",
  "LongHairMiaWallace",
  "LongHairStraight",
  "LongHairStraight2",
  "LongHairStraightStrand",
  "ShortHairDreads01",
  "ShortHairDreads02",
  "ShortHairFrizzle",
  "ShortHairShaggyMullet",
  "ShortHairShortCurly",
  "ShortHairShortFlat",
  "ShortHairShortRound",
  "ShortHairShortWaved",
  "ShortHairSides",
  "ShortHairTheCaesar",
  "ShortHairTheCaesarSidePart",
] as const;

const accessoriesTypeOptions = [
  "Blank",
  "Kurt",
  "Prescription01",
  "Prescription02",
  "Round",
  "Sunglasses",
  "Wayfarers",
] as const;

const facialHairTypeOptions = [
  "Blank",
  "BeardMedium",
  "BeardLight",
  "BeardMagestic",
  "MoustacheFancy",
  "MoustacheMagnum",
] as const;

const facialHairColorOptions = [
  "Auburn",
  "Black",
  "Blonde",
  "BlondeGolden",
  "Brown",
  "BrownDark",
  "Platinum",
  "Red",
] as const;

const clotheTypeOptions = [
  "BlazerShirt",
  "BlazerSweater",
  "CollarSweater",
  "GraphicShirt",
  "Hoodie",
  "Overall",
  "ShirtCrewNeck",
  "ShirtScoopNeck",
  "ShirtVNeck",
] as const;

const eyeTypeOptions = [
  "Close",
  "Cry",
  "Default",
  "Dizzy",
  "EyeRoll",
  "Happy",
  "Hearts",
  "Side",
  "Squint",
  "Surprised",
  "Wink",
  "WinkWacky",
] as const;

const eyebrowTypeOptions = [
  "Angry",
  "AngryNatural",
  "Default",
  "DefaultNatural",
  "FlatNatural",
  "RaisedExcited",
  "RaisedExcitedNatural",
  "SadConcerned",
  "SadConcernedNatural",
  "UnibrowNatural",
  "UpDown",
  "UpDownNatural",
] as const;

const mouthTypeOptions = [
  "Concerned",
  "Default",
  "Disbelief",
  "Eating",
  "Grimace",
  "Sad",
  "ScreamOpen",
  "Serious",
  "Smile",
  "Tongue",
  "Twinkle",
  "Vomit",
] as const;

const skinColorOptions = [
  "Tanned",
  "Yellow",
  "Pale",
  "Light",
  "Brown",
  "DarkBrown",
  "Black",
] as const;

const hairColorTypes = [
  "Auburn",
  "Black",
  "Blonde",
  "BlondeGolden",
  "Brown",
  "BrownDark",
  "PastelPink",
  "Platinum",
  "Red",
  "SilverGray",
] as const;

const hatColorOptions = [
  "Black",
  "Blue01",
  "Blue02",
  "Blue03",
  "Gray01",
  "Gray02",
  "Heather",
  "PastelBlue",
  "PastelGreen",
  "PastelOrange",
  "PastelRed",
  "PastelYellow",
  "Pink",
  "Red",
  "White",
] as const;

const clotheColorOptions = [
  "Black",
  "Blue01",
  "Blue02",
  "Blue03",
  "Gray01",
  "Gray02",
  "Heather",
  "PastelBlue",
  "PastelGreen",
  "PastelOrange",
  "PastelRed",
  "PastelYellow",
  "Pink",
  "Red",
  "White",
] as const;

export const generateRandomAvatar = (): string => {
  const accessoriesType = getRandomArrayElement(accessoriesTypeOptions);
  const clotheColor = getRandomArrayElement(clotheColorOptions);
  const clotheType = getRandomArrayElement(clotheTypeOptions);
  const eyeType = getRandomArrayElement(eyeTypeOptions);
  const eyebrowType = getRandomArrayElement(eyebrowTypeOptions);
  const facialHairColor = getRandomArrayElement(facialHairColorOptions);
  const facialHairType = getRandomArrayElement(facialHairTypeOptions);
  const hairColor = getRandomArrayElement(hairColorTypes);
  const hatColor = getRandomArrayElement(hatColorOptions);
  const mouthType = getRandomArrayElement(mouthTypeOptions);
  const skinColor = getRandomArrayElement(skinColorOptions);
  const topType = getRandomArrayElement(topTypeOptions);

  return `https://avataaars.io/?avatarStyle=Transparent&accessoriesType=${accessoriesType}&avatarStyle=Circle&clotheColor=${clotheColor}&clotheType=${clotheType}&eyeType=${eyeType}&eyebrowType=${eyebrowType}&facialHairColor=${facialHairColor}&facialHairType=${facialHairType}&hairColor=${hairColor}&hatColor=${hatColor}&mouthType=${mouthType}&skinColor=${skinColor}&topType=${topType}`;
};
