/* eslint-disable camelcase */
import { AppLanguage, HistoryItemEntity, ItemEntity } from "data/utils/types";
import { RefObject } from "react";

import { SelectOption } from "./generics";
import { BaseItem } from "./types";

export const scrollToRef = <T extends HTMLElement>(
  ref: RefObject<T>,
  options: ScrollIntoViewOptions = {
    behavior: "smooth",
    block: "start",
    inline: "nearest",
  }
): void => {
  ref.current?.scrollIntoView(options);
};

export const idGenerator = (): string =>
  `l${Math.random().toString(36).substr(2, 9)}`;

export const createOptions = (items?: BaseItem[] | null): SelectOption[] => {
  if (!items) return [];
  return items.map((item) => ({ label: item.name, value: String(item.id) }));
};

export const getRandomArrayElement = <T>(arr: readonly T[]): T =>
  arr[Math.floor(Math.random() * arr.length)];

export const toSelectOption = (item: BaseItem | null): SelectOption | null => {
  if (!item) return null;
  return {
    label: item.name,
    value: String(item.id),
  };
};

export const capitalize = (str: string): string =>
  str
    .split(" ")
    .map((word) => word[0].toUpperCase() + word.slice(1))
    .join(" ");

export const flatifySelectOptions = (
  values: Record<
    string,
    string | number | SelectOption | boolean | null | undefined
  >
): Record<string, string | number | boolean | null | undefined> =>
  Object.entries(values).reduce((acc, [key, val]) => {
    if (typeof val === "object" && val !== null && val.value) {
      if (!Number.isNaN(val.value)) {
        return { ...acc, [key]: Number(val.value) };
      }
      return { ...acc, [key]: val.value };
    }
    if (key.toLowerCase().includes("id") && !Number.isNaN(Number(val))) {
      return { ...acc, [key]: Number(val) };
    }
    return { ...acc, [key]: val };
  }, {});

export const getHistoryItemTitle = (
  history: HistoryItemEntity,
  language?: AppLanguage | null
): string | undefined => {
  if (!history) return "";
  if (language) {
    const translation = history.item.titleMap[language];
    if (translation) return translation;
  }
  return history.item.title;
};

export const getItemTitle = (
  item?: ItemEntity | null,
  language?: AppLanguage | null
): string | undefined => {
  if (!item) return "";
  if (language) {
    const translation = item.titleMap[language];
    if (translation) return translation;
  }
  return item.title;
};

export const formatHistoryItemAge = (
  seconds: number
): { short: string; full: string } => {
  const fullMinutes = Math.floor(seconds / 60);
  if (fullMinutes === 0)
    return { short: `${seconds} s`, full: `${seconds} second(s)` };

  if (fullMinutes < 60)
    return { short: `${fullMinutes} m`, full: `${fullMinutes} minute(s)` };

  const fullHours = Math.floor(fullMinutes / 60);

  if (fullHours < 96)
    return { short: `${fullHours} h`, full: `${fullHours} hour(s)` };

  const fullDays = Math.floor(fullHours / 24);

  return { short: `${fullDays} d`, full: `${fullDays} day(s)` };
};
