import React from "react";

export type ViewportContextProviderType = {
  isMobile?: boolean;
  isTablet?: boolean;
  isSmallDesktop?: boolean;
  isDesktop?: boolean;
};

const ViewportContext = React.createContext<ViewportContextProviderType>({});

export default ViewportContext;
