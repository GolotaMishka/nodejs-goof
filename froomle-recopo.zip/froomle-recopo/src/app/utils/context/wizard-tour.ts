import React, { Dispatch, ReactElement, SetStateAction } from "react";

export type WizardFormContextProviderType = {
  steps: ReactElement[];
  step: number;
  setStep: Dispatch<SetStateAction<number>>;
  setMeta: Dispatch<SetStateAction<Record<string, unknown>>>;
};

export const defaultContext: WizardFormContextProviderType = {
  steps: [],
  step: 0,
  setStep: () => null,
  setMeta: () => null,
};

const WizardFormContext = React.createContext<WizardFormContextProviderType>(
  defaultContext
);

export default WizardFormContext;
