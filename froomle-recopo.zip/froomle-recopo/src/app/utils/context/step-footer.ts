import React, { Dispatch, SetStateAction } from "react";

type PathFuncType = (...args: (string | number)[]) => string;

export type StepFooterStateType = {
  hasStepFooter: boolean;
  nextPagePath?: PathFuncType | null;
  nextStepTitle?: string;
  nextStepDisabled?: boolean;
  prevPagePath?: PathFuncType | null;
  prevStepTitle?: string;
};

export type StepFooterProviderType = {
  stepFooterState: StepFooterStateType;
  setStepFooterState: Dispatch<SetStateAction<StepFooterStateType>>;
};

export const defaultState: StepFooterStateType = {
  hasStepFooter: false,
  nextPagePath: null,
  nextStepTitle: "",
  nextStepDisabled: false,
  prevPagePath: null,
  prevStepTitle: "",
};

export const defaultValue: StepFooterProviderType = {
  stepFooterState: defaultState,
  setStepFooterState: () => defaultState,
};

const StepFooterContext = React.createContext<StepFooterProviderType>(
  defaultValue
);

export default StepFooterContext;
