import React, { Dispatch, SetStateAction } from "react";

type TourContextProviderType = {
  goToNextStep?: () => void;
  goToStep?: Dispatch<SetStateAction<number>>;
  isOpen?: boolean;
  currentStep?: number;
  isFinished?: () => boolean;
  start?: () => void;
};

const TourContext = React.createContext<TourContextProviderType>({});

export default TourContext;
