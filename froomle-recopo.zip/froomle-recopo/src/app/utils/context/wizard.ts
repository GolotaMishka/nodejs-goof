import { WizardMetaType } from "app/utils/types";
import React, { Dispatch, SetStateAction } from "react";
import {
  personasPath,
  recommendationsPath,
  templatesPath,
} from "app/constants/url";

export type WizardContextProviderType = {
  steps: ((...args: string[]) => string)[];
  step: number;
  setStep: Dispatch<SetStateAction<number>>;
  meta: WizardMetaType;
  setMeta: Dispatch<SetStateAction<Record<string, unknown>>>;
};

export const defaultContext: WizardContextProviderType = {
  steps: [personasPath, templatesPath, recommendationsPath],
  step: 0,
  setStep: () => null,
  meta: {},
  setMeta: () => null,
};

const WizardContext = React.createContext<WizardContextProviderType>(
  defaultContext
);

export default WizardContext;
