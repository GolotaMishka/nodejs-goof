import {
  BenchMarkType,
  CreationStep,
  EventIntegrationType,
  Industry,
  IntegrationLocation,
  ItemIntegrationType,
  ModuleConstraints,
  PageType,
  PlanType,
  RecommendationIntegrationType,
} from "data";

export type History = {
  item: string;
  value: boolean;
}[];

export type WizardMetaType = {
  onPrevHandler?: () => void;
  isEnabled?: boolean;
};

export type ParamsType = {
  companyId: string;
  envId: string;
};

export type RecommendationParamsType = {
  companyId: string;
  envId: string;
  templateId: string;
};

export type Recommendation = {
  img: string;
  title: string;
  link: string;
};

export type Persona = {
  name?: string;
  type?: string;
  subtitle?: string;
  history: History;
  id?: string;
  recommendations?: Recommendation[];
};

export type BaseItem = {
  name: string;
  id: string;
  [key: string]: any;
};

export type SignUpFormValues = {
  firstName: string | null;
  lastName: string | null;
  email: string | null;
  password: string | null;
  repeatPassword: string | null;
};

export type SignInFormValues = {
  email: string | null;
  password: string | null;
};

export type SignInByCodeFormValues = {
  code: string | null;
  redirectUri: string;
};

export type ForgotPassFormValues = {
  email?: string;
};

export type InviteFormValues = {
  email: string;
  roleIds: string[];
  step?: CreationStep | null;
};

export type GeneralInfoValues = {
  name: string;
  industry: Industry;
  planType?: PlanType;
  monthlyPageViews: string;
  monthlyRevenue?: string;
  brands?: string[];
};

export type ModulePlacementValues = {
  pageType: PageType;
  position: string;
};

export type ModuleInfoValues = {
  label: string;
  placement: ModulePlacementValues;
  module: string;
};

export type BusinessInfoValues = {
  objectives: string;
  shouldCompare: boolean;
  benchmarkType?: BenchMarkType;
  benchmarkBaseline?: string;
  remarks?: string;
  modules?: ModuleInfoValues[];
};

export type IntegrationInfoValues = {
  itemIntegrationType: ItemIntegrationType;
  eventIntegrationType: EventIntegrationType;
  recommendationIntegrationType: RecommendationIntegrationType;
  eventSdkFramework?: string;
  recommendationSdkFramework?: string;
  recommendationIntegrationLocation?: IntegrationLocation;
  serverLocation?: string;
  metadata?: string;
  otherInfo?: string;
  constraints?: ModuleConstraints;
  environments?: string[];
};

export type AddressValues = {
  address1: string;
  address2?: string;
  postalCode: string;
  region: string;
  country: string;
  city: string;
};

export type PersonValues = {
  firstName: string;
  lastName: string;
  email: string;
};

export type BillingInfoValues = {
  legalName: string;
  vatNumber: string;
  poReferences?: string[];
  billingAddress: AddressValues;
  billingPerson: PersonValues;
};

export type DateInfo = {
  activatedAt?: Date | boolean;
  trialStartsAt?: Date | boolean;
};

export type EnvironmentValues = {
  name: string;
  displayName: string;
};

export type CompanyDetailValues = {
  environments?: EnvironmentValues[];
  logo?: string;
  generalInfo?: GeneralInfoValues;
  businessInfo?: BusinessInfoValues;
  billingInfo?: BillingInfoValues;
  integrationInfo?: IntegrationInfoValues;
  dateInfo?: DateInfo;
  modules?: ModuleInfoValues[];
  isDemo?: string;
};
