import ForgotPass from "app/components/routes/forgot-pass";
import { ForgotPassFormValues } from "app/utils/types";
import { useRequestPassword, validationSchemas } from "data";
import { Formik } from "formik";
import React, { ReactElement } from "react";

export const ForgotPassContainer = (): ReactElement => {
  const {
    mutate: requestPassword,
    isSuccess,
    isLoading,
  } = useRequestPassword();
  const initialValues: ForgotPassFormValues = {
    email: "",
  };

  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchemas.ForgotPassSchema}
      onSubmit={(values) => requestPassword(values)}
    >
      {(formikProps) => (
        <ForgotPass
          {...formikProps}
          isSuccess={isSuccess}
          isLoading={isLoading}
        />
      )}
    </Formik>
  );
};
