import SignIn from "app/components/routes/sign-in-new";
import {
  companiesPath,
  companyWizardPath,
  completeSignUpPath,
} from "app/constants/url";
import {
  useAcceptInvite,
  useAuth,
  useInvite,
  useLogin,
  useLoginByCode,
  usePingApis,
  UserEntity,
  validationSchemas,
} from "data";
import { Formik } from "formik";
import React, { ReactElement, useEffect, useState } from "react";
import { Redirect, useHistory } from "react-router-dom";

export type SignInFormValues = {
  email: string | null;
  password: string | null;
};

const SignInContainer = (): ReactElement => {
  const history = useHistory();
  let params = new URLSearchParams(window.location.search);
  const auth0InviteId = params.get("invitation");
  const { mutate: login, isLoading } = useLogin();
  const { mutate: loginByCode, isLoading: codeLoading } = useLoginByCode();
  const { isAuthenticated, user } = useAuth();
  const { data: invite } = useInvite(auth0InviteId);

  const [linked, setLinked] = useState<string | undefined>();
  const {
    mutateAsync: acceptInvite,
    isLoading: acceptIsLoading,
  } = useAcceptInvite();
  usePingApis();

  const loginCallback = async (data?: UserEntity) => {
    if (data?.linked) {
      setLinked(data?.linked);
      localStorage.clear();
      sessionStorage.clear();
      return;
    }

    if (!invite?.id) return;
    await acceptInvite(invite?.id);

    if (invite?.step && invite?.company)
      history.push(companyWizardPath(invite.company.id, invite.step));
  };

  useEffect(() => {
    params = new URLSearchParams(window.location.search);
    const code = params.get("code");
    if (code) {
      loginByCode(
        { code, redirectUri: window.location.origin },
        { onSuccess: loginCallback }
      );
    }
  }, []);

  if (isAuthenticated && !acceptIsLoading && !codeLoading && !linked)
    return (
      <Redirect
        to={
          user?.email_verified
            ? companiesPath
            : { pathname: completeSignUpPath, search: window.location.search }
        }
      />
    );

  const initialValues: SignInFormValues = {
    email: invite?.email ?? null,
    password: "",
  };

  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchemas.SignInNewSchema}
      onSubmit={(values) =>
        login(values, {
          onSuccess: () => loginCallback(),
        })
      }
    >
      {(formikProps) => (
        <SignIn
          {...formikProps}
          isLoading={isLoading || acceptIsLoading || codeLoading || !!linked}
          invitation={invite}
          linked={linked}
        />
      )}
    </Formik>
  );
};

export default SignInContainer;
