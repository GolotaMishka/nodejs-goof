import PageLoader from "app/components/core/loader";
import PublicLayout from "app/components/core/public-layout";
import {
  completeSignUpPath,
  forgotPasswordPath,
  signInPath,
  signUpPath,
} from "app/constants/url";
import { useInvite } from "data";
import React, { ReactElement } from "react";
import { Redirect, Route, Switch } from "react-router-dom";
import { CompleteSignupContainer } from "./complete-signup";
import { ForgotPassContainer } from "./forgot-pass";

import SignInContainer from "./sign-in";
import SignUpContainer from "./sign-up";

const SharedContainer = (): ReactElement => {
  const params = new URLSearchParams(window.location.search);
  const inviteId = params.get("invitation");

  const { data: invite } = useInvite(inviteId);

  if (!invite && inviteId) {
    return <PageLoader />;
  }

  return (
    <PublicLayout>
      <Switch>
        <Route path={signInPath} component={SignInContainer} />
        <Route path={signUpPath} component={SignUpContainer} />
        <Route
          exact
          path={forgotPasswordPath}
          component={ForgotPassContainer}
        />
        <Route
          exact
          path={completeSignUpPath}
          component={CompleteSignupContainer}
        />
        <Redirect
          to={{
            pathname:
              invite?.existingUser || !inviteId ? signInPath : signUpPath,
            search: window.location.search,
          }}
        />
      </Switch>
    </PublicLayout>
  );
};

export default SharedContainer;
