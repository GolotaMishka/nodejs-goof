import { CompleteSignup } from "app/components/routes/complete-signup";
import React, { ReactElement } from "react";

export const CompleteSignupContainer = (): ReactElement => {
  return <CompleteSignup />;
};
