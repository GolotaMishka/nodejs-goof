import React, { ReactElement, useEffect, useState } from "react";
import SignUp from "app/components/routes/sign-up";
import { Formik } from "formik";
import {
  useAuth,
  useInvite,
  useLoginByCode,
  useRegister,
  useRegisterFromInvite,
  UserEntity,
  validationSchemas,
} from "data";
import { SignUpFormValues } from "app/utils/types";
import { Redirect } from "react-router-dom";
import {
  companiesPath,
  companyWizardPath,
  completeSignUpPath,
} from "app/constants/url";

const SignUpContainer = (): ReactElement => {
  const { mutate: register, isLoading: isRegisterLoading } = useRegister();

  const { mutate: loginByCode } = useLoginByCode();
  const { isAuthenticated, user } = useAuth();

  let params = new URLSearchParams(window.location.search);
  const inviteId = params.get("invitation");

  const { data: invite } = useInvite(inviteId);
  const [linked, setLinked] = useState<string | undefined>();

  const loginCallback = async (data?: UserEntity) => {
    if (data?.linked) {
      setLinked(data?.linked);
      localStorage.clear();
      sessionStorage.clear();
    }
  };
  const {
    mutate: registerFromInvite,
    isLoading: isRegisterFromInviteLoading,
  } = useRegisterFromInvite(invite?.id);

  useEffect(() => {
    params = new URLSearchParams(window.location.search);

    const code = params.get("code");
    if (code) {
      loginByCode(
        {
          code,
          redirectUri: window.location.origin,
        },
        { onSuccess: loginCallback }
      );
    }
  }, []);

  if (isAuthenticated && !linked) {
    if (invite?.step && user?.email_verified && invite.company)
      return (
        <Redirect to={companyWizardPath(invite.company.id, invite.step)} />
      );

    let completePath = completeSignUpPath;
    if (invite?.step) {
      const p = new URLSearchParams();
      p.append("companyId", invite.company?.id || "");
      p.append("step", invite.step);
      completePath = `${completeSignUpPath}?${p.toString()}`;
    }
    return (
      <Redirect to={user?.email_verified ? companiesPath : completePath} />
    );
  }
  const initialValues: SignUpFormValues = {
    firstName: "",
    lastName: "",
    email: invite?.email || "",
    password: "",
    repeatPassword: "",
  };
  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchemas.SignUpSchema}
      onSubmit={(values) =>
        invite ? registerFromInvite(values) : register(values)
      }
      enableReinitialize
    >
      {(formikProps) => (
        <SignUp
          {...formikProps}
          isLoading={
            isRegisterLoading || isRegisterFromInviteLoading || !!linked
          }
          invite={invite}
          linked={linked}
        />
      )}
    </Formik>
  );
};

export default SignUpContainer;
