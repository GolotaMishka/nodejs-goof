import React from "react";
import { hot } from "react-hot-loader/root";
import { Route, Switch } from "react-router-dom";
import { basePath, companiesPath } from "app/constants/url";
import PrivateRoute from "./app";
// import Home from "./public";
import SharedContainer from "./public";

const App = () => {
  return (
    <Switch>
      <Route path={companiesPath}>
        <PrivateRoute />
      </Route>
      <Route path={basePath}>
        <SharedContainer />
      </Route>
    </Switch>
  );
};

export default hot(App);
