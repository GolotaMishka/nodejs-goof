import CompaniesLayout from "app/components/core/companies-layout";
import { SkeletonLoader } from "app/components/core/loader";
import CompanyCreation from "app/components/routes/companyCreation";
import { companyWizardPath, portalPath } from "app/constants/url";
import { useAuth, useCompanyDetail, useRefresh } from "data";
import React, { ReactElement, useEffect } from "react";
import { Route, Switch, useParams } from "react-router-dom";
import { PortalRoute } from "../portalRoute";

const CompanyContainer = (): ReactElement => {
  const { companyId } = useParams<{ companyId: string }>();
  const { refreshToken, companyId: currentCompanyId } = useAuth();
  const {
    mutate: refresh,
    isLoading: refreshLoading,
    isSuccess,
  } = useRefresh();
  const { data } = useCompanyDetail(
    isSuccess || currentCompanyId === companyId ? companyId : undefined
  );
  useEffect(() => {
    if (currentCompanyId !== companyId && companyId)
      refresh({ token: refreshToken, companyId });
  }, [companyId]);

  if (refreshLoading || !data) return <SkeletonLoader />;

  return (
    <Switch>
      <Route path={companyWizardPath(":companyId", ":step")}>
        <CompaniesLayout>
          <CompanyCreation />
        </CompaniesLayout>
      </Route>
      <Route path={portalPath(":companyId", ":envId")}>
        <PortalRoute />
      </Route>
    </Switch>
  );
};

export default CompanyContainer;
