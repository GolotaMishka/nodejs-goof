import React, { ReactElement, useCallback, useEffect, useState } from "react";
import { RecommendationParamsType } from "app/utils/types";
import Recommendations, {
  FormValues,
} from "app/components/routes/recommendations";
import { useParams } from "react-router-dom";
import { Formik } from "formik";
import {
  PersonaEntity,
  useCreateRecommendation,
  useListCategories,
  useListHistoryItems,
  useListPersonas,
  useListTemplates,
  validationSchemas,
} from "data";
import { useDebounce } from "app/utils/hooks";
import PageLoader from "app/components/core/loader";

const RecommendationsContainer = (): ReactElement => {
  const { data: templates, isFetched: templatesLoaded } = useListTemplates();
  const { templateId } = useParams<RecommendationParamsType>();

  const currentTemplate = templates?.find(
    (template) => String(template.id) === templateId
  );

  const [contextItemSearch, setContextItemSearch] = useState("");

  const [orderByPopularity, setOrderByPopularity] = useState(true);

  const debouncedContextItemSearch = useDebounce(contextItemSearch);

  const { data: contextItems, isFetching } = useListHistoryItems(
    debouncedContextItemSearch,
    10,
    orderByPopularity
  );

  const { data: personas, isFetched: personasLoaded } = useListPersonas();

  const { data: categories } = useListCategories({
    enabled: !!currentTemplate?.hasContextCategory,
  });

  const {
    mutate: createRecommendation,
    data: currentRecommendation,
    isLoading: recommendationLoading,
    isIdle: recommendationIdle,
  } = useCreateRecommendation<FormValues>();

  const onFilterChange = (filter: string) => {
    setOrderByPopularity(filter === "Popular");
  };

  const onSubmit = useCallback(
    (values: Partial<FormValues>) => {
      const cleanValues: Record<string, unknown> = {};
      if (currentTemplate) {
        const { hasContextCategory, hasContextItem } = currentTemplate;
        if (hasContextItem) cleanValues.contextItem = values.contextItem;
        if (hasContextCategory)
          cleanValues.contextCategory = values.contextCategory?.value;

        createRecommendation(cleanValues);
      }
    },
    [currentTemplate]
  );

  useEffect(() => {
    if (
      currentTemplate &&
      !currentTemplate.hasContextCategory &&
      !currentTemplate.hasContextItem
    ) {
      createRecommendation({});
    }
  }, [currentTemplate]);

  if (!templatesLoaded || !personasLoaded) return <PageLoader />;

  return (
    <Formik
      initialValues={{
        contextCategory: null,
        contextItem: null,
        hasContextCategory: currentTemplate?.hasContextCategory,
        hasContextItem: currentTemplate?.hasContextItem,
      }}
      validationSchema={validationSchemas.RecommendationSchema}
      enableReinitialize
      onSubmit={onSubmit}
    >
      {(formikProps) => (
        <Recommendations
          categories={categories}
          currentTemplate={currentTemplate}
          onContextItemSearch={setContextItemSearch}
          isContextItemLoading={isFetching}
          contextItems={contextItems}
          currentRecommendation={currentRecommendation}
          recommendationLoading={recommendationLoading}
          recommendationIdle={recommendationIdle}
          personas={personas as PersonaEntity[]}
          onFilterChange={onFilterChange}
          {...formikProps}
        />
      )}
    </Formik>
  );
};

export default RecommendationsContainer;
