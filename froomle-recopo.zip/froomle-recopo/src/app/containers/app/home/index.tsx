import React, { ReactElement } from "react";
import Home from "app/components/routes/home";

const HomeContainer = (): ReactElement => {
  return <Home />;
};

export default HomeContainer;
