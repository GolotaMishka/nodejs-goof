import React, { ReactElement } from "react";
import Insights from "app/components/routes/insights";

const InsightsContainer = (): ReactElement => {
  return <Insights />;
};

export default InsightsContainer;
