import Settings from "app/components/routes/settings";
import React, { ReactElement } from "react";

const SettingsContainer = (): ReactElement => {
  return <Settings />;
};

export default SettingsContainer;
