import Footer from "app/components/core/footer";
import { companiesPath, signInPath } from "app/constants/url";
import { useAuth } from "data";
import React, { ReactElement } from "react";
import { Redirect, Route, Switch } from "react-router-dom";

import Companies from "./companies";

const PrivateRoute = (): ReactElement => {
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <Redirect to={signInPath} />;
  }
  return (
    <>
      <Switch>
        <Route path={companiesPath} component={Companies} />
        <Redirect to={companiesPath} />
      </Switch>
      <Footer />
    </>
  );
};

export default PrivateRoute;
