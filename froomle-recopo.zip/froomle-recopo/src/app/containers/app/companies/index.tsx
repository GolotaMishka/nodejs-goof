import CompaniesLayout from "app/components/core/companies-layout";
import { Companies } from "app/components/routes/companies";
import CompanyCreation from "app/components/routes/companyCreation";
import { companiesPath, companyCreation, companyPath } from "app/constants/url";
import React, { ReactElement } from "react";
import { Route, Switch } from "react-router-dom";
import CompanyContainer from "../company";

const CompaniesContainer = (): ReactElement => {
  return (
    <Switch>
      <Route exact path={companyCreation}>
        <CompaniesLayout>
          <CompanyCreation />
        </CompaniesLayout>
      </Route>
      <Route component={CompanyContainer} path={companyPath(":companyId")} />
      <Route path={companiesPath}>
        <CompaniesLayout>
          <Companies />
        </CompaniesLayout>
      </Route>
    </Switch>
  );
};

export default CompaniesContainer;
