import React, { ReactElement } from "react";
import Personas from "app/components/routes/personas";

const PersonasContainer = (): ReactElement => {
  return <Personas />;
};

export default PersonasContainer;
