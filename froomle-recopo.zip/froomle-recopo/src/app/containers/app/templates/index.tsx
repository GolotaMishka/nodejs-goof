import React, { ReactElement } from "react";
import Templates from "app/components/routes/templates";

const TemplatesContainer = (): ReactElement => {
  return <Templates />;
};

export default TemplatesContainer;
