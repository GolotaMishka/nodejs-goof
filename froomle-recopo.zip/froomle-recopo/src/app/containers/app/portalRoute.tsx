import WizardLayout from "app/components/core/wizard-layout";
import {
  homePath,
  insightsPath,
  personasPath,
  recommendationsPath,
  settingsPath,
  templatesPath,
} from "app/constants/url";
import ScrollToTop from "app/utils/scroll-to-top";
import { ParamsType } from "app/utils/types";
import { useAuth, useListEnvironments, useStore } from "data";
import React, { ReactElement, useEffect } from "react";
import { Route, Switch, useParams } from "react-router-dom";
import Home from "./home";
import Insights from "./insights";
import Personas from "./personas";
import Recommendations from "./recommendations";
import Templates from "./templates";
import Settings from "./settings";

export const PortalRoute = (): ReactElement => {
  const { envId } = useParams<ParamsType>();
  const { projectId } = useAuth();
  const { data: environments } = useListEnvironments(projectId!);
  const { setEnv } = useStore();

  useEffect(() => {
    if (envId && environments) {
      const newEnv = environments?.find((env) => String(env.id) === envId);
      if (newEnv) setEnv(newEnv);
    }
  }, [envId, environments]);

  return (
    <>
      <ScrollToTop />
      <WizardLayout>
        <Switch>
          <Route path={homePath(":companyId", ":envId")}>
            <Home />
          </Route>
          <Route path={personasPath(":companyId", ":envId")}>
            <Personas />
          </Route>
          <Route exact path={templatesPath(":companyId", ":envId")}>
            <Templates />
          </Route>
          <Route
            path={recommendationsPath(":companyId", ":envId", ":templateId")}
          >
            <Recommendations />
          </Route>
          <Route path={insightsPath(":companyId", ":envId")}>
            <Insights />
          </Route>
          <Route path={settingsPath(":companyId", ":envId")}>
            <Settings />
          </Route>
        </Switch>
      </WizardLayout>
    </>
  );
};
