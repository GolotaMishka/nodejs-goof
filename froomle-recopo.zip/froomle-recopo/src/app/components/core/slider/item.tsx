import React, { ReactElement, useEffect } from "react";
import { ButtonIcon, Icon, Text } from "ui";
import cx from "classnames";
import { ItemEntity } from "data";
import ReactTooltip from "react-tooltip";
import s from "./styles.scss";

interface IProps {
  item: ItemEntity;
  className?: string;
  hasContextItem: boolean;
  title: string;
  addItemToHistory: (item: ItemEntity) => void;
  setContextItem: (item: ItemEntity) => void;
}

const SliderItem = ({
  className,
  item,
  hasContextItem,
  title,
  addItemToHistory,
  setContextItem,
}: IProps): ReactElement => {
  const handleHistoryButtonClick = (
    event: React.MouseEvent<HTMLButtonElement, MouseEvent>
  ) => {
    event.preventDefault();
    event.stopPropagation();
    addItemToHistory(item);
  };

  const handleContextButtonClick = (
    event: React.MouseEvent<HTMLButtonElement, MouseEvent>
  ) => {
    event.preventDefault();
    event.stopPropagation();
    setContextItem(item);
  };

  useEffect(() => {
    return () => {
      ReactTooltip.hide();
    };
  }, []);

  return (
    <a
      href={item.uri}
      target="_blank"
      rel="noreferrer"
      className={cx(s.item, className)}
    >
      {item.images?.[0] && (
        <div className={s.itemImageWrapper}>
          <div className={s.itemOverlay}>
            <ButtonIcon
              type="button"
              icon={Icon.icons.bookmark}
              className={s.itemOverlayButton}
              data-for="button-tooltip"
              data-tip={JSON.stringify({ title: "Add to history" })}
              onClick={handleHistoryButtonClick}
            />
            <ButtonIcon
              type="button"
              icon={Icon.icons.home}
              className={cx(
                s.itemOverlayButton,
                !hasContextItem && s.itemOverlayButton_disabled
              )}
              data-for="button-tooltip"
              disabled={!hasContextItem}
              data-tip={JSON.stringify({ title: "Use as context item" })}
              onClick={handleContextButtonClick}
            />
          </div>
          <img className={s.itemImage} src={item.images[0]} alt={title} />
        </div>
      )}
      <div
        className={s.itemSection}
        data-tip={JSON.stringify({
          title,
          categories: item.categories,
        })}
        data-for="history-item-tooltip"
      >
        <Text component="p" color="dark" className={s.itemTitle}>
          {title}
        </Text>
      </div>
    </a>
  );
};

export default SliderItem;
