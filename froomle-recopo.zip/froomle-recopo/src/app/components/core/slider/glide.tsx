import "@glidejs/glide/dist/css/glide.core.min.css";

import React, { ReactElement, useEffect, useRef, useState } from "react";
import Glide from "@glidejs/glide";
import cx from "classnames";
import { ButtonIcon, Icon } from "ui";
import bp from "ui/styles/_breakpoints.scss";

import s from "./styles.scss";

type GlideType = "slider" | "carousel";

type Breakpoints = Record<number, Record<string, unknown>>;

type GliderProps = {
  type?: GlideType;
  startAt?: number;
  perView?: number;
  focusAt?: number | string;
  gap?: number;
  autoplay?: number | boolean;
  hoverPause?: boolean;
  keyboard?: boolean;
  bound?: boolean;
  swipeThreshold?: number | boolean;
  dragThreshold?: number | boolean;
  perTouch?: number | boolean;
  touchRatio?: number;
  touchAngle?: number;
  animationDuration?: number;
  rewind?: boolean;
  rewindDuration?: number;
  animationTimingFunc?: string;
  direction?: string;
  breakpoints?: Breakpoints;
  throttle?: number;
};

interface IProps {
  children: React.ReactNodeArray;
  className?: string;
}

const GlideComponent = ({ children, className }: IProps): ReactElement => {
  const glideRef = useRef<HTMLDivElement>(null);
  const [currentActive, setCurrentActive] = useState(0);
  const glideInstance = useRef<any>(null);

  const setIndex = () => {
    if (glideInstance.current) {
      setCurrentActive(glideInstance.current?.index);
    }
  };

  useEffect(() => {
    const numberOfSlides = children.length;

    const defaultOptions: GliderProps = {
      perView: Math.min(5, numberOfSlides),
      bound: true,
      rewind: false,
      gap: 8,
      keyboard: false,
      breakpoints: {
        [parseInt(bp.hugeScreen, 10)]: {
          perView: Math.min(4, numberOfSlides),
        },
        [parseInt(bp.desktop, 10)]: {
          perView: Math.min(3, numberOfSlides),
        },
        [parseInt(bp.smallDesktop, 10)]: {
          perView: Math.min(2, numberOfSlides),
        },
      },
    };

    const glide = new Glide(glideRef.current, defaultOptions);

    glideInstance.current = glide;

    glide.mount();

    glide.on("run", setIndex);

    return () => glide.destroy();
  }, []);

  return (
    <div className={className}>
      <ButtonIcon
        type="button"
        icon={Icon.icons.chevronLeft}
        className={cx(s.glideButton, s.glideButton_left)}
        onClick={() => glideInstance.current?.go("|<")}
        disabled={currentActive === 0}
      />
      <div className={s.glideContainer}>
        <div ref={glideRef} className={cx(s.glide, "glide")}>
          <div className="glide__track" data-glide-el="track">
            <ul className="glide__slides">
              {children.map((slide: ReactElement, index: number) => (
                <li key={`glide_slide_${index + 1}`} className="glide__slide">
                  {slide}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
      <ButtonIcon
        icon={Icon.icons.chevronRight}
        type="button"
        className={cx(s.glideButton, s.glideButton_right)}
        disabled={
          currentActive ===
          children.length - glideInstance.current?.settings?.perView
        }
        onClick={() => glideInstance.current?.go("|>")}
      />
    </div>
  );
};

export default GlideComponent;
