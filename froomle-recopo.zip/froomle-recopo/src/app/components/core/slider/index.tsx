import React, { ReactElement } from "react";
import { useBreakpoints } from "data/hooks/breakpoints";
import cx from "classnames";
import { ItemEntity, useStore } from "data";
import { Text } from "ui";
import { getItemTitle, idGenerator } from "app/utils";
import sliderItemAnimationData from "public/animations/slider-item.json";
import Glide from "./glide";
import SliderItem from "./item";
import Lottie from "../lottie";
import s from "./styles.scss";

interface IProps {
  media: ItemEntity[];
  className?: string;
  isLoading: boolean;
  hasContextItem: boolean;
  setContextItem: (item: ItemEntity) => void;
  addItemToHistory: (item: ItemEntity) => void;
}

const Slider = ({
  media,
  className,
  isLoading = false,
  hasContextItem,
  addItemToHistory,
  setContextItem,
}: IProps): ReactElement => {
  const { isMobile } = useBreakpoints();

  const { template, env } = useStore();

  if (!isLoading && media.length === 0)
    return <Text>There are no recommendations available</Text>;

  const Component = isMobile ? "div" : Glide;

  const items = isLoading
    ? [...Array(20)].map(() => (
        <div className={s.sliderItem} key={idGenerator()}>
          <Lottie animationData={sliderItemAnimationData} />
        </div>
      ))
    : media?.map((item) => {
        const title = getItemTitle(item, template?.language || env?.language);
        return (
          <SliderItem
            key={`slider_item_${
              item.id || item.froomleItemId || item.clientItemId
            }`}
            className={s.sliderItem}
            hasContextItem={hasContextItem}
            title={title as string}
            item={item}
            addItemToHistory={addItemToHistory}
            setContextItem={setContextItem}
          />
        );
      });

  return <Component className={cx(s.slider, className)}>{items}</Component>;
};

export default Slider;
