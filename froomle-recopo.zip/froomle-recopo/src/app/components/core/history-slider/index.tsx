import React, {
  ChangeEvent,
  ReactElement,
  useCallback,
  useRef,
  useEffect,
  useState,
} from "react";
import { getHistoryItemTitle, formatHistoryItemAge } from "app/utils/helpers";
import cx from "classnames";
import ReactTooltip from "react-tooltip";
import { Checkbox } from "ui";
import Slider from "app/components/core/slider-new";
import { HistoryItemEntity, useStore, useUpdateHistoryItem } from "data";
import { idGenerator } from "@panenco/ui";
import TimePicker from "./time-picker";
import s from "./styles.scss";

interface IProps {
  personaId: string;
  className?: string;
  items: HistoryItemEntity[];
}

type TimePickerStateType = {
  isOpened: boolean;
  historyItem: HistoryItemEntity | null;
};

const timePickerWidth = 137;
const timePickerTopMargin = 4;

const HistorySlider = ({
  items,
  personaId,
  className,
}: IProps): ReactElement => {
  const { env, template } = useStore();
  const timeStampsRef = useRef<(HTMLButtonElement | null)[]>([]);

  const [timePickerState, setTimePickerState] = useState<TimePickerStateType>({
    isOpened: false,
    historyItem: null,
  });

  useEffect(() => {
    ReactTooltip.rebuild();
  }, []);

  const { mutate: updateHistoryItem } = useUpdateHistoryItem();

  const handleCheckboxChange = (itemId: string) => (
    e: ChangeEvent<HTMLInputElement>
  ) => {
    const values = { isEnabled: e.target.checked };
    updateHistoryItem({ itemId, personaId, values });
  };

  const handleItemAgeChange = (age: number) => {
    const itemId = timePickerState.historyItem?.itemId;
    if (itemId) {
      const values = { secondsAgo: age };
      updateHistoryItem({ itemId, personaId, values });
    }
  };

  const openTimepicker = (historyItem: HistoryItemEntity) => (): void => {
    setTimePickerState({ isOpened: true, historyItem });
    ReactTooltip.hide();
  };

  const closeTimepicker = (): void => {
    setTimePickerState({ isOpened: false, historyItem: null });
  };

  const getTimePickerPositionValues = useCallback((): {
    top?: number;
    left?: number;
  } => {
    const itemIndex = items.findIndex(
      ({ itemId }) => itemId === timePickerState.historyItem?.itemId
    );

    const clickedTimeStampElement = timeStampsRef.current[itemIndex];

    if (!clickedTimeStampElement) return {};

    const rect = clickedTimeStampElement.getBoundingClientRect();

    return {
      top: rect.bottom + window.scrollY + timePickerTopMargin,
      left: rect.right + window.scrollX - timePickerWidth,
    };
  }, [items, timePickerState, timeStampsRef]);

  return (
    <>
      {timePickerState.isOpened && (
        <TimePicker
          onClose={closeTimepicker}
          style={{
            position: "absolute",
            width: timePickerWidth,
            ...getTimePickerPositionValues(),
          }}
          submitCallback={handleItemAgeChange}
        />
      )}
      <Slider className={className}>
        {items.map((historyItem, i) => {
          const { images, uri } = historyItem.item;

          const title = getHistoryItemTitle(
            historyItem,
            template?.language || env?.language
          );

          const img = historyItem.item.images?.[0];

          const {
            short: itemAgeShort,
            full: itemAgeFull,
          } = formatHistoryItemAge(historyItem.secondsAgo);

          return (
            <div
              key={idGenerator()}
              className={cx(
                s.historyItem,
                !historyItem.isEnabled && s.historyItem_disabled
              )}
            >
              {images?.[0] && (
                <div className={s.historyItemImageWrapper}>
                  <img
                    className={s.historyItemImage}
                    src={images[0]}
                    alt={title}
                  />
                </div>
              )}
              <div className={s.historyItemButtons}>
                <Checkbox
                  checked={historyItem.isEnabled}
                  onChange={handleCheckboxChange(historyItem.itemId as string)}
                  wrapperProps={{
                    className: s.historyItemCheckbox,
                    "data-tip": JSON.stringify({
                      title: historyItem.isEnabled
                        ? "Disable item"
                        : "Enable item",
                    }),
                    "data-for": "button-tooltip",
                  }}
                />
                <button
                  className={s.historyItemAgeButton}
                  data-tip={JSON.stringify({
                    title: `Viewed ${itemAgeFull} ago`,
                  })}
                  data-for="button-tooltip"
                  onClick={openTimepicker(historyItem)}
                  ref={(el) => {
                    timeStampsRef.current[i] = el;
                  }}
                >
                  {itemAgeShort}
                </button>
              </div>
              <a
                className={s.historyItemTitle}
                href={uri}
                target="_blank"
                rel="noreferrer"
                data-tip={JSON.stringify({
                  img,
                  title,
                  categories: historyItem.item.categories,
                })}
                data-for="history-item-tooltip"
              >
                {title}
              </a>
            </div>
          );
        })}
      </Slider>
    </>
  );
};

export default HistorySlider;
