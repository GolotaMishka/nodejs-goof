/* eslint-disable jsx-a11y/label-has-associated-control */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
import React, {
  ChangeEvent,
  ReactElement,
  useEffect,
  useRef,
  useState,
} from "react";
import { SelectOption } from "app/utils/generics";
import { idGenerator } from "app/utils/helpers";
import { createPortal } from "react-dom";
import { TextInput, Text, Icon, ButtonIcon, AppThemeType, useTheme } from "ui";
import { useOutsideClick } from "app/utils/hooks";
import s from "./styles.scss";

const options: SelectOption<number>[] = [
  { label: "1 min", value: 60 },
  { label: "60 min", value: 60 * 60 },
  { label: "1 day", value: 24 * 60 * 60 },
  { label: "10 days", value: 10 * 24 * 60 * 60 },
  { label: "60 days", value: 60 * 24 * 60 * 60 },
];

const formatInputValueToSeconds = (inputValue: string): number => {
  return Math.floor(60 * parseFloat(inputValue));
};

interface IProps extends React.HTMLAttributes<HTMLDivElement> {
  submitCallback: (num: number) => void;
  onClose: () => void;
}

const root = document.getElementById("menu-root") as HTMLElement;

const TimePicker = ({
  submitCallback,
  onClose,
  ...props
}: IProps): ReactElement => {
  const theme: AppThemeType = useTheme();
  const ref = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [inputValue, setInputValue] = useState<string>("");

  const isValid = !Number.isNaN(parseFloat(inputValue));

  const handleSubmit = (numberOfSeconds?: number) => () => {
    const val = numberOfSeconds || formatInputValueToSeconds(inputValue);
    submitCallback(Number(val));
    onClose();
  };

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };

  useOutsideClick(ref, onClose);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && isValid) {
      handleSubmit()();
    }
  };

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  return createPortal(
    <div ref={ref} className={s.picker} {...props}>
      <div className={s.pickerHeader}>
        <label className={s.pickerInputLabel}>
          <TextInput
            inputRef={inputRef}
            value={inputValue}
            onChange={handleInputChange}
            type="number"
            step={1}
            min={1}
            placeholder="00"
            id="timepicker-input"
            wrapperProps={{ className: s.pickerInput }}
            style={{
              width: `calc(${inputValue.length}ch + 2px)`,
              minWidth: "calc(2ch + 2px)",
              maxWidth: 70,
            }}
            onKeyDown={handleKeyDown}
          />
          <Text size="s" color="secondary">
            min
          </Text>
        </label>

        {isValid && (
          <ButtonIcon
            type="button"
            icon={Icon.icons.plus}
            color={theme.colors.secondary}
            className={s.pickerSubmit}
            onClick={handleSubmit()}
          />
        )}
      </div>
      <ul className={s.pickerList}>
        {options.map((option) => (
          <li
            key={idGenerator()}
            onClick={handleSubmit(option.value)}
            className={s.pickerListItem}
          >
            <Text size="s" color="primary">
              {option.label}
            </Text>
          </li>
        ))}
      </ul>
    </div>,
    root
  );
};

export default TimePicker;
