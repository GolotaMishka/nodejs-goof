import React, { ReactElement, useContext } from "react";
import { useBreakpoints } from "data/hooks/breakpoints";
import { Button, Icon, PrimaryButton } from "ui";
import StepFooterContext from "app/utils/context/step-footer";
import { useAuth, useStore } from "data";
import cx from "classnames";
import s from "./styles.scss";

const StepFooter = (): ReactElement | null => {
  const { isMobile } = useBreakpoints();
  const { env, template } = useStore();
  const { companyId } = useAuth();

  const {
    stepFooterState: {
      hasStepFooter,
      nextPagePath,
      nextStepDisabled,
      nextStepTitle,
      prevPagePath,
      prevStepTitle,
    },
  } = useContext(StepFooterContext);

  if (!hasStepFooter) return null;

  return (
    <nav className={s.nav}>
      {prevPagePath && (
        <Button
          variant="transparent"
          component="link"
          to={prevPagePath(
            companyId!,
            env?.id as string,
            template?.id as string
          )}
          iconLeft={Icon.icons.chevronLeft}
        >
          {isMobile ? "Back" : prevStepTitle}
        </Button>
      )}
      {nextPagePath && (
        <PrimaryButton
          className={cx(
            s.navNextButton,
            nextStepDisabled && s.navNextButton_disabled
          )}
          component="link"
          to={nextPagePath(
            companyId!,
            env?.id as string,
            template?.id as string
          )}
          data-cy="next-button"
        >
          {nextStepTitle}
        </PrimaryButton>
      )}
    </nav>
  );
};

export default StepFooter;
