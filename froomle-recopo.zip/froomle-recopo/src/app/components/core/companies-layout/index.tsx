import React, { ReactElement } from "react";
import StepFooter from "app/components/core/step-footer";
import cx from "classnames";
import Header from "app/components/core/header";
import s from "./styles.scss";

const CompaniesLayout: React.FC = ({ children }): ReactElement => {
  return (
    <div className={s.layout}>
      <Header />
      <div className={cx(s.page, s.page_gutter)}>{children}</div>
      <StepFooter />
    </div>
  );
};

export default CompaniesLayout;
