import React, {
  ChangeEvent,
  HTMLAttributes,
  ReactElement,
  useMemo,
  useState,
} from "react";
import cx from "classnames";
import { idGenerator } from "app/utils";
import { Text, Chip } from "ui";
import s from "./styles.scss";

export interface ChipsInputProps {
  inputProps?: HTMLAttributes<HTMLInputElement>;
  separator?: string;
  onChange: (chips: string[]) => void;
  value: string[];
  title?: string | ReactElement;
  error?: string;
  className?: string;
}

export const ChipsInput = ({
  inputProps = {},
  value: chips,
  title,
  separator = ",",
  onChange,
  error,
  className,
}: ChipsInputProps): ReactElement => {
  const [inputValue, setInputValue] = useState("");

  const inputId = useMemo(() => {
    if (inputProps.id) return inputProps.id;
    return idGenerator();
  }, [inputProps?.id]);

  const addChip = (chip: string) => {
    onChange([...chips, chip.trim()]);
  };

  const removeChip = (i: number) => {
    onChange(chips.filter((_, chipIndex) => chipIndex !== i));
  };

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;

    if (value.includes(separator)) {
      // add chip if separator added
      const newChips = [...chips, value.substring(0, value.length - 1)];

      onChange(newChips);
      setInputValue("");
    } else {
      setInputValue(value);
    }
  };

  const renderTitle = () => {
    if (!title) return null;
    if (React.isValidElement(title)) return title;
    return (
      <Text
        component="span"
        weight="bold"
        color="primary"
        size="m"
        style={{ marginBottom: 4 }}
      >
        {title}
      </Text>
    );
  };

  const handleBlur = () => {
    if (inputValue.trim()) {
      addChip(inputValue);
      setInputValue("");
    }
  };

  const handlechipInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (["Enter", separator].includes(e.key)) {
      // prevent form submission
      e.preventDefault();
      if (inputValue.trim()) {
        // add new chip and clear input
        addChip(inputValue);
        setInputValue("");
      }
    } else if (e.key === "Backspace") {
      // if input is empty - remove last chip
      if (!inputValue) {
        removeChip(chips.length - 1);
      }
    }
  };

  return (
    <div className={cx(s.wrap, className)}>
      {renderTitle()}
      <label
        htmlFor={inputId}
        className={cx(s.inputLabel, error && s.input_error)}
      >
        {chips.map((chip, i) => (
          <Chip
            checked
            className={s.inputChip}
            key={`chip-${i + 1}`}
            onClick={() => removeChip(i)}
          >
            {chip}
          </Chip>
        ))}
        <input
          {...inputProps}
          value={inputValue}
          onChange={handleInputChange}
          className={cx(
            s.input,
            chips.length > 0 && s.input_placeholderHidden,
            inputProps?.className
          )}
          onKeyDown={handlechipInputKeyDown}
          onBlur={handleBlur}
          id={inputId}
        />
      </label>
      {error && (
        <Text size="xs" color="error">
          {error}
        </Text>
      )}
    </div>
  );
};
