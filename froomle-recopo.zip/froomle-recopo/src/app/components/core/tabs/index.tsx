import React, { useState } from "react";
import cx from "classnames";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import { Text } from "ui";

import s from "./styles.scss";

interface IProps {
  children: React.ReactNode;
  tabs: string[];
  className?: string;
}

const CustomTabs: React.FC<IProps> = ({
  children,
  tabs,
  className,
  ...props
}) => {
  const [activeTab, setActiveTab] = useState(0);

  return (
    <Tabs
      selectedIndex={activeTab}
      onSelect={setActiveTab}
      className={className}
      {...props}
    >
      <TabList className={s.list}>
        {tabs.map((tab, i) => (
          <Tab
            key={`tab_${tab}_${i + 1}`}
            className={cx(s.tab, { [s.tab_active]: i === activeTab })}
            style={{ width: `${100 / tabs.length}%` }}
          >
            <Text weight="bold">{tab}</Text>
          </Tab>
        ))}
      </TabList>
      {children}
    </Tabs>
  );
};

export { TabPanel as Tab, CustomTabs as Tabs };
