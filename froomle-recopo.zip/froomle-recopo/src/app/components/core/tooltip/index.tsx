import React, { ReactElement, useCallback, useEffect } from "react";
import { useBreakpoints } from "data/hooks/breakpoints";
import { Text } from "ui";
import cx from "classnames";
import ReactTooltip, { TooltipProps } from "react-tooltip";
import s from "./styles.scss";

interface IProps extends TooltipProps {
  dependencies?: any[];
  showOnMobile?: boolean;
  className?: string;
}

const Tooltip = ({
  dependencies = [],
  showOnMobile = false,
  className,
  ...props
}: IProps): ReactElement | null => {
  const { isMobile } = useBreakpoints();

  const renderTooltipContent = useCallback((dataTip: string | null) => {
    if (dataTip) {
      try {
        const { img, title, categories } = JSON.parse(dataTip);
        return (
          <div className={s.tooltipWrapper}>
            {img && (
              <div
                style={{ backgroundImage: `url(${img})` }}
                className={s.tooltipImage}
              />
            )}
            <Text size="m" color="light">
              {title}
            </Text>
            <div className={s.tooltipColumn}>
              {!!categories?.length && (
                <div className={s.tooltipCategories}>
                  <Text color="secondary" size="s">
                    Categories:
                  </Text>
                  <ul className={s.tooltipList}>
                    {categories.map((category) => (
                      <li key={category} className={s.tooltipListItem}>
                        <Text component="p" size="s" color="secondary">
                          {category.split("/").join(" / ")}
                        </Text>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        );
      } catch (error) {
        return "";
      }
    }
    return "";
  }, []);

  useEffect(() => {
    ReactTooltip.rebuild();
  }, [isMobile, ...dependencies]);

  if (!showOnMobile && isMobile) return null;

  return (
    <ReactTooltip
      place={isMobile ? "top" : "bottom"}
      effect="solid"
      getContent={renderTooltipContent}
      className={cx(s.tooltip, className)}
      event={isMobile ? "dbclick" : undefined}
      eventOff="touchend"
      globalEventOff="touchend"
      {...props}
    />
  );
};

export default Tooltip;
