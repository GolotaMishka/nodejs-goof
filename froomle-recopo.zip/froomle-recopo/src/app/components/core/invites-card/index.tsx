/* eslint-disable no-nested-ternary */
import { companyWizardPath } from "app/constants/url";
import {
  CompanyInviteStatus,
  useAcceptInvite,
  useAuth,
  useDeclineInvite,
  useListCompanies,
  useListInvites,
} from "data";
import { CompanyInviteEntity } from "data/utils/types";
import React, { ReactElement, useState } from "react";
import { Trans, useTranslation } from "react-i18next";
import { useHistory } from "react-router-dom";
import { Button, ConfirmModal, Text } from "ui";
import s from "./styles.scss";

export const InvitesCard = (): ReactElement => {
  const { t } = useTranslation();
  const history = useHistory();
  const { user } = useAuth();

  const { data: invites, refetch: refetchInvites } = useListInvites(
    user?.id,
    CompanyInviteStatus.pending
  );
  const { refetch: refetchCompanies } = useListCompanies(user?.id);
  const refetch = () => {
    refetchCompanies();
    refetchInvites();
  };
  const [decliningInvite, setDecliningInvite] = useState(
    null as null | CompanyInviteEntity
  );
  const { mutate: acceptInvite, isLoading: acceptLoading } = useAcceptInvite();
  const {
    mutate: declineInvite,
    isLoading: declineIsLoading,
  } = useDeclineInvite();

  if (!invites?.length) return <></>;
  return (
    <div className={s.card}>
      <div className={s.cardHeader}>
        <Text weight="bold" size="l">
          {t("invites")}
        </Text>
      </div>
      {invites?.map((invite) => (
        <div className={s.cardRow} key={invite.id}>
          <span>
            <Trans
              i18nKey="invitedYou"
              values={{
                firstName: invite?.createdBy?.firstName,
                lastName: invite?.createdBy?.lastName,
                companyName: invite?.company?.name,
              }}
            />
          </span>
          <div className={s.cardActions}>
            <Button
              onClick={() =>
                acceptInvite(invite.id, {
                  onSuccess: () => {
                    refetch();
                    if (invite.step && invite.company)
                      history.push(
                        companyWizardPath(invite.company.id, invite.step)
                      );
                  },
                })
              }
              isLoading={acceptLoading}
              className={s.cardActionsAccept}
            >
              <Trans i18nKey="accept" />
            </Button>
            <Button
              onClick={() => setDecliningInvite(invite)}
              className={s.cardActionsDecline}
            >
              <Trans i18nKey="decline" />
            </Button>
          </div>
        </div>
      ))}
      {decliningInvite && (
        <ConfirmModal
          title={t("areYouSure")}
          onClose={() => setDecliningInvite(null)}
          onSubmit={() =>
            declineInvite(decliningInvite.id, {
              onSuccess: () => {
                refetch();
                setDecliningInvite(null);
              },
            })
          }
          submitting={declineIsLoading}
        >
          <Trans
            i18nKey="decliningInvite"
            values={{
              companyName: decliningInvite.company?.name,
            }}
          />
        </ConfirmModal>
      )}
    </div>
  );
};
