/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import React, { ReactElement, useContext, useRef } from "react";
import { Link, Route } from "react-router-dom";
import { portalPath, companiesPath } from "app/constants/url";
import { Text, Icon } from "ui";
import { useLogout } from "data";
import cx from "classnames";
// import ViewportContext from "app/utils/context/viewport";
import { useBreakpoints } from "data/hooks/breakpoints";
import TourContext from "app/utils/context/tour";
import colors from "ui/styles/_colors.scss";
import s from "./styles.scss";

interface IProps {
  className?: string;
  onClose: () => void;
}

const Dropdown = ({ className, onClose }: IProps): ReactElement => {
  const ref = useRef<HTMLUListElement>(null);
  const logout = useLogout();
  const { start: startProductTour } = useContext(TourContext);
  const { isMobile } = useBreakpoints();

  return (
    <ul ref={ref} className={cx(s.dropdown, className)}>
      <Route path={portalPath(":companyId", ":envId")}>
        <li className={s.dropdownOption}>
          <Link className={s.dropdownOptionLink} to={companiesPath}>
            <Icon icon={Icon.icons.repeat} color={colors.primary} size={20} />
            <Text size="m" color="primary">
              Change company
            </Text>
          </Link>
        </li>
        {!isMobile && (
          <li
            className={s.dropdownOption}
            onClick={() => {
              onClose();
              startProductTour?.();
            }}
          >
            <Icon icon={Icon.icons.map} color={colors.primary} size={20} />
            <Text>Product tour</Text>
          </li>
        )}
      </Route>
      {!isMobile && (
        <li className={s.dropdownOption} onClick={logout}>
          <Icon icon={Icon.icons.logout} color={colors.primary} size={20} />
          <Text>Log out</Text>
        </li>
      )}
    </ul>
  );
};

export default Dropdown;
