/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
import { companiesPath, homePath, portalPath } from "app/constants/url";
import TourContext from "app/utils/context/tour";
import { useDisableBodyScroll, useOutsideClick } from "app/utils/hooks";
import cx from "classnames";
import { useAuth, useLogout, useStore } from "data";
import { useBreakpoints } from "data/hooks/breakpoints";
import React, {
  ReactElement,
  useCallback,
  useContext,
  useRef,
  useState,
} from "react";
import { createPortal } from "react-dom";
import { Link, Route } from "react-router-dom";
import { Avatar, ButtonIcon, Icon, Text } from "ui";
import colors from "ui/styles/_colors.scss";
import Dropdown from "./dropdown";
import s from "./styles.scss";

const menuRoot = document.getElementById("menu-root") as HTMLElement;

interface HeaderProps {
  wrapperClassName?: string;
}

const Header = ({ wrapperClassName }: HeaderProps): ReactElement => {
  const { user, companyId, companyName } = useAuth();
  const { isMobile } = useBreakpoints();
  const [dropdownOpened, setDropdownOpened] = useState(false);
  const [menuOpened, setMenuOpened] = useState(false);
  const { start: startProductTour } = useContext(TourContext);
  const profileRef = useRef<HTMLDivElement>(null);
  const { env } = useStore();
  const logout = useLogout();

  const closeDropdown = useCallback(() => {
    setDropdownOpened(false);
  }, []);

  const toggleDropdown = useCallback(() => {
    setDropdownOpened(!dropdownOpened);
  }, [dropdownOpened]);

  const closeMenu = useCallback(() => {
    setMenuOpened(false);
  }, []);

  const toggleMenu = useCallback(() => {
    setMenuOpened(!menuOpened);
  }, [menuOpened]);

  const handleProductTourClick = () => {
    closeMenu();
    startProductTour?.();
  };

  useOutsideClick(profileRef, closeDropdown);

  useDisableBodyScroll(menuOpened);

  const LogoWrapperComponent = env && companyName ? Route : "div";

  const renderProfile = () => (
    <div className={s.headerProfile} ref={profileRef}>
      <div
        className={s.headerProfileButton}
        onClick={!isMobile ? toggleDropdown : () => null}
      >
        <Avatar img={user?.picture} type="medium" />
        <div className={s.headerProfileInfo}>
          <div className={s.headerProfileOpenerWrapper}>
            <Text color="light" size="s" weight="bold">
              {user?.name}
            </Text>
            {!isMobile && (
              <Icon
                icon={Icon.icons[dropdownOpened ? "chevronUp" : "chevronDown"]}
                size={15}
                color={colors.light}
                className={s.headerProfileOpenerIcon}
              />
            )}
          </div>
          <Route path={portalPath(":companyId", ":envId")}>
            <Text color="light" size="s">
              {companyName} | {env?.name}
            </Text>
          </Route>
        </div>
      </div>
      {dropdownOpened && (
        <Dropdown
          className={cx(s.headerProfileDropdown, {
            [s.headerProfileDropdown_up]: isMobile,
          })}
          onClose={closeDropdown}
        />
      )}
    </div>
  );

  return (
    <div className={cx(s.headerWrapper, wrapperClassName)}>
      <header className={s.header}>
        <LogoWrapperComponent
          to={
            LogoWrapperComponent === "div"
              ? undefined
              : homePath(":companyId", ":endId")
          }
        >
          <Icon icon={Icon.icons.froomle} width={130} color={colors.light} />
        </LogoWrapperComponent>
        {isMobile ? (
          <ButtonIcon
            icon={Icon.icons[menuOpened ? "menuOpened" : "menuClosed"]}
            onClick={toggleMenu}
            color={menuOpened ? colors.secondary : colors.light}
          />
        ) : (
          renderProfile()
        )}
      </header>
      {menuOpened &&
        createPortal(
          <div className={s.headerOverlay}>
            <ul className={s.headerMenu}>
              <Route path={portalPath(":companyId", ":envId")}>
                <li className={s.headerMenuItem}>
                  <Link
                    to={homePath(companyId!, env?.id as string)}
                    onClick={closeMenu}
                  >
                    <Text color="light" size="l" weight="bold">
                      Home page
                    </Text>
                  </Link>
                </li>
                <li
                  className={s.headerMenuItem}
                  onClick={handleProductTourClick}
                >
                  <Text color="light" size="l" weight="bold">
                    Product tour
                  </Text>
                </li>
                <Link className={s.headerMenuItem} to={companiesPath}>
                  <Icon
                    icon={Icon.icons.repeat}
                    color={colors.light}
                    size={20}
                  />
                  <Text color="light" size="l" weight="bold">
                    Change project
                  </Text>
                </Link>
              </Route>
              <Route path={companiesPath}>
                <li className={s.headerMenuItem} onClick={logout}>
                  <Icon
                    icon={Icon.icons.logout}
                    color={colors.light}
                    size={20}
                  />
                  <Text color="light" size="l" weight="bold">
                    Log out
                  </Text>
                </li>
              </Route>
            </ul>

            <div className={s.headerFooter}>{renderProfile()}</div>
          </div>,
          menuRoot
        )}
    </div>
  );
};

export default Header;
