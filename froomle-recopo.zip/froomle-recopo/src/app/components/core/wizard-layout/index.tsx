import React, { ReactElement } from "react";
import { useBreakpoints } from "data/hooks/breakpoints";
import Sidebar from "app/components/core/sidebar";
import StepFooter from "app/components/core/step-footer";
import cx from "classnames";
import Header from "app/components/core/header";
import s from "./styles.scss";

const WizardLayout = ({
  children,
  isShownSidebar = true,
}: {
  children: React.ReactNode;
  isShownSidebar?: boolean;
}): ReactElement => {
  const { isMobile } = useBreakpoints();

  return (
    <div className={s.layout}>
      <Header />
      {!isMobile && isShownSidebar && <Sidebar />}
      <div className={cx(s.page, s.page_gutter)}>{children}</div>
      <StepFooter />
    </div>
  );
};

export default WizardLayout;
