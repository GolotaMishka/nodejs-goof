import React, { ReactElement, useEffect } from "react";
import { getItemTitle, idGenerator } from "app/utils/helpers";
import ReactTooltip from "react-tooltip";
import Slider from "app/components/core/slider-new";
import { ExtendedItemEntity, ItemEntity, useStore } from "data";
import { ButtonIcon, Icon } from "ui";
import cx from "classnames";
import colors from "ui/styles/_colors.scss";
import s from "./styles.scss";

interface IProps {
  className?: string;
  items: ExtendedItemEntity[];
  hasContextItem: boolean;
  setContextItem: (item: ItemEntity) => void;
  addItemToHistory: (item: ItemEntity) => void;
}

const RecommendationsSlider = ({
  items,
  className,
  hasContextItem,
  setContextItem,
  addItemToHistory,
}: IProps): ReactElement => {
  const { env, template } = useStore();

  useEffect(() => {
    ReactTooltip.rebuild();
  }, []);

  const handleHistoryButtonClick = (
    event: React.MouseEvent<HTMLButtonElement, MouseEvent>,
    item: ItemEntity
  ) => {
    event.preventDefault();
    event.stopPropagation();
    addItemToHistory(item);
  };

  const handleContextButtonClick = (
    event: React.MouseEvent<HTMLButtonElement, MouseEvent>,
    item: ItemEntity
  ) => {
    event.preventDefault();
    event.stopPropagation();
    setContextItem(item);
  };

  return (
    <Slider className={className}>
      {items.map((item) => {
        const { images, uri } = item;

        const title = getItemTitle(item, template?.language || env?.language);

        const img = item.images?.[0];

        return (
          <div key={idGenerator()} className={s.recommendationItem}>
            {images?.[0] && (
              <div className={s.recommendationItemImageWrapper}>
                <img
                  className={s.recommendationItemImage}
                  src={images[0]}
                  alt={title}
                />
              </div>
            )}
            <div className={s.recommendationItemButtons}>
              <ButtonIcon
                type="button"
                icon={Icon.icons.bookmark}
                color={colors.accent}
                className={cx(
                  s.recommendationItemButton,
                  item.isInPersonaHistory && s.recommendationItemButton_disabled
                )}
                data-for="button-tooltip"
                disabled={item.isInPersonaHistory}
                data-tip={JSON.stringify({
                  title: item.isInPersonaHistory
                    ? "Disabled (already in history)"
                    : "Add to history",
                })}
                onClick={(e) => handleHistoryButtonClick(e, item)}
              />
              <ButtonIcon
                type="button"
                icon={Icon.icons.home}
                color={colors.accent}
                className={cx(
                  s.recommendationItemButton,
                  !hasContextItem && s.recommendationItemButton_disabled
                )}
                data-for="button-tooltip"
                disabled={!hasContextItem}
                data-tip={JSON.stringify({
                  title: hasContextItem
                    ? "Use as context item"
                    : "Disabled (no context item in this module)",
                })}
                onClick={(e) => handleContextButtonClick(e, item)}
              />
            </div>
            <a
              className={s.recommendationItemTitle}
              href={uri}
              target="_blank"
              rel="noreferrer"
              data-tip={JSON.stringify({
                img,
                title,
                categories: item.categories,
              })}
              data-for="history-item-tooltip"
            >
              {title}
            </a>
          </div>
        );
      })}
    </Slider>
  );
};

export default RecommendationsSlider;
