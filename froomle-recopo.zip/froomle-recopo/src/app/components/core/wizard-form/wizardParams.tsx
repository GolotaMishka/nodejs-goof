import { CreationStep } from "data";

export type WizardParams = { step: CreationStep | "null"; companyId: string };
