import Field from "app/utils/form-field";
import cx from "classnames";
import { ItemIntegrationType } from "data";
import React, { ReactElement, useState } from "react";
import { Trans, useTranslation } from "react-i18next";
import { Button, Modal, Radio, Text } from "ui";
import { ContentBox } from "../../helpers";
import s from "../../styles.scss";
import { ValuesProps } from "./valuesProps";

export const Items = ({ values }: ValuesProps): ReactElement => {
  const [isInfoModal, setInfoModal] = useState(false);
  const { t } = useTranslation();
  return (
    <ContentBox>
      <div className={s.contentBoxHeader}>
        <Text weight="bold" size="m">
          <Trans i18nKey="integration.items.title" />
        </Text>
        <Text size="m" color="secondary">
          <Trans i18nKey="integration.items.description1" />
          <button
            type="button"
            className={cx(s.externalLink, s.buttonLink)}
            onClick={() => setInfoModal(true)}
          >
            <Text color="primary">
              <Trans i18nKey="integration.items.descriptionButton" />
            </Text>
          </button>
        </Text>
        <Text
          size="m"
          color="secondary"
          dangerouslySetInnerHTML={{
            __html: t("integration.items.description2"),
          }}
        />
      </div>
      <div className={s.contentBoxBody}>
        <div className={s.root}>
          <Text size="m" color="primary" weight="bold" className={s.rootTitle}>
            <Trans i18nKey="integration.items.typeTitle" />
          </Text>
          <div className={s.radioListCol}>
            <Field
              className={s.radioListItem}
              name="integrationInfo.itemIntegrationType"
              label={t("integration.items.apiCalls")}
              onChangeAdapter={() => ItemIntegrationType.apiCalls}
              checked={
                values.integrationInfo?.itemIntegrationType ===
                ItemIntegrationType.apiCalls
              }
              component={Radio}
            />
            <Field
              className={s.radioListItem}
              name="integrationInfo.itemIntegrationType"
              label={t("integration.items.sftp")}
              onChangeAdapter={() => ItemIntegrationType.SFTP}
              checked={
                values.integrationInfo?.itemIntegrationType ===
                ItemIntegrationType.SFTP
              }
              component={Radio}
            />
          </div>
        </div>
      </div>
      {isInfoModal && (
        <Modal
          title={t("integration.items.modal.title")}
          onClose={() => setInfoModal(false)}
          className={s.inviteModal}
        >
          <ul className={s.listContent}>
            {(t("integration.items.modal.content", {
              returnObjects: true,
            }) as string[]).map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
          <Button variant="transparent" onClick={() => setInfoModal(false)}>
            <Trans i18nKey="close" />
          </Button>
        </Modal>
      )}
    </ContentBox>
  );
};
