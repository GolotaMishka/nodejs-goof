import Field from "app/utils/form-field";
import { CompanyDetailValues } from "app/utils/types";
import cx from "classnames";
import { IntegrationLocation, RecommendationIntegrationType } from "data";
import React, { ReactElement } from "react";
import { Trans, useTranslation } from "react-i18next";
import { Checkbox, Radio, Text, TextArea, TextInput } from "ui";
import { Col, ContentBox, Row } from "../../helpers";
import s from "../../styles.scss";
import { ValuesProps } from "./valuesProps";

const getOnMetaChange = (
  item: string,
  values: CompanyDetailValues,
  setFieldValue
) => () => {
  const items = values.integrationInfo?.metadata?.split(", ") || [];
  const i = items.indexOf(item);
  if (i >= 0) {
    items.splice(i);
  } else items.push(item);
  setFieldValue("integrationInfo.metadata", items.join(", "));
};

const getMetaChecked = (item: string, values: CompanyDetailValues) =>
  values.integrationInfo?.metadata?.split(", ")?.includes(item);

export const Recommendations = ({
  values,
  setFieldValue,
}: ValuesProps): ReactElement => {
  const { t } = useTranslation();
  return (
    <ContentBox>
      <div className={s.contentBoxHeader}>
        <Text weight="bold" size="m">
          <Trans i18nKey="integration.recommendations.title" />
        </Text>
        <Text
          size="m"
          color="secondary"
          dangerouslySetInnerHTML={{
            __html: t("integration.recommendations.description"),
          }}
        />
      </div>
      <div className={s.contentBoxBody}>
        <div className={s.root}>
          <Row>
            <Col className={s.radioListCol}>
              <Text size="m" color="primary" weight="bold">
                <Trans i18nKey="integration.recommendations.recommendationIntegrationType" />
                ?
              </Text>
              {Object.values(RecommendationIntegrationType).map((x, i) => (
                <Field
                  key={Number(i)}
                  className={s.radioListItem}
                  name="integrationInfo.recommendationIntegrationType"
                  label={t(`integration.recommendations.${x}`)}
                  onChangeAdapter={() => x}
                  checked={
                    values.integrationInfo?.recommendationIntegrationType === x
                  }
                  component={Radio}
                />
              ))}
            </Col>
            {values.integrationInfo?.recommendationIntegrationType ===
              RecommendationIntegrationType.sdk && (
              <Col>
                <Field
                  className={s.contentBoxBodyField}
                  name="integrationInfo.recommendationSdkFramework"
                  title={t(
                    "integration.recommendations.recommendationSdkFramework"
                  )}
                  component={TextInput}
                />
              </Col>
            )}
            <Col className={s.radioListCol}>
              <div>
                <Text size="m" color="primary" weight="bold">
                  <Trans i18nKey="integration.recommendations.recommendationIntegrationLocation" />
                </Text>
                <div>
                  <Text color="secondary">
                    <Trans i18nKey="integration.recommendations.recommendationIntegrationLocationDescription" />
                  </Text>
                </div>
              </div>
              {Object.values(IntegrationLocation).map((x, i) => (
                <Field
                  key={Number(i)}
                  className={s.radioListItem}
                  name="integrationInfo.recommendationIntegrationLocation"
                  label={t(`integration.recommendations.${x}`)}
                  onChangeAdapter={() => x}
                  checked={
                    values.integrationInfo
                      ?.recommendationIntegrationLocation === x
                  }
                  component={Radio}
                />
              ))}
            </Col>
            {values.integrationInfo?.recommendationIntegrationLocation ===
              IntegrationLocation.backend && (
              <Col>
                <Field
                  className={cx(
                    s.contentBoxBodyField,
                    s.contentBoxBodyFieldWide
                  )}
                  name="integrationInfo.serverLocation"
                  title={t("integration.recommendations.serverLocation")}
                  component={TextInput}
                />
              </Col>
            )}
          </Row>

          <div className={s.topMargin}>
            <Text
              size="m"
              color="primary"
              weight="bold"
              className={cx(s.topMargin, s.rootTitle)}
            >
              <Trans i18nKey="integration.recommendations.metadata" />
            </Text>
            <div>
              <Text color="secondary">
                <Trans i18nKey="integration.recommendations.metadataDescription" />
              </Text>
            </div>
          </div>

          <Row>
            <Col>
              <div className={s.radioListCol}>
                <Checkbox
                  label="Title"
                  checked={getMetaChecked("title", values)}
                  onChange={getOnMetaChange("title", values, setFieldValue)}
                />
                <Checkbox
                  label="Image_url"
                  checked={getMetaChecked("image_url", values)}
                  onChange={getOnMetaChange("image_url", values, setFieldValue)}
                />
                <Checkbox
                  label="Price"
                  checked={getMetaChecked("price", values)}
                  onChange={getOnMetaChange("price", values, setFieldValue)}
                />
                <Checkbox
                  label="Url"
                  checked={getMetaChecked("url", values)}
                  onChange={getOnMetaChange("url", values, setFieldValue)}
                />
              </div>
            </Col>
          </Row>
          <Field
            name="integrationInfo.otherInfo"
            title={t("integration.recommendations.other")}
            component={TextArea}
            className={s.topMargin}
          />
        </div>
      </div>
    </ContentBox>
  );
};
