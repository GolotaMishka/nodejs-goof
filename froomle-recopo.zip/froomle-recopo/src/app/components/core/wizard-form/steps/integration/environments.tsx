import Field from "app/utils/form-field";
import { useBreakpoints } from "data";
import React, { ReactElement } from "react";
import { Trans, useTranslation } from "react-i18next";
import { Text, TextInput } from "ui";
import { Col, ContentBox, Row } from "../../helpers";
import s from "../../styles.scss";
import { ValuesProps } from "./valuesProps";

export const Environments = ({ values }: ValuesProps): ReactElement => {
  const { t } = useTranslation();
  const { isMobile } = useBreakpoints();
  return (
    <ContentBox>
      <div className={s.contentBoxHeader}>
        <Text weight="bold" size="m">
          <Trans i18nKey="integration.environments.title" />
        </Text>
        <Text size="m" color="secondary">
          <Trans i18nKey="integration.environments.description" />
        </Text>
      </div>
      <div className={s.contentBoxBody}>
        <div className={s.root}>
          <Row>
            <Col>
              <Text size="m" color="secondary">
                <Trans i18nKey="integration.environments.brandsWebsites" />
              </Text>
            </Col>
            {values.environments?.map((_, i) => (
              <>
                <Col size={6}>
                  {isMobile && <div className={s.number}>{`${i + 1}.`}</div>}
                  <Field
                    name={`environments[${i}].displayName`}
                    component={TextInput}
                    title={t("integration.environments.brandWebsite")}
                    disabled
                  />
                </Col>
                <Col size={6}>
                  <Field
                    name={`environments[${i}].name`}
                    component={TextInput}
                    title={t("integration.environments.technicalName")}
                  />
                </Col>
                {(values.environments?.length || 0) > 1 &&
                  i !== (values.environments?.length || 0) - 1 && (
                    <div className={s.divider} />
                  )}
              </>
            ))}
          </Row>
        </div>
      </div>
    </ContentBox>
  );
};
