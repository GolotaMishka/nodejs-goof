import { useMeetingLink } from "data";
import React, { ReactElement } from "react";
import { Trans } from "react-i18next";
import { Button, Text } from "ui";
import Banner from "../../../banner";
import s from "../../styles.scss";

export const ScheduleMeeting = (): ReactElement => {
  const { data } = useMeetingLink();
  return (
    <Banner className={s.banner}>
      <Text color="light" size="m" weight="bold">
        <Trans i18nKey="integration.meeting.description" />
      </Text>
      <Button
        className={s.bannerButton}
        type="button"
        onClick={() => window.open(data, "_blank")}
      >
        <Trans i18nKey="integration.meeting.schedule" />
      </Button>
    </Banner>
  );
};
