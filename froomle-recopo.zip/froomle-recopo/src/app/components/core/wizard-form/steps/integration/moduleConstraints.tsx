import { ChipsInput } from "app/components/core/chips-input";
import Field from "app/utils/form-field";
import cx from "classnames";
import { Industry } from "data";
import React, { ReactElement } from "react";
import { Trans, useTranslation } from "react-i18next";
import { Button, Text, TextArea, TextInput } from "ui";
import { Col, ContentBox, Row } from "../../helpers";
import s from "../../styles.scss";
import { ValuesProps } from "./valuesProps";

export const ModuleConstraints = ({
  values,
  setFieldValue,
}: ValuesProps): ReactElement => {
  const { t } = useTranslation();
  return (
    <ContentBox>
      <div className={s.contentBoxHeader}>
        <Text weight="bold" size="m">
          <Trans i18nKey="integration.constraints.title" />
        </Text>
        <Text size="m" color="secondary">
          <Trans i18nKey="integration.constraints.description" />
        </Text>
      </div>
      <div className={s.contentBoxBody}>
        <div className={s.root}>
          {!values.integrationInfo?.constraints ? (
            <Button
              className={s.constraintsButton}
              onClick={() => setFieldValue("integrationInfo.constraints", {})}
            >
              <Trans i18nKey="integration.constraints.setConstraints" />
            </Button>
          ) : (
            <>
              <Button
                className={s.constraintsButton}
                onClick={() =>
                  setFieldValue("integrationInfo.constraints", undefined)
                }
              >
                <Trans i18nKey="integration.constraints.setConstraints" />
              </Button>
              <Row>
                {values.generalInfo?.industry === Industry.news && (
                  <Col>
                    <Field
                      className={cx(
                        s.contentBoxBodyField,
                        s.contentBoxBodyFieldWide
                      )}
                      name="integrationInfo.constraints.maxAge"
                      title={t("integration.constraints.maxAge")}
                      component={TextInput}
                      type="number"
                    />
                  </Col>
                )}

                {values.generalInfo?.industry === Industry.eCommerce && (
                  <Col>
                    <Field
                      className={cx(
                        s.contentBoxBodyField,
                        s.contentBoxBodyFieldWide
                      )}
                      name="integrationInfo.constraints.minStock"
                      title={t("integration.constraints.minStock")}
                      component={TextInput}
                      type="number"
                    />
                  </Col>
                )}
                {[Industry.news, Industry.eCommerce].includes(
                  values.generalInfo?.industry as Industry
                ) && (
                  <>
                    <Col>
                      <ChipsInput
                        onChange={(chips) =>
                          setFieldValue(
                            "integrationInfo.constraints.ignoredCategories",
                            chips
                          )
                        }
                        value={
                          values.integrationInfo?.constraints
                            ?.ignoredCategories || []
                        }
                        title={t("integration.constraints.ignoredCategories")}
                      />
                    </Col>
                    <Col>
                      <ChipsInput
                        onChange={(chips) =>
                          setFieldValue(
                            "integrationInfo.constraints.ignoredTags",
                            chips
                          )
                        }
                        value={
                          values.integrationInfo?.constraints?.ignoredTags || []
                        }
                        title={t("integration.constraints.ignoredTags")}
                      />
                    </Col>
                  </>
                )}
                <Col>
                  <Field
                    className={cx(
                      s.contentBoxBodyField,
                      s.contentBoxBodyFieldWide
                    )}
                    name="integrationInfo.constraints.other"
                    title={t(
                      [(Industry.news, Industry.eCommerce)].includes(
                        values.generalInfo?.industry as Industry
                      )
                        ? "integration.constraints.other"
                        : "integration.constraints.specifyConstraints"
                    )}
                    component={TextArea}
                  />
                </Col>
              </Row>
            </>
          )}
        </div>
      </div>
    </ContentBox>
  );
};
