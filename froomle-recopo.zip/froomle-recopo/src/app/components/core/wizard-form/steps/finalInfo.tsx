import { useWizardContext } from "@panenco/formik-wizard-form";
import { DayPicker, toast } from "@panenco/ui";
import { companiesPath, companyWizardPath } from "app/constants/url";
import ScrollToTop from "app/utils/scroll-to-top";
import { CompanyDetailValues } from "app/utils/types";
import { CreationStep, useConfirmCompany, useUpdateCompanyDates } from "data";
import { DateInfo, DateInfoSchema } from "data/utils";
import { Form, FormikProps } from "formik";
import React, { useEffect, useImperativeHandle } from "react";
import { Trans, useTranslation } from "react-i18next";
import { useHistory, useParams } from "react-router-dom";
import { Button, PrimaryButton, Text } from "ui";
import cx from "classnames";
import { Col, ContentBox, Row } from "../helpers";
import s from "../styles.scss";
import { WizardParams } from "../wizardParams";
import { ScheduleMeeting } from "./integration";

function Step(
  {
    setFieldValue,
    isSubmitting,
    errors,
    values,
  }: FormikProps<CompanyDetailValues>,
  ref
) {
  const history = useHistory();
  const { t } = useTranslation();
  const { companyId } = useParams<WizardParams>();
  const {
    mutateAsync: setDates,
    isLoading: dateLoading,
  } = useUpdateCompanyDates(companyId);
  const { mutateAsync: confirm, isLoading: confirmLoading } = useConfirmCompany(
    companyId
  );

  useImperativeHandle(ref, () => ({
    onSubmit: async (val: CompanyDetailValues) => {
      await setDates(val.dateInfo as DateInfo);
      await confirm(undefined, {
        onSuccess: () => {
          (toast as any).success(t("companySubmitted"));
          history.push(companiesPath);
        },
      });
    },
  }));

  useEffect(() => {
    if (companyId)
      history.push(companyWizardPath(companyId, CreationStep.date));
  }, []);

  const { back } = useWizardContext();

  return (
    <Form className={s.form}>
      <ScrollToTop />
      <ScheduleMeeting />
      <ContentBox>
        <div className={s.contentBoxHeader}>
          <Text weight="bold" size="m">
            <Trans i18nKey="final.subTitle" />
          </Text>
        </div>
        <div className={s.contentBoxBody}>
          <div className={s.root}>
            <Row>
              <Col>
                <DayPicker
                  title={t("final.activatedAt")}
                  component={DayPicker}
                  format="yyyy/MM/dd"
                  placeholder="yyyy/MM/dd"
                  value={
                    values.dateInfo?.activatedAt
                      ? new Date(values.dateInfo?.activatedAt as any)
                      : undefined
                  }
                  defaultDay={true as any}
                  onChange={(v) => {
                    if (v !== true)
                      setFieldValue("dateInfo.activatedAt", new Date(v));
                  }}
                  error={
                    (errors.dateInfo as any)?.activatedAt &&
                    ((
                      <span className={s.fieldError}>
                        {(errors.dateInfo as any)?.activatedAt}
                      </span>
                    ) as any)
                  }
                />
                <Text color="secondary" size="s">
                  <Trans i18nKey="final.activatedAtInfo" />
                </Text>
              </Col>
              <Col>
                <DayPicker
                  title={t("final.trialStartsAt")}
                  component={DayPicker}
                  format="yyyy/MM/dd"
                  placeholder="yyyy/MM/dd"
                  value={
                    values.dateInfo?.trialStartsAt
                      ? new Date(values.dateInfo?.trialStartsAt as any)
                      : undefined
                  }
                  defaultDay={true as any}
                  onChange={(v) => {
                    if (v !== true)
                      setFieldValue("dateInfo.trialStartsAt", new Date(v));
                  }}
                  error={
                    (errors.dateInfo as any)?.trialStartsAt &&
                    ((
                      <span className={cx(s.fieldError, s.fieldErrorTrial)}>
                        {(errors.dateInfo as any)?.trialStartsAt}
                      </span>
                    ) as any)
                  }
                />
                <Text color="secondary" size="s">
                  <Trans i18nKey="final.trialStartsAtInfo" />
                </Text>
              </Col>
            </Row>
          </div>
        </div>
      </ContentBox>
      <div className={s.buttonGroup}>
        <Button type="button" onClick={back}>
          <Trans i18nKey="previous" />
        </Button>
        <PrimaryButton
          type="submit"
          isLoading={isSubmitting}
          disabled={isSubmitting || dateLoading || confirmLoading}
        >
          <Trans i18nKey="submit" />
        </PrimaryButton>
      </div>
    </Form>
  );
}

const FinalInfo = React.forwardRef<
  HTMLFormElement,
  FormikProps<CompanyDetailValues>
>(Step);

FinalInfo.displayName = "final.title";
(FinalInfo as any).Validation = DateInfoSchema;
(FinalInfo as any).Title = "final.title";

export default FinalInfo;
