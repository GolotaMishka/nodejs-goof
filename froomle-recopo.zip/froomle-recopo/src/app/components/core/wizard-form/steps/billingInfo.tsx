import { useWizardContext } from "@panenco/formik-wizard-form";
import { companyWizardPath } from "app/constants/url";
import Field from "app/utils/form-field";
import ScrollToTop from "app/utils/scroll-to-top";
import {
  BillingInfo,
  CompanyDetail,
  CreationStep,
  useUpdateCompanyBilling,
} from "data";
import { BillingInfoSchema } from "data/utils";
import { Form, FormikProps } from "formik";
import React, { useEffect, useImperativeHandle } from "react";
import { Trans, useTranslation } from "react-i18next";
import { useHistory, useParams } from "react-router-dom";
import { Button, PrimaryButton, Text, TextInput } from "ui";
import { toast } from "@panenco/ui";
import { ChipsInput } from "../../chips-input";
import { Col, ContentBox, Row } from "../helpers";
import s from "../styles.scss";
import { WizardParams } from "../wizardParams";

const mapValues = (values: CompanyDetail): BillingInfo =>
  values.billingInfo as BillingInfo;

function Step(
  { isSubmitting, setFieldValue, values }: FormikProps<CompanyDetail>,
  ref
) {
  const history = useHistory();
  const { companyId } = useParams<WizardParams>();
  const { t } = useTranslation();
  const { mutateAsync: update } = useUpdateCompanyBilling(companyId);
  useImperativeHandle(ref, () => ({
    onSubmit: async (val: CompanyDetail) => {
      const mapped = mapValues(val);
      await update(mapped);
    },
  }));

  useEffect(
    () => history.push(companyWizardPath(companyId, CreationStep.billing)),
    []
  );

  const { back, next } = useWizardContext();

  const skipStep = async () => {
    await update({});
    (toast as any).success(t("billingSkippedNotice"));
    next();
  };

  return (
    <Form className={s.form}>
      <Button
        onClick={() => skipStep()}
        variant="transparent"
        className={s.formSkip}
      >
        Skip step
      </Button>
      <ScrollToTop />
      <ContentBox>
        <div className={s.contentBoxHeader}>
          <Text weight="bold" size="m">
            <Trans i18nKey="billingInfo.invoicing.title" />
          </Text>
          <Text size="m" color="secondary">
            <Trans i18nKey="billingInfo.invoicing.description" />
          </Text>
        </div>
        <div className={s.contentBoxBody}>
          <div className={s.root}>
            <Row>
              <Col size={6}>
                <Field
                  name="billingInfo.legalName"
                  title={t("billingInfo.invoicing.legalName")}
                  component={TextInput}
                />
              </Col>
              <Col size={6}>
                <Field
                  name="billingInfo.vatNumber"
                  title={t("billingInfo.invoicing.vat")}
                  component={TextInput}
                />
              </Col>
            </Row>
          </div>
        </div>
      </ContentBox>
      <ContentBox>
        <div className={s.contentBoxHeader}>
          <Text weight="bold" size="m">
            <Trans i18nKey="billingInfo.billing.title" />
          </Text>
        </div>
        <div className={s.contentBoxBody}>
          <div className={s.root}>
            <Row>
              <Col size={6}>
                <Field
                  name="billingInfo.billingAddress.address1"
                  title={t("billingInfo.billing.address1")}
                  component={TextInput}
                />
              </Col>
              <Col size={6}>
                <Field
                  name="billingInfo.billingAddress.address2"
                  title={t("billingInfo.billing.address2")}
                  component={TextInput}
                />
              </Col>
              <Col size={6}>
                <Field
                  name="billingInfo.billingAddress.postalCode"
                  title={t("billingInfo.billing.postalCode")}
                  component={TextInput}
                  type="text"
                />
              </Col>
              <Col size={6}>
                <Field
                  name="billingInfo.billingAddress.region"
                  title={t("billingInfo.billing.region")}
                  component={TextInput}
                />
              </Col>
              <Col size={6}>
                <Field
                  name="billingInfo.billingAddress.city"
                  title={t("billingInfo.billing.city")}
                  component={TextInput}
                />
              </Col>
              <Col size={6}>
                <Field
                  name="billingInfo.billingAddress.country"
                  title={t("billingInfo.billing.country")}
                  component={TextInput}
                />
              </Col>
              <Col>
                <ChipsInput
                  onChange={(chips) =>
                    setFieldValue("billingInfo.poReferences", chips)
                  }
                  value={values.billingInfo?.poReferences || []}
                  title={t("billingInfo.billing.poReferences")}
                />
              </Col>
            </Row>
          </div>
        </div>
      </ContentBox>
      <ContentBox>
        <div className={s.contentBoxHeader}>
          <Text weight="bold" size="m">
            <Trans i18nKey="billingInfo.billing.person" />
          </Text>
        </div>
        <div className={s.contentBoxBody}>
          <div className={s.root}>
            <Row>
              <Col size={6}>
                <Field
                  name="billingInfo.billingPerson.firstName"
                  title="First name"
                  component={TextInput}
                />
              </Col>
              <Col size={6}>
                <Field
                  name="billingInfo.billingPerson.lastName"
                  title="Last name"
                  component={TextInput}
                />
              </Col>
              <Col size={6}>
                <Field
                  name="billingInfo.billingPerson.email"
                  title="Billing email address for invoices"
                  component={TextInput}
                />
              </Col>
            </Row>
          </div>
        </div>
      </ContentBox>
      <div className={s.buttonGroup}>
        <Button type="button" onClick={back}>
          <Trans i18nKey="previous" />
        </Button>
        <PrimaryButton type="submit" isLoading={isSubmitting}>
          <Trans i18nKey="nextStep" />
        </PrimaryButton>
      </div>
    </Form>
  );
}

const BillingInformation = React.forwardRef<
  HTMLFormElement,
  FormikProps<CompanyDetail>
>(Step);

BillingInformation.displayName = "billingInfo.title";
(BillingInformation as any).Title = "billingInfo.title";
(BillingInformation as any).Validation = BillingInfoSchema;

export default BillingInformation;
