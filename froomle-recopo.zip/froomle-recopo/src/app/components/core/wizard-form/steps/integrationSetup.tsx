import { useWizardContext } from "@panenco/formik-wizard-form";
import { companyWizardPath } from "app/constants/url";
import ScrollToTop from "app/utils/scroll-to-top";
import { CompanyDetailValues, IntegrationInfoValues } from "app/utils/types";
import { CreationStep, useUpdateCompanyIntegration } from "data";
import { IntegrationInfoSchema } from "data/utils";
import { Form, FormikProps } from "formik";
import React, { useEffect, useImperativeHandle } from "react";
import { Trans } from "react-i18next";
import { useHistory, useParams } from "react-router-dom";
import { Button, PrimaryButton } from "ui";
import s from "../styles.scss";
import { WizardParams } from "../wizardParams";
import {
  Benchmarking,
  Environments,
  Events,
  Items,
  ModuleConstraints,
  Recommendations,
  ScheduleMeeting,
} from "./integration";

const mapValues = (values: CompanyDetailValues): IntegrationInfoValues => {
  return {
    ...values.integrationInfo,
    ...values.businessInfo,
    environments: (values.environments as unknown) as string[],
  } as IntegrationInfoValues;
};

function Step(
  {
    setFieldValue,
    isSubmitting,
    values,
    ...formikProps
  }: FormikProps<CompanyDetailValues>,
  ref
) {
  const { companyId } = useParams<WizardParams>();
  const history = useHistory();
  const { mutateAsync: update } = useUpdateCompanyIntegration(companyId);
  useImperativeHandle(ref, () => ({
    onSubmit: async (val: CompanyDetailValues) => update(mapValues(val)),
  }));

  useEffect(
    () => history.push(companyWizardPath(companyId, CreationStep.integration)),
    []
  );
  const { back } = useWizardContext();

  return (
    <Form className={s.form}>
      <ScrollToTop />
      <ScheduleMeeting />
      <Environments values={values} setFieldValue={setFieldValue} />
      <Items values={values} setFieldValue={setFieldValue} />
      <Events
        values={values}
        setFieldValue={setFieldValue}
        isSubmitting={isSubmitting}
        {...formikProps}
      />
      <Recommendations values={values} setFieldValue={setFieldValue} />
      <ModuleConstraints values={values} setFieldValue={setFieldValue} />
      <Benchmarking values={values} setFieldValue={setFieldValue} />

      <div className={s.buttonGroup}>
        <Button type="button" onClick={back}>
          <Trans i18nKey="previous" />
        </Button>
        <PrimaryButton type="submit" isLoading={isSubmitting}>
          <Trans i18nKey="nextStep" />
        </PrimaryButton>
      </div>
    </Form>
  );
}

const IntegrationSetup = React.forwardRef<
  HTMLFormElement,
  FormikProps<CompanyDetailValues>
>(Step);

IntegrationSetup.displayName = "integration.title";
(IntegrationSetup as any).Title = "integration.title";
(IntegrationSetup as any).Validation = IntegrationInfoSchema;

export default IntegrationSetup;
