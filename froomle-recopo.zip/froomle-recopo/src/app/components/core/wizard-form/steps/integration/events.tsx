import Field from "app/utils/form-field";
import { CompanyDetailValues } from "app/utils/types";
import cx from "classnames";
import { EventIntegrationType, Industry } from "data";
import { FormikProps } from "formik";
import React, { ReactElement, useState } from "react";
import { Trans, useTranslation } from "react-i18next";
import { Button, Modal, Radio, Text, TextInput } from "ui";
import { Col, ContentBox, Row } from "../../helpers";
import s from "../../styles.scss";

export const Events = ({
  values,
}: FormikProps<CompanyDetailValues>): ReactElement => {
  const { t } = useTranslation();
  const [isEventsModal, setEventsModal] = useState(false);
  return (
    <ContentBox>
      <div className={s.contentBoxHeader}>
        <Text weight="bold" size="m">
          <Trans i18nKey="integration.events.title" />
        </Text>
        <Text size="m" color="secondary">
          <Trans i18nKey="integration.events.description" />
        </Text>
      </div>
      <div className={s.contentBoxBody}>
        <div className={s.root}>
          <Row>
            <Col className={s.radioListCol}>
              <Text size="m" color="primary" weight="bold">
                <Trans i18nKey="integration.events.eventIntegrationType" />?
              </Text>
              {Object.values(EventIntegrationType).map((x, i) => (
                <Field
                  key={Number(i)}
                  className={s.radioListItem}
                  name="integrationInfo.eventIntegrationType"
                  label={t(`integration.events.${x}`)}
                  onChangeAdapter={() => x}
                  checked={values.integrationInfo?.eventIntegrationType === x}
                  component={Radio}
                />
              ))}
            </Col>
            {values.integrationInfo?.eventIntegrationType ===
              EventIntegrationType.sdk && (
              <Col>
                <Field
                  className={s.contentBoxBodyField}
                  name="integrationInfo.eventSdkFramework"
                  title={t("integration.events.eventSdkFramework")}
                  component={TextInput}
                />
              </Col>
            )}
          </Row>
        </div>
        <section className={s.topMargin}>
          <Text size="m" color="secondary">
            <Text
              color="primary"
              onClick={() => setEventsModal(true)}
              className={cx(s.externalLink, s.buttonLink)}
            >
              <Trans i18nKey="integration.events.mandatoryEventsButton" />
            </Text>
            <Text
              size="m"
              color="secondary"
              dangerouslySetInnerHTML={{
                __html: t("integration.events.frameworkDescription"),
              }}
            />
          </Text>
        </section>
      </div>
      {isEventsModal && (
        <Modal
          title={t("integration.events.modal.title")}
          onClose={() => setEventsModal(false)}
        >
          <Text color="primary" className={s.modalContent}>
            <Trans i18nKey="integration.events.modal.description" />
          </Text>
          <ul className={s.listContent}>
            {(t("integration.events.modal.events", {
              returnObjects: true,
            }) as string[]).map((item) => (
              <li key={item}>{item}</li>
            ))}
            {values.generalInfo?.industry === Industry.eCommerce &&
              (t("integration.events.modal.ecommEvents", {
                returnObjects: true,
              }) as string[]).map((item) => <li key={item}>{item}</li>)}
            {values.generalInfo?.industry === Industry.news &&
              (t("integration.events.modal.newsEvents", {
                returnObjects: true,
              }) as string[]).map((item) => <li key={item}>{item}</li>)}
            {values.generalInfo?.industry === Industry.streaming &&
              (t("integration.events.modal.streamingEvents", {
                returnObjects: true,
              }) as string[]).map((item) => <li key={item}>{item}</li>)}
          </ul>
          <Button variant="transparent" onClick={() => setEventsModal(false)}>
            <Trans i18nKey="close" />
          </Button>
        </Modal>
      )}
    </ContentBox>
  );
};
