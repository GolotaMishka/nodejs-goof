import { companyWizardPath } from "app/constants/url";
import Field from "app/utils/form-field";
import ScrollToTop from "app/utils/scroll-to-top";
import { CompanyDetailValues, GeneralInfoValues } from "app/utils/types";
import {
  CompanyDetail,
  CreationStep,
  Industry,
  useAuth,
  useCreateCompany,
  useRefresh,
  useUpdateCompanyGeneral,
} from "data";
import { GeneralInfoSchema } from "data/utils";
import { Form, FormikProps } from "formik";
import React, { useEffect, useImperativeHandle } from "react";
import { Trans, useTranslation } from "react-i18next";
import { useHistory, useParams } from "react-router-dom";
import { PrimaryButton, SelectInput, Text, TextInput } from "ui";
import { ChipsInput } from "../../chips-input";
import { Col, ContentBox, Row } from "../helpers";
import s from "../styles.scss";
import { WizardParams } from "../wizardParams";

const industries = Object.values(Industry).map((x) => ({ label: x, value: x }));

const mapValues = (values: CompanyDetail): GeneralInfoValues =>
  values.generalInfo as GeneralInfoValues;

function Step(
  {
    setFieldValue,
    isSubmitting,
    values,
    errors,
    touched,
    submitCount,
  }: FormikProps<CompanyDetailValues>,
  ref
) {
  const history = useHistory();
  const { companyId } = useParams<WizardParams>();
  const { mutateAsync: create } = useCreateCompany();
  const { mutateAsync: update } = useUpdateCompanyGeneral(companyId);
  const { refreshToken } = useAuth();
  const { mutateAsync } = useRefresh();
  const { t } = useTranslation();

  useImperativeHandle(ref, () => ({
    onSubmit: async (val) => {
      const mapped = mapValues(val);
      if (companyId) {
        await update(mapped);
        return;
      }
      const c = await create(mapped);
      await mutateAsync({ token: refreshToken, companyId: c.id });
      history.push(companyWizardPath(c.id, CreationStep.business));
    },
  }));

  useEffect(() => {
    if (companyId)
      history.push(companyWizardPath(companyId, CreationStep.general));
  }, []);

  return (
    <Form className={s.form}>
      <ScrollToTop />
      <ContentBox>
        <div className={s.contentBoxHeader}>
          <Text weight="bold" size="m">
            <Trans i18nKey="companyInfo.contentTitle" />
          </Text>
          <Text size="m" color="secondary">
            <Trans i18nKey="companyInfo.contentSubTitle" />
          </Text>
        </div>
        <div className={s.contentBoxBody}>
          <div className={s.root}>
            <Row>
              <Col size={6}>
                <Field
                  name="generalInfo.name"
                  title={t("titles.name")}
                  component={TextInput}
                />
              </Col>
              <Col size={6}>
                <Field
                  name="generalInfo.industry"
                  title={t("titles.industry")}
                  component={SelectInput}
                  options={industries}
                  onChangeAdapter={(option) => option.value}
                  valueAdapter={(v) =>
                    industries?.find((industry) => industry.value === v)
                  }
                />
              </Col>
              <Col size={6}>
                <Field
                  name="generalInfo.monthlyPageViews"
                  title={t("titles.monthlyPageViews")}
                  component={TextInput}
                />
              </Col>
              <Col size={6}>
                <Field
                  name="generalInfo.monthlyRevenue"
                  title={t("titles.monthlyRevenue")}
                  component={TextInput}
                />
              </Col>
              <Col size={6}>
                <ChipsInput
                  onChange={(chips) =>
                    setFieldValue("generalInfo.brands", chips)
                  }
                  value={values.generalInfo?.brands || []}
                  title={t("titles.brandsWebsites")}
                  error={
                    (((touched?.generalInfo as any)?.brands || submitCount) &&
                      (errors?.generalInfo as any)?.brands) ||
                    undefined
                  }
                />
              </Col>
            </Row>
          </div>
        </div>
      </ContentBox>
      <div className={s.buttonGroup}>
        <PrimaryButton isLoading={isSubmitting} type="submit">
          <Trans i18nKey="continueNextStep" />
        </PrimaryButton>
      </div>
    </Form>
  );
}

const CompanyInformation = React.forwardRef<
  HTMLFormElement,
  FormikProps<CompanyDetailValues>
>(Step);

CompanyInformation.displayName = "companyInfo.title";
(CompanyInformation as any).Validation = GeneralInfoSchema;
(CompanyInformation as any).Title = "companyInfo.title";

export default CompanyInformation;
