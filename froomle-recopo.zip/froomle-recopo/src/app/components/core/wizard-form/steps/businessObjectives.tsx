/* eslint-disable jsx-a11y/anchor-is-valid */
import { useWizardContext } from "@panenco/formik-wizard-form";
import { companyWizardPath } from "app/constants/url";
import Field from "app/utils/form-field";
import ScrollToTop from "app/utils/scroll-to-top";
import { BusinessInfoValues, CompanyDetailValues } from "app/utils/types";
import cx from "classnames";
import {
  CreationStep,
  PageType,
  useCompanyDetail,
  useUpdateCompanyBusiness,
} from "data";
import { useListModules } from "data/hooks/modules";
import { BusinessInfoSchema } from "data/utils";
import { Form, FormikProps } from "formik";
import React, {
  ChangeEvent,
  useEffect,
  useImperativeHandle,
  useState,
} from "react";
import { Trans, useTranslation } from "react-i18next";
import { useHistory, useParams } from "react-router-dom";
import {
  Button,
  Checkbox,
  Icon,
  PrimaryButton,
  Radio,
  SelectInput,
  Text,
  TextArea,
  TextInput,
} from "ui";
import { ContentBox } from "../helpers";
import s from "../styles.scss";
import { WizardParams } from "../wizardParams";

const mapValues = (values: CompanyDetailValues): BusinessInfoValues =>
  ({ ...values.businessInfo, modules: values.modules } as BusinessInfoValues);

const pageTypes = Object.values(PageType).map((x) => ({ label: x, value: x }));

function Step(
  {
    isSubmitting,
    values,
    setFieldValue,
    errors,
    touched,
    submitCount,
  }: FormikProps<CompanyDetailValues>,
  ref
) {
  const history = useHistory();
  const { companyId } = useParams<WizardParams>();
  const { mutateAsync: update } = useUpdateCompanyBusiness(companyId);
  const { data } = useCompanyDetail(companyId);

  const { data: modules } = useListModules(data?.generalInfo?.industry);
  const [search, setSearch] = useState("");
  const { t } = useTranslation();
  useImperativeHandle(ref, () => ({
    onSubmit: async (val: CompanyDetailValues) => {
      const mapped = mapValues(val);
      await update(mapped);
    },
  }));

  useEffect(
    () => history.push(companyWizardPath(companyId, CreationStep.business)),
    []
  );

  const { back } = useWizardContext();
  return (
    <Form className={s.form}>
      <ScrollToTop />
      <ContentBox>
        <div className={s.contentBoxHeader}>
          <Text weight="bold" size="m">
            <Trans i18nKey="businessInfo.objectives.title" />
          </Text>
          <Text size="m" color="secondary">
            <Trans i18nKey="businessInfo.objectives.subTitle" />
          </Text>
        </div>
        <div className={s.contentBoxBody}>
          <div className={s.root}>
            <Field
              className={s.contentBoxBodyField}
              name="businessInfo.objectives"
              component={TextArea}
            />
          </div>
        </div>
      </ContentBox>
      <ContentBox>
        <div className={s.contentBoxHeader}>
          <Text weight="bold" size="m">
            <Trans i18nKey="businessInfo.module.choose" />
          </Text>
          <Text
            size="m"
            color="secondary"
            dangerouslySetInnerHTML={{
              __html: t("businessInfo.module.learnMore"),
            }}
          />
        </div>
        <div className={s.contentBoxBody}>
          <div className={cx(s.root, s.rootFullWidth)}>
            <div className={s.contentBoxBodyWrapperFullWidth}>
              <TextInput
                className={s.contentBoxBodyWrapperFullWidthItem}
                title={t("businessInfo.module.search")}
                iconAfter={Icon.icons.search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
          {modules
            ?.filter(
              (m) =>
                m.name.toLowerCase().includes(search.toLowerCase()) ||
                m.description.toLowerCase().includes(search.toLowerCase())
            )
            .map((moduleType) => {
              const currentModuleIndex = values.modules?.findIndex(
                (m) => m.module === moduleType.id
              );
              const moduleIsSelected =
                Number.isInteger(currentModuleIndex) &&
                currentModuleIndex !== -1;

              return (
                <div key={moduleType.id} className={s.module}>
                  <Checkbox
                    wrapperProps={{
                      className: s.moduleCheckbox,
                    }}
                    checked={moduleIsSelected}
                    onChange={(e: ChangeEvent<HTMLInputElement>) => {
                      setFieldValue(
                        "modules",
                        e.target.checked
                          ? [
                              ...(values.modules || []),
                              {
                                module: moduleType.id,
                                label: moduleType.name,
                                placement: { pageType: null, position: null },
                              },
                            ]
                          : values.modules?.filter(
                              (module) => module.module !== moduleType.id
                            )
                      );
                    }}
                  />
                  <div className={s.moduleColumn}>
                    <Text
                      component="p"
                      weight="bold"
                      size="m"
                      className={s.moduleColumnTitle}
                    >
                      {moduleType.name}
                    </Text>
                    <Text color="secondary">{moduleType.description}</Text>
                    {moduleIsSelected && (
                      <div className={s.moduleInputs}>
                        <Field
                          name={`modules.${currentModuleIndex}.placement.pageType`}
                          component={SelectInput}
                          title={t("businessInfo.module.pageType")}
                          options={pageTypes}
                          onChangeAdapter={(option) => option.value}
                          valueAdapter={(v) =>
                            pageTypes?.find((x) => x.value === v)
                          }
                          className={s.moduleInput}
                        />
                        <Field
                          name={`modules.${currentModuleIndex}.label`}
                          component={TextInput}
                          title={t("businessInfo.module.label")}
                          className={s.moduleInput}
                        />
                        <Field
                          name={`modules.${currentModuleIndex}.placement.position`}
                          component={TextInput}
                          title={t("businessInfo.module.position")}
                          className={s.moduleInput}
                        />
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          {(touched.modules || submitCount) && errors.modules ? (
            <Text size="m" color="error">
              <br />
              {errors.modules}
            </Text>
          ) : (
            ""
          )}
        </div>
      </ContentBox>
      <ContentBox>
        <div className={s.contentBoxHeader}>
          <Text weight="bold" size="m">
            <Trans i18nKey="businessInfo.module.compareTitle" />
          </Text>
        </div>
        <div className={s.contentBoxBody}>
          <div className={s.root}>
            <div className={s.radioListRow}>
              <Field
                className={s.radioListItem}
                name="businessInfo.shouldCompare"
                label={t("yes")}
                onChangeAdapter={() => true}
                component={Radio}
                checked={values.businessInfo?.shouldCompare === true}
              />
              <Field
                className={s.radioListItem}
                name="businessInfo.shouldCompare"
                label={t("no")}
                component={Radio}
                onChangeAdapter={() => false}
                checked={values.businessInfo?.shouldCompare === false}
              />
            </div>
          </div>
        </div>
      </ContentBox>
      <ContentBox>
        <div className={s.contentBoxHeader}>
          <Text weight="bold" size="m">
            <Trans i18nKey="businessInfo.remarks" />
          </Text>
        </div>
        <div className={s.contentBoxBody}>
          <div className={s.root}>
            <Field name="businessInfo.remarks" component={TextArea} />
          </div>
        </div>
      </ContentBox>
      <div className={s.buttonGroup}>
        <Button type="button" onClick={back}>
          <Trans i18nKey="previous" />
        </Button>
        <PrimaryButton type="submit" isLoading={isSubmitting}>
          <Trans i18nKey="nextStep" />
        </PrimaryButton>
      </div>
    </Form>
  );
}

const BusinessObjectives = React.forwardRef<
  HTMLFormElement,
  FormikProps<CompanyDetailValues>
>(Step);

BusinessObjectives.displayName = "businessInfo.title";
(BusinessObjectives as any).Title = "businessInfo.title";
(BusinessObjectives as any).Validation = BusinessInfoSchema;

export default BusinessObjectives;
