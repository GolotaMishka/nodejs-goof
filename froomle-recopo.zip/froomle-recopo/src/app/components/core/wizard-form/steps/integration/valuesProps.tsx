import { CompanyDetailValues } from "app/utils/types";

export type ValuesProps = {
  setFieldValue: (
    field: string,
    value: any,
    shouldValidate?: boolean | undefined
  ) => void;
  values: CompanyDetailValues;
};
