import Field from "app/utils/form-field";
import cx from "classnames";
import { BenchMarkType } from "data";
import React, { ReactElement } from "react";
import { Trans, useTranslation } from "react-i18next";
import { Radio, Text, TextArea } from "ui";
import { Col, ContentBox, Row } from "../../helpers";
import s from "../../styles.scss";
import { ValuesProps } from "./valuesProps";

export const Benchmarking = ({ values }: ValuesProps): ReactElement => {
  const { t } = useTranslation();
  if (!values.businessInfo?.shouldCompare) return <></>;
  return (
    <ContentBox>
      <div className={s.contentBoxHeader}>
        <Text weight="bold" size="m">
          <Trans i18nKey="integration.benchmarking.title" />
        </Text>
        <Text size="m" color="secondary">
          <Trans i18nKey="integration.benchmarking.description" />
        </Text>
      </div>
      <div className={s.contentBoxBody}>
        <div className={s.root}>
          <Row>
            <Col>
              <div className={s.radioListCol}>
                <Field
                  className={s.radioListItem}
                  name="businessInfo.benchmarkType"
                  label={t("integration.benchmarking.froomleDistributes")}
                  onChangeAdapter={() => BenchMarkType.froomleDistributes}
                  component={Radio}
                  checked={
                    values.businessInfo?.benchmarkType ===
                    BenchMarkType.froomleDistributes
                  }
                />
                <Field
                  className={s.radioListItem}
                  name="businessInfo.benchmarkType"
                  label={t("integration.benchmarking.customerDistributes")}
                  onChangeAdapter={() => BenchMarkType.customerDistributes}
                  component={Radio}
                  checked={
                    values.businessInfo?.benchmarkType ===
                    BenchMarkType.customerDistributes
                  }
                />
              </div>
            </Col>
            <Col>
              <Field
                className={cx(s.contentBoxBodyField, s.contentBoxBodyFieldWide)}
                name="businessInfo.benchmarkBaseline"
                title={t("integration.benchmarking.benchmarkBaseline")}
                component={TextArea}
              />
            </Col>
          </Row>
        </div>
      </div>
    </ContentBox>
  );
};
