import { useWizardContext } from "@panenco/formik-wizard-form";
import cx from "classnames";
import {
  CompanyDetail,
  CreationStep,
  useBreakpoints,
  useCompanyDetail,
} from "data";
import React, { ReactElement } from "react";
import { useTranslation } from "react-i18next";
import { useParams } from "react-router-dom";
import { Icon, Text } from "ui";

import s from "./styles.scss";
import { WizardParams } from "./wizardParams";

// import Field from "app/utils/form-field";
export interface CompoundedComponent
  extends React.ForwardRefExoticComponent<
    React.HTMLAttributes<HTMLFormElement>
  > {
  Title: string;
}

export const stepMap = {
  [CreationStep.general]: { index: 0, key: "generalInfo" },
  [CreationStep.business]: { index: 1, key: "businessInfo" },
  [CreationStep.billing]: { index: 2, key: "billingInfo" },
  [CreationStep.integration]: { index: 3, key: "integrationInfo" },
  [CreationStep.date]: { index: 4, key: "dateInfo" },
};

export const getLatestActiveStep = (data: CompanyDetail): CreationStep => {
  // eslint-disable-next-line no-restricted-syntax
  for (const step of Object.keys(stepMap)) {
    // eslint-disable-next-line no-continue
    if (data[stepMap[step].key]) continue;
    return step as CreationStep;
  }
  return CreationStep.general;
};

export const ContentBox = ({ children }): ReactElement => {
  return <div className={s.contentBox}>{children}</div>;
};

export const WizardTrack = ({ stepMeta, finished }): ReactElement => {
  const { currentStepIndex } = useWizardContext();

  const { isMobile } = useBreakpoints();

  return (
    <div className={s.pointerWrapper}>
      {!isMobile && (
        <div
          className={cx(
            s.pointer,
            stepMeta.stepIndex === currentStepIndex && s.pointerActive,
            finished &&
              stepMeta.stepIndex !== currentStepIndex &&
              s.pointerCompleted
          )}
        >
          {finished && <Icon icon={Icon.icons.check} color="white" />}
        </div>
      )}
      {!isMobile && <div className={s.pointerLine} />}
    </div>
  );
};

export const Layout = ({ step }) => {
  const { stepsMeta, currentStepIndex, toStep } = useWizardContext();
  const { t } = useTranslation();
  const { isMobile } = useBreakpoints();

  const { companyId } = useParams<WizardParams>();

  const { data } = useCompanyDetail(companyId);

  return (
    <div className={!isMobile && s.layoutWizard}>
      {stepsMeta.map((stepMeta) => {
        const finished = !!data?.[
          Object.values(stepMap).find((x) => x.index === stepMeta.stepIndex)
            ?.key as string
        ];
        const title = isMobile ? (
          <span className={s.pointerMobileWrapper}>
            <div
              className={cx(
                s.pointer,
                stepMeta.stepIndex === currentStepIndex && s.pointerActive,
                finished &&
                  stepMeta.stepIndex !== currentStepIndex &&
                  s.pointerCompleted
              )}
            >
              {finished && <Icon icon={Icon.icons.check} color="white" />}
            </div>
            <Text size="m" weight="bold">{`${stepMeta.stepIndex + 1}. ${t(
              stepMeta.title?.toString() || ""
            )}`}</Text>
          </span>
        ) : (
          <Text size="m" weight="bold">{`${stepMeta.stepIndex + 1}. ${t(
            stepMeta.title?.toString() || ""
          )}`}</Text>
        );

        return (
          <div key={stepMeta.stepIndex} className={s.contentStep}>
            <WizardTrack stepMeta={stepMeta} finished={finished} />
            <div className={s.contentStepForm}>
              {companyId ? (
                <button
                  className={s.link}
                  onClick={() => toStep(stepMeta.stepIndex)}
                >
                  {title}
                </button>
              ) : (
                title
              )}
              {currentStepIndex === stepMeta.stepIndex && step}
            </div>
          </div>
        );
      })}
    </div>
  );
};

interface IProps {
  className?: string;
  children: React.ReactNode;
}

interface ColProps extends IProps {
  size?: number;
}

export const Row = ({ className, ...props }: IProps): React.ReactElement => {
  return <div className={cx(s.row, className)} {...props} />;
};

export const Col = ({
  className,
  size = 12,
  children,
  ...props
}: ColProps): React.ReactElement => {
  const { isMobile } = useBreakpoints();
  return (
    <div {...props} className={cx(s[`col${isMobile ? 12 : size}`], className)}>
      {children}
    </div>
  );
};
