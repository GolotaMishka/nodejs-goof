import { WizardForm as FormikWizardForm } from "@panenco/formik-wizard-form";
import { companyWizardPath } from "app/constants/url";
import { CompanyDetailValues } from "app/utils/types";
import {
  EventIntegrationType,
  Industry,
  IntegrationLocation,
  ItemIntegrationType,
  RecommendationIntegrationType,
  useCompanyDetail,
} from "data";
import React, { ReactElement, useEffect } from "react";
import { useHistory, useParams } from "react-router-dom";
import { SkeletonLoader } from "../loader";
import { getLatestActiveStep, Layout, stepMap } from "./helpers";
import {
  BillingInformation,
  BusinessObjectives,
  CompanyInformation,
  FinalInfo,
  IntegrationSetup,
} from "./steps";
import { WizardParams } from "./wizardParams";

const steps = [
  CompanyInformation,
  BusinessObjectives,
  BillingInformation,
  IntegrationSetup,
  FinalInfo,
];

const defaultValues: CompanyDetailValues = {
  generalInfo: {
    name: "",
    industry: "" as Industry,
    monthlyPageViews: "",
    monthlyRevenue: "",
  },
  businessInfo: {
    objectives: "",
    shouldCompare: ("" as unknown) as boolean,
    remarks: "",
  },
  billingInfo: {
    billingAddress: {
      address1: "",
      city: "",
      country: "",
      postalCode: "",
      region: "",
      address2: "",
    },
    billingPerson: {
      email: "",
      firstName: "",
      lastName: "",
    },
    legalName: "",
    vatNumber: "",
    poReferences: [],
  },
  integrationInfo: {
    eventIntegrationType: "" as EventIntegrationType,
    itemIntegrationType: "" as ItemIntegrationType,
    recommendationIntegrationType: "" as RecommendationIntegrationType,
    recommendationIntegrationLocation: "" as IntegrationLocation,
    constraints: undefined,
    eventSdkFramework: "",
    recommendationSdkFramework: "",
    serverLocation: "",
  },
  dateInfo: {
    activatedAt: undefined,
    trialStartsAt: undefined,
  },
  environments: [],
  modules: [],
};

const WizardForm = (): ReactElement => {
  const { step, companyId } = useParams<WizardParams>();
  const history = useHistory();

  const { data } = useCompanyDetail(companyId);

  useEffect(() => {
    if (step !== "null" || !data) return;

    const latestActiveStep = getLatestActiveStep(data);
    history.push(companyWizardPath(companyId, latestActiveStep));
  }, [step, data]);

  if ((!data && step) || step === "null") return <SkeletonLoader />;

  return (
    <FormikWizardForm
      initialValues={
        data
          ? ({
              ...data,
              generalInfo: {
                ...defaultValues.generalInfo,
                ...data.generalInfo,
                brands: data.environments?.map((e) => e.displayName) || [],
              },
              businessInfo: {
                ...defaultValues.businessInfo,
                ...data.businessInfo,
              },
              billingInfo: {
                ...defaultValues.billingInfo,
                ...data.billingInfo,
              },
              integrationInfo: {
                ...defaultValues.integrationInfo,
                ...data.integrationInfo,
              },
              dateInfo: {
                ...defaultValues.dateInfo,
                ...data.dateInfo,
              },
              environments: data.environments || defaultValues.environments,
              modules:
                data.modules?.map((e) => ({ ...e, module: e.module.id })) ||
                defaultValues.modules,
            } as CompanyDetailValues)
          : defaultValues
      }
      steps={steps}
      onSubmit={() => undefined}
      component={Layout}
      enableReinitialize
      initialStep={step && stepMap[step]?.index}
      onReset={() => null}
    />
  );
};

export default WizardForm;
