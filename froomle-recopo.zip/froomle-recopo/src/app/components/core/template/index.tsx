import React, { ReactElement } from "react";
import { idGenerator } from "app/utils";
import { SimpleSpread } from "app/utils/generics";
import cx from "classnames";
import { Text } from "ui";

import { TemplateEntity } from "data";
import s from "./styles.scss";

interface ExtraProps {
  isSelected: boolean;
  template: TemplateEntity;
  className?: string;
}

type Props = SimpleSpread<React.HTMLAttributes<HTMLDivElement>, ExtraProps>;

const Template = ({
  isSelected,
  template,
  className,
  ...props
}: Props): ReactElement => {
  return (
    <div
      className={cx(
        s.template,
        { [s.template_selected]: isSelected },
        className
      )}
      data-cy={isSelected ? "template-selected" : "template"}
      {...props}
    >
      <div className={s.templateSection}>
        <Text weight="bold" size="m" color="accent" className={s.templateTitle}>
          {template.name}
        </Text>
        <Text size="s" color="secondary" className={s.templateSubtitle}>
          {template.description}
        </Text>
      </div>
      <div className={s.divider} />
      <div className={s.templateSection}>
        <Text
          size="s"
          color="primary"
          weight="bold"
          className={s.templateSectionHeader}
        >
          Modules:
        </Text>
        <ul className={s.templateList}>
          {template.modules.map((module) => (
            <li key={idGenerator()} className={s.templateListItem}>
              <Text color="dark" size="s" className={s.templateListItemText}>
                {module.name}
              </Text>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default Template;
