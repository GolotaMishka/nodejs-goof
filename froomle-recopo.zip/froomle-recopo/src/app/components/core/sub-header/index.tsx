import React, { ReactElement } from "react";
import s from "./styles.scss";

export interface SubHeaderProps {
  children: React.ReactNode;
}

const SubHeader = ({ children }: SubHeaderProps): ReactElement => {
  return <section className={s.subHeader}>{children}</section>;
};

export default SubHeader;
