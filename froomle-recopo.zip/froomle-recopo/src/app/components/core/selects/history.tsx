/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import React, {
  ReactElement,
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import { getItemTitle } from "app/utils";
import { useOutsideClick } from "app/utils/hooks";
import cx from "classnames";
import {
  AppThemeType,
  Button,
  Icon,
  PrimaryButton,
  Text,
  TextInput,
  TextInputProps,
  useTheme,
} from "ui";
import { ItemEntity, useStore } from "data";
import type { SimpleSpread } from "app/utils/generics";

import s from "./styles.scss";
import SelectFilters from "./filters";

type FilterType = "Popular" | "Recent";

interface ExtraProps {
  onInputChange: (string) => void;
  options?: ItemEntity[];
  className?: string;
  isLoading: boolean;
  onSubmit: (options: ItemEntity[]) => void;
  initialSelected?: boolean;
  onFilterChange?: (filter: FilterType) => void;
  filters?: FilterType[];
}

type Props = SimpleSpread<TextInputProps, ExtraProps>;

const HistorySelect = ({
  options,
  onInputChange,
  className,
  isLoading,
  onSubmit,
  initialSelected = false,
  filters,
  onFilterChange,
  ...props
}: Props): ReactElement => {
  const wrapperRef = useRef(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const [menuIsOpen, setMenuIsOpen] = useState(false);
  const [inputValue, setInputValue] = useState("");
  const [selectedOptions, setSelectedOptions] = useState<ItemEntity[]>([]);
  const theme: AppThemeType = useTheme();

  const { env } = useStore();

  const closeMenu = useCallback(() => {
    setMenuIsOpen(false);
  }, []);

  const openMenu = useCallback(() => {
    setMenuIsOpen(true);
  }, []);

  useOutsideClick(wrapperRef, closeMenu);

  useEffect(() => {
    if (!menuIsOpen) {
      setSelectedOptions([]);
      setInputValue("");
    }
  }, [menuIsOpen]);

  const handleInputChange = ({
    target: { value: newValue },
  }: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(newValue);
    onInputChange(newValue);
  };

  const onOptionClick = (option: ItemEntity, isSelected: boolean) => () => {
    inputRef.current?.focus();
    if (!isSelected) {
      setSelectedOptions([...selectedOptions, option]);
    } else {
      setSelectedOptions(
        selectedOptions.filter(
          (selectedOption) =>
            option.clientItemId !== selectedOption.clientItemId &&
            option.froomleItemId !== selectedOption.froomleItemId
        )
      );
    }
  };

  const handleSubmit = () => {
    closeMenu();
    onSubmit(selectedOptions);
  };

  useEffect(() => {
    if (options && initialSelected) {
      setSelectedOptions(options);
    }
  }, [options]);

  const renderNoOptionsMessage = useCallback(() => {
    if (options && options.length > 0) return null;
    return (
      <Text color="secondary" size="m" className={s.noOptionsMessage}>
        {isLoading ? "Loading..." : "No items found"}
      </Text>
    );
  }, [isLoading]);

  const renderOptions = useCallback(() => {
    return options?.map((option, i) => {
      const isSelected = !!selectedOptions?.find(
        (selectedOption) =>
          option.clientItemId === selectedOption.clientItemId ||
          option.froomleItemId === selectedOption.froomleItemId
      );
      return (
        <div
          ref={menuRef}
          key={`option_${option.froomleItemId || option.clientItemId}`}
          data-cy={`history-select-option-${i}`}
          className={cx(s.menuOption, {
            [s.menuOption_selected]: isSelected,
          })}
          onClick={onOptionClick(option, isSelected)}
        >
          {isSelected && (
            <Icon
              color={theme.colors.accent}
              size={12}
              icon={Icon.icons.check}
            />
          )}
          <Text size="m" color="dark">
            {getItemTitle(option, env?.language)}
          </Text>
        </div>
      );
    });
  }, [options, env, menuRef, onOptionClick]);

  return (
    <div ref={wrapperRef} className={cx(s.root, className)}>
      <TextInput
        iconAfter={!filters && Icon.icons.search}
        onChange={handleInputChange}
        value={inputValue}
        onFocus={openMenu}
        inputRef={inputRef}
        wrapperProps={{
          className: cx(menuIsOpen && s.input),
          "data-cy": "history-select-input",
        }}
        {...props}
      />
      {filters && (
        <SelectFilters
          options={filters}
          onChange={onFilterChange}
          className={s.inputFilter}
        />
      )}
      {menuIsOpen && (
        <div className={s.menu}>
          <div className={s.menuOptions}>
            {renderNoOptionsMessage()}
            {renderOptions()}
          </div>
          <div className={s.menuFooter}>
            <Button onClick={closeMenu}>Cancel</Button>
            <PrimaryButton
              onClick={handleSubmit}
              data-cy="history-select-submit"
            >
              Add
              {selectedOptions.length ? ` (${selectedOptions.length})` : ""}
            </PrimaryButton>
          </div>
        </div>
      )}
    </div>
  );
};

export default HistorySelect;
