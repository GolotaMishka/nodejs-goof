/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import React, { useCallback, useRef, useState, ReactElement } from "react";
import { useOutsideClick } from "app/utils/hooks";
import { Icon, Text } from "ui";
import cx from "classnames";
import { idGenerator } from "app/utils";
import s from "./styles.scss";

interface IProps {
  options: string[];
  className?: string;
  onChange?: (option: string) => void;
}

const SelectFilters = ({
  options,
  onChange,
  className,
}: IProps): ReactElement => {
  const [selectedFilter, setSelectedFilter] = useState(options[0]);
  const [menuIsOpen, setMenuIsOpen] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const closeMenu = useCallback(() => {
    setMenuIsOpen(false);
  }, []);

  const toggleMenu = useCallback(() => {
    setMenuIsOpen(!menuIsOpen);
  }, [menuIsOpen]);

  const handleOptionClick = (option) => () => {
    toggleMenu();
    if (onChange) onChange(option);
    setSelectedFilter(option);
  };

  useOutsideClick(wrapperRef, closeMenu);

  return (
    <div
      ref={wrapperRef}
      className={cx(s.filter, className, menuIsOpen && s.filter_opened)}
    >
      <div
        className={cx(s.filterSelected, s.filterOption)}
        onClick={toggleMenu}
      >
        <Icon size={17} icon={Icon.icons.sort} />
        <Text color="accent" size="s">
          {selectedFilter}
        </Text>
      </div>
      {menuIsOpen && (
        <ul className={s.filterOptions}>
          {options
            .filter((option) => option !== selectedFilter)
            .map((option) => (
              <li
                key={idGenerator()}
                onClick={handleOptionClick(option)}
                className={s.filterOption}
              >
                <Text color="primary" size="s">
                  {option}
                </Text>
              </li>
            ))}
        </ul>
      )}
    </div>
  );
};

export default SelectFilters;
