/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-static-element-interactions */
import React, {
  ReactElement,
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import { getItemTitle } from "app/utils";
import { useDisableBodyScroll, useOutsideClick } from "app/utils/hooks";
import cx from "classnames";
import {
  Button,
  ButtonIcon,
  Icon,
  PrimaryButton,
  Text,
  TextInput,
  TextInputProps,
  Avatar,
  BoxHeader,
} from "ui";
import { ItemEntity, useStore } from "data";
import { useBreakpoints } from "data/hooks/breakpoints";
import type { SimpleSpread } from "app/utils/generics";
import colors from "ui/styles/_colors.scss";
import SelectFilters from "./filters";
import s from "./styles.scss";

type FilterType = "Popular" | "Recent";

interface ExtraProps {
  onInputChange: (string) => void;
  options?: ItemEntity[];
  className?: string;
  isLoading: boolean;
  onFilterChange?: (filter: FilterType) => void;
  filters?: FilterType[];
  title?: string;
  icon?: string;
  onChange: (option: ItemEntity | null) => void;
  preselectedOption?: ItemEntity | null;
}

type Props = SimpleSpread<TextInputProps, ExtraProps>;

const ContextSelect = ({
  options,
  onInputChange,
  className,
  isLoading,
  filters,
  onFilterChange,
  title,
  icon,
  onChange,
  preselectedOption = null,
  ...props
}: Props): ReactElement => {
  const wrapperRef = useRef(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const [selectedOption, setSelectedOption] = useState<ItemEntity | null>(
    preselectedOption || null
  );
  const [menuIsOpen, setMenuIsOpen] = useState(false);
  const [inputValue, setInputValue] = useState("");
  const { isSmallMobile } = useBreakpoints();

  const { env } = useStore();

  const closeMenu = useCallback(() => {
    setMenuIsOpen(false);
  }, []);

  const openMenu = useCallback(() => {
    setMenuIsOpen(true);
  }, []);

  useOutsideClick(wrapperRef, closeMenu);

  useEffect(() => {
    setSelectedOption(preselectedOption);
  }, [preselectedOption]);

  useEffect(() => {
    if (!menuIsOpen) {
      setInputValue("");
    }
  }, [menuIsOpen]);

  const handleInputChange = ({
    target: { value: newValue },
  }: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(newValue);
    onInputChange(newValue);
  };

  const onOptionClick = (option: ItemEntity) => {
    setSelectedOption(option);
  };

  const onSave = () => {
    onChange(selectedOption);
    closeMenu();
  };

  useDisableBodyScroll(menuIsOpen && isSmallMobile);

  const renderNoOptionsMessage = useCallback(() => {
    if (options && options.length > 0) return null;
    return (
      <Text color="secondary" size="m" className={s.noOptionsMessage}>
        {isLoading ? "Loading..." : "No items found"}
      </Text>
    );
  }, [isLoading]);

  const renderOptions = useCallback(() => {
    return options?.map((option, i) => {
      const isSelected = option === selectedOption;

      return (
        <div
          ref={menuRef}
          key={`option_${option.froomleItemId || option.clientItemId}`}
          data-cy={`history-select-option-${i}`}
          className={cx(s.contextOption, {
            [s.contextOption_selected]: isSelected,
          })}
          onClick={() => onOptionClick(option)}
        >
          <Avatar type="huge" img={option.images?.[0]} />
          <div className={s.contextOptionDescription}>
            {!!option.categories?.length && (
              <Text size="s" color="secondary">
                {option.categories.join(` ${String.fromCharCode(8226)} `)}
              </Text>
            )}
            <Text size="m" color="dark">
              {getItemTitle(option, env?.language)}
            </Text>
          </div>
        </div>
      );
    });
  }, [options, env, menuRef, onOptionClick]);

  const placeholderText = isSmallMobile
    ? "Search item..."
    : "Please enter item name...";

  return (
    <div
      ref={wrapperRef}
      className={cx(s.context, className, menuIsOpen && s.context_opened)}
    >
      {menuIsOpen && isSmallMobile && (
        <BoxHeader>
          <div className={s.contextMenuHeaderContent}>
            <Text color="light">Choose context item</Text>
            <ButtonIcon
              className={s.contextMenuHeaderCloseButton}
              icon={Icon.icons.close}
              color={colors.light}
              onClick={closeMenu}
            />
          </div>
        </BoxHeader>
      )}
      {title && !(menuIsOpen && isSmallMobile) && (
        <div className={s.contextTitle}>
          {icon && <Icon size={16} icon={Icon.icons[icon]} />}
          <Text weight="bold">{title}</Text>
        </div>
      )}
      <div className={s.contextInputWrapper}>
        <TextInput
          iconAfter={Icon.icons[menuIsOpen ? "chevronUp" : "chevronDown"]}
          onChange={handleInputChange}
          value={inputValue}
          onFocus={openMenu}
          inputRef={inputRef}
          placeholder={
            menuIsOpen || !selectedOption ? placeholderText : undefined
          }
          wrapperProps={{
            className: cx(s.contextInput, {
              [s.input]: menuIsOpen,
              [s.contextInput_opened]: menuIsOpen,
            }),
            "data-cy": "history-select-input",
          }}
          {...props}
        />
        {filters && menuIsOpen && (
          <SelectFilters
            options={filters}
            onChange={onFilterChange}
            className={cx(s.inputFilter, s.contextFilter)}
          />
        )}
        {!menuIsOpen && selectedOption && (
          <div className={s.contextShowcase} onClick={openMenu}>
            <Avatar img={selectedOption?.images?.[0]} />
            <Text className={s.contextShowcaseTitle}>
              {selectedOption?.title}
            </Text>
          </div>
        )}
      </div>
      {menuIsOpen && (
        <div className={cx(s.menu, s.contextMenu)}>
          <div className={s.contextOptions}>
            {renderNoOptionsMessage()}
            {renderOptions()}
          </div>
          <div className={cx(s.menuFooter, s.contextMenuFooter)}>
            <Button onClick={closeMenu}>Cancel</Button>
            {/* TODO: add isSubmitting */}
            <PrimaryButton
              disabled={!selectedOption}
              onClick={onSave}
              data-cy="history-select-submit"
            >
              Save
            </PrimaryButton>
          </div>
        </div>
      )}
    </div>
  );
};

export default ContextSelect;
