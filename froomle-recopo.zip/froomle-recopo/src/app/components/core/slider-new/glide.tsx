import "@glidejs/glide/dist/css/glide.core.min.css";

import React, { ReactElement, useEffect, useRef, useState } from "react";
import Glide from "@glidejs/glide";
import cx from "classnames";
import { ButtonIcon, Icon } from "ui";
import { useBreakpoints } from "data/hooks/breakpoints";
import bp from "ui/styles/_breakpoints.scss";
import s from "./styles.scss";

type GlideType = "slider" | "carousel";

type Breakpoints = Record<number, Record<string, unknown>>;

type PeekSetting = { before: number; after: number };

type GliderProps = {
  type?: GlideType;
  startAt?: number;
  perView: number;
  focusAt?: number | string;
  gap?: number;
  autoplay?: number | boolean;
  hoverPause?: boolean;
  keyboard?: boolean;
  bound?: boolean;
  swipeThreshold?: number | boolean;
  dragThreshold?: number | boolean;
  perTouch?: number | boolean;
  touchRatio?: number;
  touchAngle?: number;
  animationDuration?: number;
  rewind?: boolean;
  rewindDuration?: number;
  animationTimingFunc?: string;
  direction?: string;
  breakpoints?: Breakpoints;
  throttle?: number;
  peek?: PeekSetting | number;
};

const gliderOptions: GliderProps = {
  perView: 7,
  peek: { before: 0, after: 70 },
  bound: true,
  rewind: false,
  gap: 11,
  keyboard: false,
  breakpoints: {
    [parseInt(bp.hugeScreen, 10)]: {
      perView: 5,
    },
    [parseInt(bp.desktop, 10)]: {
      perView: 4,
    },
    [parseInt(bp.smallDesktop, 10)]: {
      perView: 3,
    },
    [parseInt(bp.tablet, 10)]: {
      perView: 2,
    },
    [parseInt(bp.mobile, 10)]: {
      perView: 1,
    },
  },
};

interface IProps {
  children: React.ReactNodeArray;
  className?: string;
}

const GlideComponent = ({ children, className }: IProps): ReactElement => {
  const glideRef = useRef<HTMLDivElement>(null);
  const [currentActive, setCurrentActive] = useState(0);

  const { isMobile } = useBreakpoints();

  const glideInstance = useRef<any>(null);

  const numberOfSlides = children.length;

  const setIndex = () => {
    if (glideInstance.current) {
      setCurrentActive(glideInstance.current?.index);
    }
  };

  useEffect(() => {
    let glide: Glide | undefined;

    if (glideRef.current) {
      glide = new Glide(glideRef.current, gliderOptions);
      glideInstance.current = glide;
      glide.mount();
      glide.on("run", setIndex);
    }

    return () => {
      if (glideRef.current && glide) glide.destroy();
    };
  }, [numberOfSlides]);

  const currentPerView = glideInstance.current?.settings?.perView;

  const isLeftButtonHidden = currentActive === 0;
  const isRightButtonHidden =
    currentPerView >= numberOfSlides ||
    currentActive === numberOfSlides - currentPerView;

  return (
    <div className={className}>
      {!isMobile && (
        <ButtonIcon
          type="button"
          icon={Icon.icons.chevronLeft}
          className={cx(
            s.glideButton,
            s.glideButton_left,
            isLeftButtonHidden && s.glideButton_hidden
          )}
          onClick={() => glideInstance.current?.go("|<")}
        />
      )}
      <div className={s.glideContainer}>
        <div ref={glideRef} className={cx(s.glide, "glide")}>
          <div className="glide__track" data-glide-el="track">
            <ul className="glide__slides">
              {children.map((slide: ReactElement, index: number) => (
                <li key={`glide_slide_${index + 1}`} className="glide__slide">
                  {slide}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
      {!isMobile && (
        <ButtonIcon
          icon={Icon.icons.chevronRight}
          type="button"
          className={cx(
            s.glideButton,
            s.glideButton_right,
            isRightButtonHidden && s.glideButton_hidden
          )}
          onClick={() => glideInstance.current?.go("|>")}
        />
      )}
    </div>
  );
};

export default GlideComponent;
