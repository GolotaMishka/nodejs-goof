import React, { ReactElement, useEffect } from "react";
import cx from "classnames";
import { idGenerator } from "app/utils";
import { useBreakpoints } from "data/hooks/breakpoints";
import sliderItemAnimationData from "public/animations/slider-item.json";
import ReactTooltip from "react-tooltip";
import Glide from "./glide";
import Lottie from "../lottie";
import s from "./styles.scss";

interface IProps {
  children: ReactElement[];
  className?: string;
  isLoading?: boolean;
}

const Slider = ({
  children,
  className,
  isLoading = false,
}: IProps): ReactElement => {
  const { isMobile } = useBreakpoints();

  useEffect(() => {
    ReactTooltip.rebuild();
  });

  const slides = isLoading
    ? [...Array(20)].map(() => (
        <div className={s.sliderItem} key={idGenerator()}>
          <Lottie animationData={sliderItemAnimationData} />
        </div>
      ))
    : children.map((slide) => (
        <div key={idGenerator()} className={s.sliderItem}>
          {slide}
        </div>
      ));

  const Component = isMobile ? "div" : Glide;

  return <Component className={cx(s.slider, className)}>{slides}</Component>;
};

export default Slider;
