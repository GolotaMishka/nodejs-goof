import React, { ReactElement } from "react";
import cx from "classnames";
import { useBreakpoints } from "data/hooks/breakpoints";
import { Avatar, Text, Button, Icon } from "ui";
import HistorySlider from "app/components/core/history-slider";
import RecommendationsSlider from "app/components/core/recommendations-slider";
import {
  ExtendedItemEntity,
  HistoryItemEntity,
  ItemEntity,
  PersonaEntity,
  useUpdatePersona,
} from "data";
import colors from "ui/styles/_colors.scss";
import { useToggleState } from "app/utils/hooks";
import s from "./styles.scss";

type SetContextItemType = (item: ItemEntity) => void;

interface IProps {
  className?: string;
  persona?: PersonaEntity;
  items?: ExtendedItemEntity[] | [];
  hasContextItem?: boolean;
  hasCodeButton?: boolean;
  openCode?: () => void;
  setContextItem?: SetContextItemType;
}

const RecommendationCard = ({
  className,
  persona,
  items = [],
  openCode,
  hasContextItem,
  hasCodeButton = false,
  setContextItem,
}: IProps): ReactElement => {
  const [historyOpened, toggleHistoryOpened] = useToggleState(false);
  const { isMobile, isTablet } = useBreakpoints();
  const { mutate: updatePersona } = useUpdatePersona();

  const addItemToPersonaHistory = (item: ExtendedItemEntity) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { isInPersonaHistory, ...originalItem } = item;
    const newHistoryItem: HistoryItemEntity = {
      item: originalItem,
      isEnabled: true,
      secondsAgo: 60,
    };
    updatePersona({
      personaId: persona?.id as string,
      values: {
        items: [...(persona?.items as HistoryItemEntity[]), newHistoryItem],
      },
    });
  };

  const renderHistoryButton = () => (
    <Button
      className={s.cardHeaderHistoryButton}
      iconRight
      icon={Icon.icons[historyOpened ? "chevronDown" : "chevronUp"]}
      onClick={toggleHistoryOpened}
    >
      <Text weight="bold" color="accent">
        {historyOpened ? "Hide history" : "Show history"}
      </Text>
    </Button>
  );

  return (
    <div className={cx(s.card, className)}>
      <div className={s.cardHeader}>
        {persona && (
          <div className={s.cardHeaderInfo}>
            {persona.avatar && (
              <Avatar className={s.cardHeaderAvatar} img={persona.avatar} />
            )}
            <div className={s.cardHeaderInfoWrapper}>
              <Text
                color="primary"
                weight="bold"
                component="p"
                className={s.cardHeaderInfoName}
                title={persona.name}
              >
                {persona.name}
              </Text>
              <Text
                size="s"
                color="primary"
                component="p"
                title={persona.role}
                className={s.cardHeaderInfoAbout}
              >
                {persona.role}
                {isMobile ? <br /> : " | "}
                {persona.version?.name}
              </Text>
            </div>
          </div>
        )}
        <div className={s.cardHeaderActions}>
          {hasCodeButton && (
            <button
              type="button"
              onClick={openCode}
              className={s.cardHeaderCodeButton}
            >
              <Icon icon={Icon.icons.code} color={colors.accent} />
            </button>
          )}
          {isTablet && renderHistoryButton()}
        </div>
      </div>
      {isMobile && (
        <section className={s.cardHistoryButtonSection}>
          {renderHistoryButton()}
        </section>
      )}
      {historyOpened && persona && (
        <section className={s.history}>
          <Text
            weight="bold"
            className={s.sectionHeading}
            color={isMobile ? "secondary" : "primary"}
          >
            History
          </Text>
          {persona.items?.length ? (
            <HistorySlider
              className={s.historySlider}
              items={persona.items}
              personaId={persona.id}
            />
          ) : (
            <Text component="p" className={s.noHistoryMessage}>
              This persona has no history
            </Text>
          )}
        </section>
      )}
      <section className={s.recommendations}>
        <Text
          weight="bold"
          className={s.sectionHeading}
          color={isMobile ? "secondary" : "primary"}
        >
          Recommendations
        </Text>
        <RecommendationsSlider
          className={s.historySlider}
          items={items}
          hasContextItem={!!hasContextItem}
          setContextItem={setContextItem as SetContextItemType}
          addItemToHistory={addItemToPersonaHistory}
        />
      </section>
    </div>
  );
};

export default RecommendationCard;
