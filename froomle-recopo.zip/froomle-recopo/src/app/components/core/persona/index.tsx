import React, { ReactElement, ChangeEvent } from "react";
import cx from "classnames";
import { SortableHandle, SortableElement } from "react-sortable-hoc";
import { Avatar, ButtonIcon, Icon, Text, Toggle } from "ui";
import { PersonaEntity, useUpdatePersona } from "data";
import HistorySlider from "app/components/core/history-slider";
import { useBreakpoints } from "data/hooks/breakpoints";
import s from "./styles.scss";

interface IProps {
  className?: string;
  persona: PersonaEntity;
  dataCy?: string;
  onDeletePersonaClick?: (id: string) => void;
  onClonePersonaClick?: (persona: PersonaEntity) => void;
  onEditPersonaClick?: (id: string) => void;
  onManageHistoryClick?: (id: string) => void;
}

const DragHandle = SortableHandle((props) => (
  <ButtonIcon icon={Icon.icons.move} {...props} />
));

const PersonaCard = ({
  className,
  persona,
  dataCy,
  onEditPersonaClick,
  onDeletePersonaClick,
  onClonePersonaClick,
  onManageHistoryClick,
}: IProps): ReactElement => {
  const { mutate: updatePersona } = useUpdatePersona();

  const { isSmallDesktop } = useBreakpoints();

  const toggleIsEnabled = (e: ChangeEvent<HTMLInputElement>) => {
    const values = { isEnabled: e.target.checked };
    updatePersona({ personaId: persona?.id as string, values });
  };

  const deletePersona = () => onDeletePersonaClick?.(persona.id);

  const clonePersona = () => onClonePersonaClick?.(persona);

  const editPersona = () => onEditPersonaClick?.(persona.id);

  const manageHistory = () => onManageHistoryClick?.(persona.id);

  return (
    <div className={cx(s.card, className)} data-cy={dataCy}>
      <div className={s.cardHeader}>
        {isSmallDesktop && (
          <div
            className={cx(s.cardHeaderInfo, !persona.isEnabled && s.disabled)}
          >
            {persona.avatar && (
              <Avatar className={s.cardHeaderAvatar} img={persona.avatar} />
            )}
            <Text
              color="primary"
              weight="bold"
              component="p"
              className={s.cardHeaderInfoName}
              title={persona.name}
            >
              {persona.name}
            </Text>
            <Text
              size="s"
              color="primary"
              component="p"
              title={persona.role}
              className={s.cardHeaderInfoAbout}
            >
              {`${persona.role} | ${persona.version?.name}`}
            </Text>
          </div>
        )}
        <div className={s.cardHeaderActions}>
          {isSmallDesktop && (
            <ButtonIcon
              iconLeft
              icon={Icon.icons.editPen}
              onClick={editPersona}
              data-cy={`edit-persona-${persona.id}`}
            >
              Edit
            </ButtonIcon>
          )}
          <ButtonIcon
            iconLeft
            icon={Icon.icons.copy}
            className={s.cardHeaderButton}
            onClick={clonePersona}
            data-cy={`clone-persona-${persona.id}`}
          >
            Clone
          </ButtonIcon>
          <ButtonIcon
            iconLeft
            icon={Icon.icons.trash}
            className={s.cardHeaderButton}
            onClick={deletePersona}
            data-cy={`remove-persona-${persona.id}`}
          >
            Delete
          </ButtonIcon>
          <Toggle
            value={persona.isEnabled}
            onChange={toggleIsEnabled}
            className={s.cardHeaderToggle}
            wrapperProps={{
              "data-cy": `enable-persona-${persona.id}`,
            }}
          />
          {isSmallDesktop && <DragHandle className={s.dragHandle} />}
        </div>
      </div>
      {!isSmallDesktop && (
        <div className={s.cardInfoSection}>
          <Avatar
            className={cx(
              s.cardInfoSectionAvatar,
              !persona.isEnabled && s.disabled
            )}
            img={persona.avatar}
          />
          <div
            className={cx(
              s.cardInfoSectionInfo,
              !persona.isEnabled && s.disabled
            )}
          >
            <Text
              className={s.cardInfoSectionName}
              color="primary"
              weight="bold"
              component="p"
              title={persona.name}
            >
              {persona.name}
            </Text>
            <Text size="s" color="primary" component="p" title={persona.role}>
              {persona.role}
            </Text>
            <Text size="s" color="primary" component="p" title={persona.role}>
              {persona.version?.name}
            </Text>
          </div>
          <div className={s.cardInfoSectionActions}>
            <ButtonIcon
              icon={Icon.icons.editPen}
              onClick={editPersona}
              data-cy={`edit-persona-${persona.id}`}
            />
            <DragHandle className={s.dragHandle} />
          </div>
        </div>
      )}
      <div className={cx(s.history, !persona.isEnabled && s.disabled)}>
        <div className={s.historyHeader}>
          <Text
            size="m"
            weight="bold"
            color={isSmallDesktop ? "primary" : "secondary"}
          >
            Browsing history
          </Text>
          <ButtonIcon
            iconLeft={isSmallDesktop}
            icon={Icon.icons.editPen}
            onClick={manageHistory}
            data-cy={`manage-history-${persona.id}`}
          >
            {isSmallDesktop && "Manage history"}
          </ButtonIcon>
        </div>
        <HistorySlider
          className={s.historySlider}
          items={persona.items}
          personaId={persona.id}
        />
      </div>
    </div>
  );
};

PersonaCard.displayName = "PersonaCard";

export default SortableElement(PersonaCard);
