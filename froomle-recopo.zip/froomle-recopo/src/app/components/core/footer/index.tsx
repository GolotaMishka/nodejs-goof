import React, { ReactElement } from "react";
import { Button, Icon, Text } from "ui";

import s from "./styles.scss";

const Footer = (): ReactElement => {
  return (
    <footer className={s.footer}>
      <Button
        variant="transparent"
        component="a"
        href="mailto:servicedesk@froomle.com?subject=[RECOPO] Mail from Recommendation Portal"
        iconLeft={Icon.icons.mail}
        className={s.footerButton}
        data-tour="contact-button"
        target="_blank"
      >
        Contact us
      </Button>
      <div className={s.footerLinks}>
        <Text component="p" color="light" size="s">
          © Copyright 2021. All Rights Reserved
          {" | "}
          <a
            href="https://www.froomle.ai/privacy-policy"
            target="_blank"
            rel="noreferrer"
            className={s.footerLink}
          >
            Privacy policy
          </a>
          {" | "}
          <a
            href="https://www.froomle.ai/cookies"
            target="_blank"
            rel="noreferrer"
            className={s.footerLink}
          >
            Cookie policy
          </a>
        </Text>
      </div>
    </footer>
  );
};

export default Footer;
