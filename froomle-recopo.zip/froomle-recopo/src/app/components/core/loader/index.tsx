import { idGenerator } from "@panenco/ui";
import templateAnimationData from "public/animations/template.json";
import React, { ReactElement } from "react";
import { Icon } from "ui";
import Lottie from "../lottie";
import s from "./styles.scss";

const PageLoader = (): ReactElement => {
  return <Icon icon={Icon.icons.froomle} className={s.pageLoader} size={300} />;
};

export const SkeletonLoader = (): ReactElement => {
  return (
    <div className={s.grid}>
      {[...Array(6)].map(() => (
        <div className={s.gridItem} key={idGenerator()}>
          <Lottie animationData={templateAnimationData} />
        </div>
      ))}
    </div>
  );
};

export default PageLoader;
