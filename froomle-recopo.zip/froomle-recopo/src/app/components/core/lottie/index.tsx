import React, { ReactElement } from "react";
import AnimationComponent from "react-lottie";

const defaultOptions = {
  loop: true,
  autoplay: true,
  rendererSettings: {
    preserveAspectRatio: "none",
    className: "no-fill",
  },
};

interface IProps {
  animationData: any;
}

const Lottie = ({ animationData, ...props }: IProps): ReactElement => {
  return (
    <AnimationComponent
      options={{ ...defaultOptions, animationData }}
      {...props}
    />
  );
};

export default Lottie;
