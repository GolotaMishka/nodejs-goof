import React, { ChangeEvent, ReactElement } from "react";
import HistorySlider from "app/components/core/history-slider";
import cx from "classnames";
import { SortableHandle } from "react-sortable-hoc";
import { Button, ButtonIcon, Icon, Text, Toggle, Avatar } from "ui";
import {
  PersonaEntity,
  useCreatePersona,
  useUpdatePersona,
  useListPersonas,
} from "data";
import s from "./styles.scss";

interface IProps {
  className?: string;
  persona: PersonaEntity;
  onDeletePersonaClick?: (id: string) => void;
  onEditClick?: () => void;
  onManageHistoryClick?: () => void;
}

const DragHandle = SortableHandle(() => <ButtonIcon icon={Icon.icons.move} />);

const getNameForClone = (name: string, names: string[] = []) => {
  for (let i = 1; ; i += 1) {
    const nextPossibleName = `${name} (${i})`;
    if (!names.includes(nextPossibleName)) return nextPossibleName;
  }
};

const Persona = ({
  className,
  persona,
  onDeletePersonaClick,
  onEditClick,
  onManageHistoryClick,
}: IProps): ReactElement => {
  const { data: personas } = useListPersonas();

  const { mutate: clonePersona } = useCreatePersona();

  const { mutate: updatePersona } = useUpdatePersona();

  const toggleIsEnabled = (e: ChangeEvent<HTMLInputElement>) => {
    const values = { isEnabled: e.target.checked };
    updatePersona({ personaId: persona?.id as string, values });
  };

  const deletePersona = () => {
    if (onDeletePersonaClick) {
      onDeletePersonaClick(persona.id);
    }
  };

  const handleCloneClick = () => {
    const { name, isEnabled, items, role, versionId, rank, avatar } = persona;
    const allNames = personas?.map((p) => p.name);
    clonePersona({
      avatar,
      name: getNameForClone(name, allNames),
      isEnabled,
      items,
      role,
      versionId,
      rank: rank + 1,
    });
  };

  return (
    <div
      className={cx(s.card, className, !persona.isEnabled && s.card_disabled)}
    >
      <div className={s.cardSectionWrapper}>
        <div className={cx(s.cardHeader, s.cardSection)}>
          <ButtonIcon
            iconLeft
            icon={Icon.icons.trash}
            className={s.cardHeaderButton}
            onClick={deletePersona}
            data-cy={`remove-persona-${persona.id}`}
          >
            Delete
          </ButtonIcon>
          <ButtonIcon
            iconLeft
            icon={Icon.icons.copy}
            className={s.cardHeaderButton}
            onClick={handleCloneClick}
            data-cy={`clone-persona-${persona.id}`}
          >
            Clone
          </ButtonIcon>
          <Toggle
            value={persona.isEnabled}
            onChange={toggleIsEnabled}
            className={s.cardHeaderToggle}
            wrapperProps={{
              "data-cy": `enable-persona-${persona.id}`,
            }}
          />
        </div>
      </div>
      <div className={s.cardSectionWrapper}>
        <div className={cx(s.cardContent, s.cardSection)}>
          {persona.avatar && <Avatar img={persona.avatar} type="big" />}
          <div className={s.cardContentColumn}>
            <Text
              color="primary"
              weight="bold"
              component="p"
              className={s.cardContentText}
              title={persona.name}
            >
              {persona.name}
            </Text>
            <Text
              size="s"
              color="secondary"
              component="p"
              title={persona.role}
              className={s.cardContentText}
            >
              {persona.role}
            </Text>
            <Text
              size="s"
              color="secondary"
              title={persona?.version?.name}
              component="p"
              className={s.cardContentText}
            >
              {persona?.version?.name}
            </Text>
          </div>
          <div className={cx(s.cardContentColumn, s.cardContentIcons)}>
            <ButtonIcon
              icon={Icon.icons.editPen}
              onClick={onEditClick}
              data-cy={`edit-persona-${persona.id}`}
            />
            <DragHandle />
          </div>
        </div>
      </div>

      <div className={s.cardSectionWrapper}>
        <div className={cx(s.cardSection, s.cardHistory)}>
          <Text
            weight="bold"
            color="secondary"
            size="s"
            className={s.cardHistoryTitle}
          >
            Browsing history:
          </Text>
          <HistorySlider
            className={s.cardHistoryContent}
            items={persona.items}
            personaId={persona.id}
          />
        </div>
      </div>

      <div className={s.cardSectionWrapper}>
        <div className={cx(s.cardFooter, s.cardSection)}>
          <Button
            className={s.cardFooterButton}
            variant="transparent"
            onClick={onManageHistoryClick}
            data-cy={`manage-history-${persona.id}`}
          >
            Manage history
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Persona;
