import React, { ReactElement, useMemo, useCallback } from "react";
import { Formik, Form } from "formik";
import Field from "app/utils/form-field";
import {
  VersionEntity,
  validationSchemas,
  useListVersions,
  useCreatePersona,
  useUpdatePersona,
  useListPersonas,
  PersonaEntity,
} from "data";
import {
  flatifySelectOptions,
  createOptions,
  toSelectOption,
  generateRandomAvatar,
} from "app/utils";
import type { SelectOption } from "app/utils/generics";
import {
  Button,
  Text,
  PrimaryButton,
  Avatar,
  ButtonIcon,
  Icon,
  TextInput,
  SelectInput,
} from "ui";
import cx from "classnames";
import s from "./styles.scss";

export interface EditPersonaProps {
  personaId?: string;
  onClose: (createdPersona?: PersonaEntity) => void;
  onCancel?: () => void;
  className?: string;
}

type Values = {
  isEnabled?: boolean;
  name?: string;
  versionId?: SelectOption | null;
  role?: string;
  avatar?: string | null;
};

export const EditPersona = ({
  personaId,
  onClose,
  onCancel,
}: EditPersonaProps): ReactElement => {
  const { data: personas } = useListPersonas();

  const persona = personas?.find((p) => String(p.id) === personaId);

  const isNew = !personaId || !persona;

  const { data: versions, isLoading: versionsLoading } = useListVersions();

  const { mutateAsync: createPersona } = useCreatePersona();

  const { mutateAsync: updatePersona } = useUpdatePersona();

  const initialValues = useMemo<Values>(
    () => ({
      isEnabled: isNew ? true : persona?.isEnabled,
      name: isNew ? "" : persona?.name,
      role: isNew ? "" : persona?.role,
      avatar: isNew ? null : persona?.avatar,
      isNew: isNew || undefined,
      versionId: isNew
        ? null
        : toSelectOption(persona?.version as VersionEntity),
    }),
    [versions]
  );

  const handleSubmit = useCallback(
    async (values: Values) => {
      const cleanValues = flatifySelectOptions(values);
      if (isNew) {
        const avatar =
          (cleanValues.avatar as string | null) || generateRandomAvatar();
        await createPersona(
          { ...cleanValues, avatar },
          {
            onSuccess: (createdPersona) => {
              if (onClose) onClose(createdPersona);
            },
          }
        );
      } else {
        await updatePersona(
          {
            personaId: persona?.id as string,
            values: cleanValues,
          },
          {
            onSuccess: (updatedPersona) => {
              if (onClose) onClose(updatedPersona);
            },
          }
        );
      }
    },
    [isNew]
  );

  const renderNoOptionsMessage = useCallback(
    () => (
      <Text>
        This environment still has to be prepared by our team, please{" "}
        <a href="mailto:servicedesk@froomle.com?subject=[RECOPO] Mail from Recommendation Portal">
          contact us
        </a>
      </Text>
    ),
    []
  );

  const handleCancelClick = () => {
    if (onCancel) onCancel();
    else onClose();
  };

  return (
    <Formik
      enableReinitialize
      validationSchema={validationSchemas.EditPersonaSchema}
      onSubmit={handleSubmit}
      initialValues={initialValues}
    >
      {({ values, setFieldValue, isSubmitting }) => (
        <Form
          className={cx(s.card, s.edit)}
          id={isNew ? "new-persona" : undefined}
        >
          <div className={cx(s.modal, s.modalContent)}>
            <div className={s.modalAvatarSection}>
              <Avatar type="big" img={values.avatar} />
              <ButtonIcon
                type="button"
                onClick={() => setFieldValue("avatar", generateRandomAvatar())}
                icon={Icon.icons.refresh}
                iconLeft
              >
                Generate new avatar
              </ButtonIcon>
            </div>
            <Field
              component={TextInput}
              name="name"
              title="Name*"
              className={s.modalEditField}
            />
            <Field
              component={SelectInput}
              name="versionId"
              className={s.modalEditField}
              title="User version"
              isSearchable={false}
              options={createOptions(versions)}
              isDisabled={versionsLoading}
              onChangeAdapter={(option) => option}
              noOptionsMessage={renderNoOptionsMessage}
              selectWrapperProps={{ "data-cy": "version-select" }}
              usePortal
            />
            <Field
              component={TextInput}
              name="role"
              title="Role*"
              className={s.modalEditField}
            />
          </div>
          <div className={s.modalFooter}>
            <Button onClick={handleCancelClick} type="button">
              Cancel
            </Button>
            <PrimaryButton type="submit" isLoading={isSubmitting}>
              {isNew ? "Create" : "Save"}
            </PrimaryButton>
          </div>
        </Form>
      )}
    </Formik>
  );
};
