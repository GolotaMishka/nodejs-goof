import React, { ReactElement, useCallback, useState } from "react";
import { HistorySelect } from "app/components/core/selects";
import { Tab, Tabs } from "app/components/core/tabs";
import cx from "classnames";
import {
  Button,
  ButtonIcon,
  Icon,
  PrimaryButton,
  Text,
  ConfirmModal,
} from "ui";
import { getHistoryItemTitle } from "app/utils";
import {
  HistoryItemEntity,
  ItemEntity,
  useListHistoryItems,
  useImportHistoryItemsByIds,
  useStore,
  useUpdatePersona,
  useListPersonas,
  PersonaEntity,
} from "data";
import { useDebounce, useToggleState } from "app/utils/hooks";
import s from "./styles.scss";

interface IProps {
  personaId?: string;
  onClose: (createdPersona?: PersonaEntity) => void;
  onCancel?: () => void;
  className?: string;
}

export const ManageHistory = ({
  personaId,
  onClose,
  className,
  onCancel,
}: IProps): ReactElement => {
  const [modalOpened, toggleModalOpened] = useToggleState(false);
  const [itemSearch, setItemSearch] = useState("");
  const [orderByPopularity, setOrderByPopularity] = useState(true);
  const { data: personas } = useListPersonas();

  const currentHistory =
    personas?.find((p) => String(p.id) === personaId)?.items ?? [];

  const [history, setHistory] = useState(
    new Map(
      currentHistory.map((historyItem) => [
        historyItem.item.froomleItemId || historyItem.item.clientItemId,
        historyItem,
      ])
    )
  );

  const { env } = useStore();

  const debouncedItemSearch = useDebounce(itemSearch);

  const {
    data: historyItems,
    isFetching: isFetchingHistoryItems,
  } = useListHistoryItems(debouncedItemSearch, 10, orderByPopularity);

  const {
    data: itemsByIds,
    mutate: fetchHistoryItemsByIds,
    isLoading: isFetchingHistoryItemsByIds,
  } = useImportHistoryItemsByIds();

  const { mutate: updatePersona } = useUpdatePersona();

  const handleFilterChange = (filter) => {
    setOrderByPopularity(filter === "Popular");
  };

  const deleteHistoryItem = (id: string | number) => {
    const newHistory = new Map(history);

    newHistory.delete(id);

    setHistory(newHistory);
  };

  const searchByIds = useCallback((inputValue: string) => {
    if (inputValue.length > 0) {
      const regexp = /[\s,;]+/g;
      const items = inputValue.split(regexp);

      if (items.length > 0) {
        const froomleItemIds: number[] = [];

        items.forEach((item) => {
          const idToNumber = Number(item);

          if (!Number.isNaN(idToNumber)) {
            froomleItemIds.push(Number(item));
          }
        });

        fetchHistoryItemsByIds({ froomleItemIds, clientItemIds: items });
      }
    }
  }, []);

  const addHistoryItems = useCallback(
    (selectedOptions: ItemEntity[]) => {
      if (selectedOptions.length > 0) {
        const uniqueItems: Map<string | number, HistoryItemEntity> = new Map();

        selectedOptions.forEach((option) => {
          if (
            (option.froomleItemId && !history.has(option.froomleItemId)) ||
            (option.clientItemId && !history.has(option.clientItemId))
          ) {
            uniqueItems.set(option.froomleItemId || option.clientItemId, {
              item: option,
              isEnabled: true,
              personaId: personaId as string,
              itemId: String(option.froomleItemId || option.clientItemId),
              secondsAgo: 60,
            });
          }
        });
        if (uniqueItems.size) {
          setHistory(new Map([...history, ...uniqueItems]));
        }
      }
    },
    [personaId, currentHistory, history]
  );

  const clearHistory = useCallback(() => {
    toggleModalOpened();
    setHistory(new Map());
  }, [modalOpened]);

  const onSave = () => {
    updatePersona({
      personaId: personaId as string,
      values: {
        items: Array.from(history.values()).map(
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          ({ itemId, ...withoutItemId }) => withoutItemId
        ) as HistoryItemEntity[],
      },
    });

    if (onClose) onClose();
  };

  const renderHistoryList = () => (
    <ul className={cx(s.historySection, s.historyItems)}>
      {Array.from(history).map(([, historyItem]) => {
        const itemTitle = getHistoryItemTitle(historyItem, env?.language);
        return (
          <li
            className={s.historyItem}
            key={`history_item_${
              historyItem.item.froomleItemId || historyItem.item.clientItemId
            }`}
            data-cy="history-item"
          >
            <ButtonIcon
              icon={Icon.icons.exclude}
              className={s.historyButton}
              data-cy="remove-history-item"
              onClick={() =>
                deleteHistoryItem(
                  historyItem.item.froomleItemId ||
                    historyItem.item.clientItemId
                )
              }
            />
            <Text className={s.historyItemText} color="dark" title={itemTitle}>
              {itemTitle}
            </Text>
          </li>
        );
      })}
    </ul>
  );

  const handleCancelClick = () => {
    if (onCancel) onCancel();
    else onClose();
  };

  return (
    <div className={cx(s.modal, className)}>
      <div className={cx(s.modalContent, s.historyModalContent)}>
        <Tabs tabs={["Name", "Id"]}>
          <Tab className={s.historyTab}>
            <div className={s.historySection}>
              <HistorySelect
                placeholder="Type articles, products"
                onInputChange={setItemSearch}
                onSubmit={addHistoryItems}
                filters={["Popular", "Recent"]}
                onFilterChange={handleFilterChange}
                options={historyItems}
                isLoading={isFetchingHistoryItems}
              />
              <div className={s.historyTabHeader}>
                <ButtonIcon
                  onClick={toggleModalOpened}
                  icon={Icon.icons.trash}
                  className={s.historyButton}
                />
                <Text weight="bold" size="s" color="secondary">
                  History
                </Text>
              </div>
            </div>
            {renderHistoryList()}
          </Tab>
          <Tab className={s.historyTab}>
            <div className={s.historySection}>
              <HistorySelect
                placeholder="Type ID(s)"
                initialSelected
                onInputChange={searchByIds}
                onSubmit={addHistoryItems}
                options={itemsByIds}
                isLoading={isFetchingHistoryItemsByIds}
              />
              <div className={s.historyTabHeader}>
                <ButtonIcon
                  onClick={toggleModalOpened}
                  icon={Icon.icons.trash}
                  className={s.historyButton}
                />
                <Text weight="bold" size="s" color="secondary">
                  History
                </Text>
              </div>
            </div>
            {renderHistoryList()}
          </Tab>
        </Tabs>
      </div>
      <div className={s.historyFooter}>
        <Button onClick={handleCancelClick} data-cy="cancel-history">
          Cancel
        </Button>
        <PrimaryButton onClick={onSave} data-cy="save-history">
          Save
        </PrimaryButton>
      </div>
      {modalOpened && (
        <ConfirmModal
          onClose={toggleModalOpened}
          title="Delete all history"
          onSubmit={clearHistory}
          submitText="Delete"
        >
          <Text>Are you sure you want to delete all history?</Text>
        </ConfirmModal>
      )}
    </div>
  );
};
