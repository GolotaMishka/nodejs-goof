import { PersonaEntity } from "data";
import React, { ReactElement, useState } from "react";
import cx from "classnames";
import { Modal, Text } from "ui";
import { EditPersona } from "./edit";
import { ManageHistory } from "./history";
import s from "./styles.scss";

type Props = {
  onClose: () => void;
  onExitAfterCreatedPersona?: () => void;
};

export const CreatePersonaModal = ({
  onClose,
  onExitAfterCreatedPersona = () => null,
}: Props): ReactElement => {
  const [step, setStep] = useState(0);
  const [persona, setPersona] = useState<PersonaEntity | null>(null);

  const renderTitleWithSteps = () => (
    <div className={s.createHeader}>
      <Text color="light" weight="bold">
        Persona creation
      </Text>
      <div className={s.createHeaderSteps}>
        {[1, 2].map((x) => {
          const isActive = x === step + 1;
          return (
            <div
              key={`step_${x}`}
              className={cx(
                s.createHeaderStep,
                isActive && s.createHeaderStep_active
              )}
            >
              {x}
            </div>
          );
        })}
      </div>
    </div>
  );

  const creationSteps = [
    () => (
      <EditPersona
        onClose={(createdPersona) => {
          setStep(1);
          setPersona(createdPersona || null);
        }}
        onCancel={onClose}
      />
    ),
    () => (
      <ManageHistory
        onClose={() => {
          setStep(0);
          onExitAfterCreatedPersona();
          onClose();
        }}
        onCancel={() => {
          onExitAfterCreatedPersona();
          onClose();
        }}
        personaId={persona?.id as string}
      />
    ),
  ];

  return (
    <Modal onClose={onClose} title={renderTitleWithSteps()}>
      {creationSteps[step]()}
    </Modal>
  );
};
