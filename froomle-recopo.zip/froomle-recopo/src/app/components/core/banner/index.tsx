import React, { ReactElement } from "react";
import cx from "classnames";
import s from "./styles.scss";

interface IProps {
  children: React.ReactNode;
  className?: string;
}
const Banner = ({ children, className }: IProps): ReactElement => {
  return <div className={cx(s.banner, className)}>{children}</div>;
};

export default Banner;
