import { basePath } from "app/constants/url";
import React, { ReactElement } from "react";
import { Link } from "react-router-dom";
import { GridContainer } from "ui";
import Logo from "public/logo.svg";

import s from "./styles.scss";

export interface LayoutPublicProps {
  children: React.ReactNode;
}

const PublicLayout = ({ children }: LayoutPublicProps): ReactElement => (
  <div className={s.layout}>
    <div className={s.layoutHeader}>
      <GridContainer>
        <Link to={basePath}>
          <img className={s.layoutHeaderLogo} src={Logo} alt="Froomle logo" />
        </Link>
      </GridContainer>
    </div>

    <div className={s.content}>{children}</div>
  </div>
);

export default PublicLayout;
