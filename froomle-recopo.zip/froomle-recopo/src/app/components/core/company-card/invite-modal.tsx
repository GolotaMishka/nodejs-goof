/* eslint-disable no-nested-ternary */
import {
  Loader,
  PrimaryButton,
  SelectInput,
  TextArea,
  toast,
} from "@panenco/ui";
import Field from "app/utils/form-field";
import {
  CreationStep,
  useAuth,
  useListRoles,
  useRefresh,
  validationSchemas,
} from "data";
import { useCreateInvite } from "data/hooks/companies";
import { CompanyDetail, CompanyEntity } from "data/utils/types";
import { Form, Formik } from "formik";
import React, { ReactElement, useEffect } from "react";
import { Trans, useTranslation } from "react-i18next";
import { Button, Modal, Text, TextInput } from "ui";
import s from "./styles.scss";

type ModalProps = {
  company: CompanyEntity | CompanyDetail;
  isOpen: boolean;
  closeFunction: () => void;
  step?: CreationStep | null;
};

export const InviteModal = ({
  company,
  isOpen,
  closeFunction,
  step,
}: ModalProps): ReactElement => {
  const { t } = useTranslation();
  const { refreshToken, roles: orgRoles, companyId } = useAuth();
  const { mutate: refresh, isLoading: isRefreshing } = useRefresh();

  const {
    mutate: createInvite,
    isSuccess: isCreateInviteSuccess,
  } = useCreateInvite(company.id);

  useEffect(() => {
    if (isOpen && companyId !== company.id)
      refresh({ token: refreshToken, companyId: company.id });
  }, [isOpen]);

  useEffect(() => {
    if (isCreateInviteSuccess) {
      closeFunction();
      (toast as any).success(t("inviteSent"));
    }
  }, [isCreateInviteSuccess]);

  const { data: roles } = useListRoles();

  const roleOptions = roles?.map((role) => ({
    label: (
      <span>
        {role.name}
        <Text size="xs">{` (${role.description})`}</Text>
      </span>
    ),
    value: role.id,
  }));
  return (
    <>
      {isOpen && (
        <Modal
          title={t("actions.inviteColleague")}
          onClose={() => closeFunction()}
          className={s.inviteModal}
        >
          {isRefreshing ? (
            <div className={s.inviteWrapper}>
              <Loader />
            </div>
          ) : orgRoles?.some((x) => x.name === "admin") ? (
            <Formik
              enableReinitialize
              validationSchema={validationSchemas.InviteSchema}
              onSubmit={(values) =>
                createInvite({ ...values, roleIds: [values.role], step })
              }
              initialValues={{
                email: "",
                role: "",
                message: t("inviteMessage"),
              }}
            >
              {({ isValid, dirty, isSubmitting }) => (
                <Form className={s.invite}>
                  <Field
                    component={TextInput}
                    id="email"
                    name="email"
                    title={t("titles.email")}
                    placeholder="example@example.com"
                    disabled={isSubmitting}
                    className={s.inviteField}
                    inputClassName={s.inviteFieldInput}
                  />
                  <Field
                    component={TextArea}
                    id="message"
                    name="message"
                    title={t("titles.message")}
                    placeholder={t("titles.message")}
                    disabled={isSubmitting}
                    className={s.inviteField}
                    inputClassName={s.inviteFieldInput}
                  />
                  <Field
                    component={SelectInput}
                    title={t("titles.role")}
                    placeholder={t("chooseRole")}
                    name="role"
                    options={roleOptions}
                    onChangeAdapter={(option) => option.value}
                    valueAdapter={(v) =>
                      roleOptions?.find((role) => role.value === v)
                    }
                    className={s.inviteField}
                  />
                  <div className={s.inviteActions}>
                    <Button variant="transparent" onClick={closeFunction}>
                      <Trans i18nKey="cancel" />
                    </Button>
                    <PrimaryButton
                      className={s.inviteButton}
                      disabled={!isValid || !dirty}
                      type="submit"
                    >
                      <Trans i18nKey="invite" />
                    </PrimaryButton>
                  </div>
                </Form>
              )}
            </Formik>
          ) : (
            <Text className={s.inviteWrapper}>
              {t("youDontHavePermissionToInvite")}
            </Text>
          )}
        </Modal>
      )}
    </>
  );
};
