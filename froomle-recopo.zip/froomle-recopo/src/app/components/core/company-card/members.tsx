/* eslint-disable no-nested-ternary */
import cx from "classnames";
import { CompanyEntity } from "data/utils/types";
import React, { ReactElement, useState } from "react";
import { Avatar, Text } from "ui";
import { InviteModal } from "./invite-modal";
import s from "./styles.scss";

export const Members = ({
  company,
}: {
  company: CompanyEntity;
}): ReactElement => {
  const [inviteModalOpen, setInviteModalOpen] = useState(false);

  return (
    <>
      {company.members?.length ? (
        <div className={s.cardHeaderRightMembers}>
          {company.members?.map((member) => {
            return (
              <Avatar
                key={member.picture}
                type="small"
                img={member.picture}
                className={s.avatar}
              />
            );
          })}
          {company.invitedEmails?.map((email) => {
            return (
              <Avatar
                key={email}
                type="small"
                className={s.avatar}
                text={email}
              />
            );
          })}
          <button
            className={cx(s.button, s.avatar)}
            onClick={() => setInviteModalOpen(true)}
          >
            <Text weight="bold" color="light" size="l">
              +
            </Text>
          </button>
        </div>
      ) : null}
      <InviteModal
        company={company}
        isOpen={inviteModalOpen}
        closeFunction={() => setInviteModalOpen(false)}
      />
    </>
  );
};
