/* eslint-disable no-nested-ternary */
import { companyWizardPath, homePath } from "app/constants/url";
import { CompanyStatus, useAuth, useCompanyDetail, useRefresh } from "data";
import { CompanyEntity } from "data/utils/types";
import React, { ReactElement, useState } from "react";
import { Trans, useTranslation } from "react-i18next";
import { Link, useHistory } from "react-router-dom";
import { Button, Icon, Modal, PrimaryButton, Stamp, Text } from "ui";
import ReactTooltip from "react-tooltip";
import { Members } from "./members";
import s from "./styles.scss";

const statusToColor = {
  onboarding: "alert",
  inpreparation: "alert",
  active: "success",
};

const CompanyCard = ({ company }: { company: CompanyEntity }): ReactElement => {
  const {
    refreshToken,
    companyId: currentCompanyId,
    roles: orgRoles,
  } = useAuth();
  const history = useHistory();
  const [isLoading, setLoading] = useState(false);
  const { mutateAsync: refresh, isSuccess } = useRefresh();
  const canGetCompany = currentCompanyId === company.id || isSuccess;
  const { refetch, isFetched } = useCompanyDetail(
    canGetCompany ? company.id : undefined
  );
  const { t } = useTranslation();

  const [isNotAllowedModalOpen, setIsNotAllowedModalOpen] = useState(false);

  const refreshWithCompany = async () => {
    let roles = orgRoles;
    if (currentCompanyId !== company.id) {
      const result = await refresh({
        token: refreshToken,
        companyId: company.id,
      });
      roles = result.roles;
    }

    if (!isFetched && canGetCompany) await refetch();
    if (roles?.some((x) => x.name === "admin")) {
      history.push(companyWizardPath(company.id, null));
    } else {
      setIsNotAllowedModalOpen(true);
    }
  };

  return (
    <div className={s.card}>
      <ReactTooltip />
      <div className={s.cardHeader}>
        {company.status === CompanyStatus.onboarding ? (
          <Button
            className={s.cardTitleButton}
            isLoading={isLoading}
            onClick={async () => {
              setLoading(true);
              await refreshWithCompany();
              setLoading(false);
            }}
          >
            <Text weight="bold" size="l" color="primary">
              {company.name}
            </Text>
            <Icon
              icon={Icon.icons.open}
              size={15}
              className={s.cardTitleButtonIcon}
            />
          </Button>
        ) : (
          <Text weight="bold" size="l">
            {company.name}
          </Text>
        )}
        <div className={s.cardHeaderRight}>
          <Stamp
            data-tip={t(`companyOverview.status.${company.status}.description`)}
            color={statusToColor[company.status]}
          >
            <Trans i18nKey={`companyOverview.status.${company.status}.name`} />
          </Stamp>

          <Members company={company} />
        </div>
      </div>

      {company.environments?.length ? (
        <table>
          <thead>
            <th>
              <Text size="s" color="secondary">
                <Trans i18nKey="environment" />
              </Text>
            </th>
          </thead>
          <tbody>
            {company.environments.map((environment) => {
              return (
                <tr key={environment.name}>
                  <td>
                    {company.status === CompanyStatus.active ? (
                      <Link
                        to={homePath(company.id, environment.recopoId)}
                        className={s.cardEnvironmentLink}
                      >
                        <Text size="m">
                          {environment.displayName}
                          <Icon
                            icon={Icon.icons.open}
                            size={15}
                            className={s.cardTitleButtonIcon}
                          />
                        </Text>
                      </Link>
                    ) : (
                      <Text size="m">{environment.displayName}</Text>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      ) : null}
      {isNotAllowedModalOpen && (
        <Modal
          title={t("companyOverview.notAllowed.title")}
          onClose={() => setIsNotAllowedModalOpen(false)}
        >
          <div className={s.notAllowed}>
            <Text>
              <Trans i18nKey="companyOverview.notAllowed.body" />
            </Text>
            <PrimaryButton onClick={() => setIsNotAllowedModalOpen(false)}>
              <Trans i18nKey="companyOverview.notAllowed.close" />
            </PrimaryButton>
          </div>
        </Modal>
      )}
    </div>
  );
};

export default CompanyCard;
