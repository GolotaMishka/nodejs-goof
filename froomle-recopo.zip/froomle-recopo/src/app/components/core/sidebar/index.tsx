import React, { ReactElement } from "react";
import { Link, LinkProps } from "react-router-dom";
import { useCurrentPage } from "data/hooks/page";
import { Icon } from "ui";
import cx from "classnames";
import colors from "ui/styles/_colors.scss";
import {
  homePath,
  personasPath,
  templatesPath,
  recommendationsPath,
  insightsPath,
  settingsPath,
} from "app/constants/url";
import { RoleEntity, useAuth, useListPersonas, useStore } from "data";
import ReactTooltip from "react-tooltip";
import s from "./styles.scss";

type SidebarButton = {
  icon: string;
  page: string;
  path: (...args: (string | number)[]) => string;
};

const getButtons = (roles: RoleEntity[] | undefined) => [
  { icon: "home", page: "home", path: homePath },
  { icon: "users", page: "personas", path: personasPath },
  { icon: "brackets", page: "templates", path: templatesPath },
  { icon: "thumbsUp", page: "recommendations", path: recommendationsPath },
  { icon: "trendingUp", page: "insights", path: insightsPath },
  ...(roles?.some((r) => r.name === "admin")
    ? [{ icon: "settings", page: "settings", path: settingsPath }]
    : []),
];

const capitalize = (str: string) => str[0].toUpperCase() + str.slice(1);

interface SidebarButtonLinkProps extends LinkProps {
  disabled?: boolean;
}

const SidebarButtonLink = ({
  children,
  disabled = false,
  ...rest
}: SidebarButtonLinkProps): ReactElement => {
  if (disabled) return <span {...rest}>{children}</span>;
  return <Link {...rest}>{children}</Link>;
};

const Sidebar = (): ReactElement => {
  const { isCurrentPage } = useCurrentPage();
  const { data: personas } = useListPersonas();
  const { env, template } = useStore();
  const { companyId, roles } = useAuth();

  const hasActivePersonas = personas?.filter((p) => p.isEnabled).length !== 0;
  const templateSelected = !!template;
  const recommedationsDisabled = !hasActivePersonas || !templateSelected;

  const renderButton = ({ icon, page, path }: SidebarButton): ReactElement => {
    const isActive = isCurrentPage(page);
    const isDisabled = page === "recommendations" && recommedationsDisabled;
    const tooltipText = capitalize(page === "templates" ? "modules" : page);

    return (
      <li
        key={page}
        data-tip={tooltipText}
        className={cx(
          s.sidebarButton,
          isActive && s.sidebarButton_active,
          isDisabled && s.sidebarButton_disabled
        )}
      >
        <SidebarButtonLink
          disabled={isActive || isDisabled}
          to={path(companyId!, env?.id as string, template?.id as string)}
        >
          <Icon
            className={s.sidebarButtonIcon}
            icon={Icon.icons[icon]}
            color={isActive ? colors.success : colors.secondary}
            size={25}
          />
        </SidebarButtonLink>
      </li>
    );
  };

  return (
    <div className={s.sidebar}>
      <ul className={s.sidebarButtons}>
        {getButtons(roles).map(renderButton)}
      </ul>
      <ReactTooltip
        className={s.tooltip}
        place="right"
        effect="solid"
        type="dark"
        backgroundColor={colors.primary}
      />
    </div>
  );
};

export default Sidebar;
