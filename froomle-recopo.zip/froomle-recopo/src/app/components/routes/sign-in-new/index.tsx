import React, { ReactElement } from "react";
import { PrimaryButton, TextInput, Text, Row, Col } from "ui";
import { Form, FormikProps } from "formik";
import { Link } from "react-router-dom";

import Field from "app/utils/form-field";
import { useTranslation, Trans } from "react-i18next";
import { forgotPasswordPath, signUpPath } from "app/constants/url";
import { SignInFormValues } from "app/utils/types";
import { CompanyInviteEntity } from "data";
import s from "./styles.scss";
import { Divider, PasswordField, PlatformOAuth } from "../helpers";

type Invitation = {
  firstName?: string;
  lastName?: string;
  companyName?: string;
};

export interface SignInProps extends FormikProps<SignInFormValues> {
  invitation?: CompanyInviteEntity;
  isLoading?: boolean;
  linked?: string;
}

const Invitation = ({ invitation }: { invitation?: CompanyInviteEntity }) => {
  if (invitation) {
    return (
      <div className={s.invitation}>
        <Text color="light">
          <Trans
            i18nKey="invitedYou"
            values={{
              firstName: invitation?.createdBy?.firstName,
              lastName: invitation?.createdBy?.lastName,
              companyName: invitation?.company?.name,
            }}
          />
        </Text>
      </div>
    );
  }
  return null;
};

const SignIn = ({
  invitation,
  isValid,
  isLoading,
  linked,
}: SignInProps): ReactElement => {
  const { t } = useTranslation();

  return (
    <div className={s.login}>
      <div className={s.loginContent}>
        <div className={s.loginHeader}>
          <div className={s.loginTitle}>
            <Text color="light" size="xl" weight="bold">
              {t("actions.login")}
            </Text>
            <div className={s.loginTitleLink}>
              <Text color="light">{t("notAMember")}</Text>{" "}
              <Link
                to={{ pathname: signUpPath, search: window.location.search }}
                data-cy="signInSignInLink"
              >
                <Text
                  color="light"
                  weight="bold"
                  className={s.loginTitleLinkItem}
                >
                  {t("actions.signUp")}
                </Text>
              </Link>
            </div>
          </div>
          <Invitation invitation={invitation} />
        </div>

        <Form data-cy="signInForm">
          <PlatformOAuth linked={linked} />
          <Divider />
          <Row spacing="4, 5">
            <Col xs="12">
              <Field
                component={TextInput}
                id="email"
                name="email"
                title={t("titles.email")}
                placeholder="example@example.com"
                data-cy="signInEmailField"
                disabled={isLoading}
              />
            </Col>

            <Col xs="12">
              <div className={s.loginPassword}>
                <PasswordField
                  id="password"
                  name="password"
                  title={t("titles.password")}
                  disabled={isLoading}
                  data-cy="signInPasswordField"
                />
                <Link
                  to={forgotPasswordPath}
                  className={s.loginPasswordLink}
                  data-cy="signInForgotPasswordLink"
                >
                  <Text color="accent">{t("forgotPassword")}</Text>
                </Link>
              </div>
            </Col>
            <Col xs="12">
              <PrimaryButton
                className={s.loginSubmit}
                type="submit"
                data-cy="signInSubmitButton"
                disabled={!isValid}
                isLoading={isLoading}
              >
                {t("actions.login")}
              </PrimaryButton>
            </Col>
          </Row>
        </Form>
      </div>
    </div>
  );
};

export default SignIn;
