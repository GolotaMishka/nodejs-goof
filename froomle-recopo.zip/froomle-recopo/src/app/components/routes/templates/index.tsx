import Template from "app/components/core/template";
import React, { ReactElement, useCallback } from "react";
import { Text } from "ui";

import { TemplateEntity, useListTemplates, useStore } from "data";

import Lottie from "app/components/core/lottie";
import templateAnimationData from "public/animations/template.json";
import { idGenerator } from "app/utils";
import { homePath, recommendationsPath } from "app/constants/url";
import useStepFooter from "app/utils/hooks/step-footer";
import { useBreakpoints } from "data/hooks/breakpoints";
import s from "./styles.scss";

const NoTemplatesMessage = (): ReactElement => (
  <Text>
    This environment still has to be prepared by our team, please{" "}
    <a href="mailto:servicedesk@froomle.com?subject=[RECOPO] Mail from Recommendation Portal">
      contact us
    </a>
  </Text>
);

const Templates = (): ReactElement => {
  const { data: templates } = useListTemplates();
  const { setTemplate, template } = useStore();
  const { isSmallMobile } = useBreakpoints();

  useStepFooter(
    {
      hasStepFooter: true,
      nextStepDisabled: !template,
      nextStepTitle: isSmallMobile
        ? "Get recommendations"
        : "Next: Get recommendations",
      nextPagePath: recommendationsPath,
      prevPagePath: homePath,
      prevStepTitle: "Back to home page",
    },
    [template, isSmallMobile]
  );

  const handleTemplateClick = (t: TemplateEntity) => () => {
    setTemplate(t);
  };

  const renderGrid = useCallback(() => {
    if (!templates) {
      return [...Array(8)].map(() => (
        <div className={s.gridItem} key={idGenerator()}>
          <Lottie animationData={templateAnimationData} />
        </div>
      ));
    }

    if (templates.length === 0) return <NoTemplatesMessage />;

    return templates.map((t) => (
      <Template
        key={`template_${t.id}`}
        template={t}
        isSelected={template?.id === t.id}
        onClick={handleTemplateClick(t)}
        className={s.gridItem}
      />
    ));
  }, [templates, template]);

  return (
    <div className={s.page}>
      <Text color="primary" size="l" weight="bold">
        Choose your location and modules
      </Text>
      <section className={s.grid} data-cy="template-grid">
        {renderGrid()}
      </section>
    </div>
  );
};

export default Templates;
