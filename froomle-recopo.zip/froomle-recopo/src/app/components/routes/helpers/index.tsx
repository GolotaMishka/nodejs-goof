import Field from "app/utils/form-field";
import { useToggleState } from "app/utils/hooks";
import { WebAuth } from "auth0-js";
import googleLogo from "public/google.svg";
import microsoftLogo from "public/microsoft.svg";
import React, { ReactElement, useEffect } from "react";
import { useTranslation } from "react-i18next";
import {
  ButtonIcon,
  Col,
  Icon,
  Row,
  Text,
  TextInput,
  TextInputProps,
} from "ui";

import s from "./styles.scss";

export const Divider = (): ReactElement => {
  const { t } = useTranslation();
  return (
    <Text className={s.divider} color="primary">
      {t("or")}
    </Text>
  );
};

interface PlatForm0AuthProps {
  signUp?: boolean;
  linked?: string;
}

export const PlatformOAuth = ({
  signUp,
  linked,
}: PlatForm0AuthProps): ReactElement => {
  const webAuth = new WebAuth({
    domain: process.env.AUTH0_DOMAIN as string,
    clientID: process.env.AUTH0_CLIENT_ID as string,
    redirectUri: window.location.href,
  });

  const input = {
    responseType: "code",
    scope: "openid profile email offline_access",
    audience: process.env.AUTH0_AUDIENCE as string,
    mode: (signUp ? "signUp" : "login") as any,
  };

  const googleAuth = () =>
    webAuth.authorize({
      ...input,
      connection: "google-oauth2",
    });

  const microsoftAuth = () =>
    webAuth.authorize({
      ...input,
      connection: "windowslive",
    });

  useEffect(() => {
    if (linked) {
      webAuth.authorize({
        ...input,
        connection: linked,
      });
    }
  }, [linked]);

  return (
    <Row className={s.services} spacing="4, 5">
      <Col xs="12" sm="6">
        <button onClick={googleAuth} type="button" className={s.servicesButton}>
          <img src={googleLogo} alt="Google" className={s.servicesButtonIcon} />

          <Text color="accent">Google</Text>
        </button>
      </Col>
      <Col xs="12" sm="6">
        <button
          onClick={microsoftAuth}
          type="button"
          className={s.servicesButton}
        >
          <img
            src={microsoftLogo}
            alt="Microsoft"
            className={s.servicesButtonIcon}
          />

          <Text color="accent">Microsoft</Text>
        </button>
      </Col>
    </Row>
  );
};

export const PasswordField = ({ ...props }: TextInputProps): ReactElement => {
  const [isPasswordType, toggleInputType] = useToggleState(true);

  return (
    <Field
      component={TextInput}
      className={s.passwordField}
      type={isPasswordType ? "password" : "text"}
      data-cy="signUpPasswordField"
      iconAfter={
        <ButtonIcon
          icon={isPasswordType ? Icon.icons.unseen : Icon.icons.eye}
          onClick={toggleInputType}
          type="button"
        />
      }
      {...props}
    />
  );
};
