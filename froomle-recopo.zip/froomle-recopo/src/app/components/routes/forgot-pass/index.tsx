import { signInPath } from "app/constants/url";
import Field from "app/utils/form-field";
import { ForgotPassFormValues } from "app/utils/types";
import { Form, FormikProps } from "formik";
import React, { ReactElement } from "react";
import { useTranslation } from "react-i18next";
import { Link } from "react-router-dom";
import { Col, PrimaryButton, Row, Text, TextInput } from "ui";

import s from "./styles.scss";

export interface ForgotPassProps extends FormikProps<ForgotPassFormValues> {
  isLoading?: boolean;
  isSuccess?: boolean;
}

const ForgotPass = ({
  isValid,
  isLoading,
  dirty,
  isSuccess,
  values,
}: ForgotPassProps): ReactElement => {
  const { t } = useTranslation();

  return (
    <div className={s.forgotPass}>
      <div className={s.forgotPassContent}>
        <div className={s.forgotPassHeader}>
          {isSuccess ? (
            <>
              <div className={s.forgotPassTitle}>
                <Text color="light" size="xl" weight="bold">
                  {t("actions.checkYourEmail")}
                </Text>
              </div>
              <Text className={s.forgotPassSubTitle}>
                {t("resetPasswordInstructions", { email: values.email })}
              </Text>
            </>
          ) : (
            <>
              <div className={s.forgotPassTitle}>
                <Text
                  color="light"
                  size="xl"
                  weight="bold"
                  className={s.forgotPassTitleText}
                >
                  {t("actions.forgotPass")}
                </Text>
                <div className={s.forgotPassTitleLink}>
                  <Link to={signInPath} data-cy="signInLink">
                    <Text
                      color="light"
                      weight="bold"
                      className={s.forgotPassTitleLinkItem}
                    >
                      {t("actions.remember")}
                    </Text>
                  </Link>
                </div>
              </div>
              <Text className={s.forgotPassSubTitle}>
                {t("willBeHandledBy")}
              </Text>
            </>
          )}
        </div>

        {isSuccess ? (
          <Form data-cy="forgotPassForm">
            <Row spacing="4, 5">
              <Col xs="12">
                <PrimaryButton
                  className={s.forgotPassSubmit}
                  component="link"
                  to={signInPath}
                >
                  {t("actions.login")}
                </PrimaryButton>
              </Col>
            </Row>
          </Form>
        ) : (
          <Form data-cy="forgotPassForm">
            <Row spacing="4, 5">
              <Col xs="12">
                <Field
                  component={TextInput}
                  id="email"
                  name="email"
                  title={t("titles.email")}
                  placeholder="example@example.com"
                  data-cy="forgotPassEmailField"
                  disabled={isLoading}
                />
              </Col>

              <Col xs="12">
                <PrimaryButton
                  className={s.forgotPassSubmit}
                  type="submit"
                  data-cy="forgotPassSubmitButton"
                  disabled={!isValid || !dirty}
                  isLoading={isLoading}
                >
                  {t("actions.continue")}
                </PrimaryButton>
              </Col>
            </Row>
          </Form>
        )}
      </div>
    </div>
  );
};

export default ForgotPass;
