import Lottie from "app/components/core/lottie";
import useStepFooter from "app/utils/hooks/step-footer";
import { ParamsType } from "app/utils/types";
import cx from "classnames";
import { useCompanyDetail, useSecrets } from "data";
import wizardCardAnimation from "public/animations/wizard-card.json";
import React, { ReactElement } from "react";
import { Trans, useTranslation } from "react-i18next";
import { useParams } from "react-router-dom";
import { CopyField, Text } from "ui";
import s from "./styles.scss";

const Settings = (): ReactElement => {
  useStepFooter({ hasStepFooter: false });
  const { t } = useTranslation();
  const { companyId } = useParams<ParamsType>();
  const { data, isLoading } = useSecrets(companyId);
  const { data: detail, isLoading: detailLoading } = useCompanyDetail(
    companyId
  );

  if (isLoading || detailLoading) {
    return <Lottie animationData={wizardCardAnimation} />;
  }
  const startDate =
    detail?.dateInfo?.trialStartsAt && new Date(detail.dateInfo.trialStartsAt);

  const formattedTrialStart = startDate && startDate.toDateString();
  const trialEnd =
    startDate && new Date(startDate.getTime() + 1000 * 60 * 60 * 24 * 40);
  const formattedTrialEnd = trialEnd?.toDateString();
  const shouldShowTrial = trialEnd && new Date() <= trialEnd;

  return (
    <div className={s.page}>
      <header className={s.pageHeader}>
        <Text
          color="primary"
          size="l"
          weight="bold"
          className={s.pageHeaderTitle}
        >
          <Trans i18nKey="companySettings.title" />
        </Text>
      </header>
      <div className={cx(s.pageCard)} data-tour="personas-wizard-card">
        <Text color="accent" size="m" weight="bold">
          <Trans i18nKey="companySettings.secrets.title" />
        </Text>
        <CopyField
          label={t("companySettings.secrets.clientId")}
          value={data?.clientId}
        />
        <CopyField
          label={t("companySettings.secrets.clientSecret")}
          value={data?.clientSecret}
          hasObfuscation
        />
        <CopyField
          label={t("companySettings.secrets.url")}
          value={data?.apiUrl}
        />

        {shouldShowTrial && (
          <div className={s.pageTrial}>
            <Text color="accent" size="m" weight="bold">
              <Trans
                i18nKey="companySettings.trial"
                values={{
                  trialStart: formattedTrialStart,
                  trialEnd: formattedTrialEnd,
                }}
              />
            </Text>
          </div>
        )}
      </div>
    </div>
  );
};

export default Settings;
