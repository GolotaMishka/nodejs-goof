import { InviteModal } from "app/components/core/company-card/invite-modal";
import { InviteColleague } from "app/components/core/invite-colleague";
import SubHeader from "app/components/core/sub-header";
import WizardForm from "app/components/core/wizard-form";
import { WizardParams } from "app/components/core/wizard-form/wizardParams";
import { companiesPath } from "app/constants/url";
import useStepFooter from "app/utils/hooks/step-footer";
import { CreationStep, useCompanyDetail } from "data";
import React, { ReactElement, useState } from "react";
import { Trans, useTranslation } from "react-i18next";
import { Link, useParams } from "react-router-dom";
import { ButtonIcon, Icon, PrimaryButton, Text } from "ui";
import s from "./styles.scss";

const CompanyCreation = (): ReactElement => {
  useTranslation();
  useStepFooter({ hasStepFooter: false });
  const { companyId, step } = useParams<WizardParams>();
  const { data: company } = useCompanyDetail(companyId);

  const [inviteModalOpen, setInviteModalOpen] = useState(false);

  return (
    <div className={s.page}>
      <SubHeader>
        <div className={s.subHeader}>
          <div className={s.subHeaderText}>
            <div className={s.subHeaderTextWrapper}>
              <Link to={companiesPath}>
                <ButtonIcon
                  icon={Icon.icons.chevronLeft}
                  className={s.subHeaderLink}
                />
              </Link>
              <Text
                color="light"
                weight="bold"
                className={s.subHeaderTextTitle}
              >
                <Trans i18nKey="companyCreation.title" />
              </Text>
            </div>
            <Text color="light" className={s.subHeaderTextSub} size="m">
              <Trans i18nKey="companyCreation.description" />
            </Text>
          </div>

          <PrimaryButton
            onClick={() => setInviteModalOpen(true)}
            className={s.subHeaderInvitation}
            disabled={!companyId}
          >
            <Trans i18nKey="actions.inviteColleague" />
          </PrimaryButton>
        </div>
      </SubHeader>
      {!company && <InviteColleague />}
      <WizardForm />
      {company && (
        <InviteModal
          company={company}
          isOpen={inviteModalOpen}
          step={step as CreationStep}
          closeFunction={() => setInviteModalOpen(false)}
        />
      )}
    </div>
  );
};

export default CompanyCreation;
