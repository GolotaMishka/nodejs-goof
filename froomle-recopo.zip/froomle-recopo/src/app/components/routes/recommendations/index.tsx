import React, { ReactElement, useEffect, useState } from "react";
import { Form, FormikProps } from "formik";
import Field from "app/utils/form-field";
import recommendationAnimationData from "public/animations/recommendation-card.json";
import recommendationAnimationDataMobile from "public/animations/recommendation-card-mobile.json";
import RecommendationCard from "app/components/core/recommendation";
import {
  Text,
  PrimaryButton,
  SelectInput,
  ConfirmModal,
  AppThemeType,
  useTheme,
} from "ui";
import {
  TemplateEntity,
  ItemEntity,
  RecommendationsList,
  PersonaEntity,
  ExtendedItemEntity,
} from "data";
import JSONPretty from "react-json-pretty";
import useStepFooter from "app/utils/hooks/step-footer";
import { SelectOption } from "app/utils/generics";
import Tooltip from "app/components/core/tooltip";
import { useBreakpoints } from "data/hooks/breakpoints";
import { ContextSelect } from "app/components/core/selects";
import Lottie from "app/components/core/lottie";
import { templatesPath } from "app/constants/url";
import s from "./styles.scss";

export type FormValues = {
  contextCategory?: SelectOption<string> | null;
  contextItem?: ItemEntity | null;
  hasContextCategory?: boolean;
  hasContextItem?: boolean;
};

interface IProps {
  currentTemplate?: TemplateEntity;
  onContextItemSearch: (inputValue: string) => void;
  isContextItemLoading: boolean;
  contextItems?: ItemEntity[];
  currentRecommendation?: RecommendationsList;
  recommendationLoading: boolean;
  recommendationIdle: boolean;
  categories?: string[];
  personas: PersonaEntity[];
  onFilterChange: (filter: string) => void;
}

const Recommendations = ({
  currentTemplate,
  onContextItemSearch,
  isContextItemLoading,
  currentRecommendation,
  contextItems = [],
  recommendationLoading,
  personas,
  categories,
  recommendationIdle,
  submitForm,
  setFieldValue,
  onFilterChange,
  values,
}: IProps & FormikProps<FormValues>): ReactElement => {
  const [modalCode, setModalCode] = useState<null | string>(null);
  const { isMobile } = useBreakpoints();
  const theme: AppThemeType = useTheme();

  useStepFooter({
    hasStepFooter: true,
    nextPagePath: null,
    prevPagePath: templatesPath,
    prevStepTitle: "Back to modules",
  });

  const setContextItem = (item: ItemEntity) => {
    setFieldValue("contextItem", item);
  };

  const closeModal = () => {
    setModalCode(null);
  };

  const handleModalSubmit = () => {
    if (modalCode) {
      navigator.clipboard.writeText(modalCode);
    }
  };

  useEffect(() => {
    if (
      (values.hasContextCategory && values.contextCategory) ||
      (values.hasContextItem && values.contextItem)
    ) {
      submitForm();
    }
  }, [values]);

  const onContextSelectChange = (option: ItemEntity | null) => {
    if (option) setFieldValue("contextItem", option);
  };

  return (
    <div className={s.page} id="recommendation-page">
      <Tooltip
        id="button-tooltip"
        dependencies={[personas, currentRecommendation]}
      />
      <Tooltip
        showOnMobile
        id="history-item-tooltip"
        offset={{ right: 12 }}
        className={s.tooltip}
        dependencies={[personas]}
      />
      <Form id="recommendation">
        <header className={s.pageHeader}>
          <Text
            color="primary"
            size="l"
            weight="bold"
            className={s.pageHeaderTitle}
          >
            Your Recommendations: {currentTemplate?.name}
          </Text>
          <PrimaryButton
            type="submit"
            className={s.pageHeaderButton}
            disabled={recommendationLoading}
            data-cy="refresh"
          >
            {(() => {
              if (recommendationLoading) return "Loading...";
              if (recommendationIdle) return "Generate";
              return "Refresh";
            })()}
          </PrimaryButton>
        </header>
        {(currentTemplate?.hasContextCategory ||
          currentTemplate?.hasContextItem) && (
          <div className={s.pageFilters} id="context-select">
            {currentTemplate.hasContextItem && (
              <ContextSelect
                title="Context item"
                icon="home"
                options={contextItems}
                onInputChange={onContextItemSearch}
                isLoading={isContextItemLoading}
                filters={["Popular", "Recent"]}
                onFilterChange={onFilterChange}
                onChange={onContextSelectChange}
                preselectedOption={values.contextItem}
              />
            )}
            {currentTemplate.hasContextCategory && (
              <Field
                component={SelectInput}
                title="Context category"
                placeholder="Choose category"
                name="contextCategory"
                options={categories?.map((category) => ({
                  value: category,
                  label: category,
                }))}
                onChangeAdapter={(option) => option}
                className={s.pageFilter}
              />
            )}
          </div>
        )}
        {recommendationLoading
          ? [...Array(4)].map((_, i) => (
              <div
                key={`preloader_${i + 1}`}
                className={s.recommendationCardLoader}
              >
                <div>
                  <Lottie
                    animationData={
                      isMobile
                        ? recommendationAnimationDataMobile
                        : recommendationAnimationData
                    }
                  />
                </div>
              </div>
            ))
          : currentRecommendation?.modules.map(
              ({ module, recommendations }) => {
                return (
                  <section
                    key={`module_${module.id}`}
                    className={s.pageSection}
                  >
                    <Text
                      size={isMobile ? "m" : "l"}
                      color={isMobile ? "secondary" : "primary"}
                      weight="bold"
                      className={s.pageSectionTitle}
                    >
                      {module.name}
                    </Text>
                    {recommendations.map(
                      ({
                        persona: {
                          id: personaId,
                          name: personaName,
                          items: historyItems,
                        },
                        items,
                        raw,
                      }) => {
                        const extendedItems: ExtendedItemEntity[] = items.map(
                          (item) => ({
                            ...item,
                            isInPersonaHistory: historyItems.some(
                              ({ item: histItem }) =>
                                histItem.clientItemId === item.clientItemId ||
                                histItem.froomleItemId === item.froomleItemId
                            ),
                          })
                        );

                        return (
                          <RecommendationCard
                            key={`recommendation-${personaName}-module-${module.id}`}
                            hasCodeButton={!!raw?.length}
                            className={s.recommendationCard}
                            hasContextItem={!!values.hasContextItem}
                            persona={
                              personas?.find(
                                (persona) => persona.id === personaId
                              ) as PersonaEntity
                            }
                            setContextItem={setContextItem}
                            items={extendedItems}
                            openCode={() => setModalCode(JSON.stringify(raw))}
                          />
                        );
                      }
                    )}
                  </section>
                );
              }
            )}
        {modalCode && (
          <ConfirmModal
            onClose={closeModal}
            title="Code"
            submitText="Copy"
            className={s.modal}
            onSubmit={handleModalSubmit}
          >
            <JSONPretty
              valueStyle={`color: ${theme.colors.accent}`}
              stringStyle={`color: ${theme.colors.error}`}
              keyStyle={`color: ${theme.colors.primary}`}
              data={modalCode}
            />
          </ConfirmModal>
        )}
      </Form>
    </div>
  );
};

export default Recommendations;
