import React, { ReactElement } from "react";
import { Text } from "ui";
import { homePath } from "app/constants/url";
import useStepFooter from "app/utils/hooks/step-footer";
import s from "./styles.scss";

const Insights = (): ReactElement => {
  useStepFooter({
    hasStepFooter: true,
    nextPagePath: null,
    prevPagePath: homePath,
    prevStepTitle: "Back to home page",
  });

  return (
    <div className={s.page}>
      <div className={s.pageHeader}>
        <Text color="primary" size="l" weight="bold">
          Insights
        </Text>
      </div>
      <Text>
        Froomle KPI reports can be consulted on{" "}
        <a
          className={s.pageDataStudioLink}
          href="http://datastudio.google.com/"
          target="_blank"
          rel="noreferrer"
        >
          Google Data Studio
        </a>
      </Text>
    </div>
  );
};

export default Insights;
