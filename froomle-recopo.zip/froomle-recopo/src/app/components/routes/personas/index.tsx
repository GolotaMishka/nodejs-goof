import React, { ReactElement, useCallback, useState } from "react";
import { SortableContainer } from "react-sortable-hoc";
import Tooltip from "app/components/core/tooltip";
import { Text, Icon, Button, ConfirmModal, Modal } from "ui";
import Lottie from "app/components/core/lottie";
import { idGenerator } from "app/utils";
import { useToggleState } from "app/utils/hooks";
import { homePath, templatesPath } from "app/constants/url";
import useStepFooter from "app/utils/hooks/step-footer";
import {
  useCreatePersona,
  useListPersonas,
  useRemovePersona,
  useUpdatePersona,
} from "data";
import personaCardAnimation from "public/animations/persona-card.json";
import personaCardAnimationMobile from "public/animations/persona-card-mobile.json";
import SortablePersona from "app/components/core/persona";
import { EditPersona } from "app/components/core/persona-modals/edit";
import { ManageHistory } from "app/components/core/persona-modals/history";
import { useBreakpoints } from "data/hooks/breakpoints";
import { CreatePersonaModal } from "app/components/core/persona-modals/create-modal";
import s from "./styles.scss";

const SortableRow = SortableContainer(({ children, ...props }) => (
  <section {...props}>{children}</section>
));

const getNameForPersonaClone = (name: string, names: string[] = []) => {
  for (let i = 1; ; i += 1) {
    const nextPossibleName = `${name} (${i})`;
    if (!names.includes(nextPossibleName)) return nextPossibleName;
  }
};

const scrollToBottom = () => {
  window.scrollTo(0, document.body.scrollHeight);
};

const Personas = (): ReactElement => {
  const [
    removePersonaModalOpened,
    toggleRemovePersonaModalOpened,
  ] = useToggleState(false);
  const [editPersonaModalOpened, toggleEditPersonaModalOpened] = useToggleState(
    false
  );
  const [
    manageHistoryModalOpened,
    toggleManageHistoryModalOpened,
  ] = useToggleState(false);
  const [isNewPersonaActive, setIsNewPersonaActive] = useState(false);
  const [activePersonaId, setActivePersonaId] = useState<string | null>(null);

  const { isMobile, isSmallMobile } = useBreakpoints();

  const { mutate: clonePersona } = useCreatePersona();

  const { mutate: removePersona } = useRemovePersona();

  const { mutate: updatePersona } = useUpdatePersona();

  const { data: personas, isLoading } = useListPersonas();

  const hasActivePersonas: boolean =
    personas?.filter((p) => p.isEnabled).length !== 0;

  useStepFooter(
    {
      hasStepFooter: true,
      nextStepDisabled: !hasActivePersonas,
      nextStepTitle: isSmallMobile ? "Choose module" : "Next: Choose module",
      nextPagePath: templatesPath,
      prevPagePath: homePath,
      prevStepTitle: "Back to home page",
    },
    [hasActivePersonas, isSmallMobile]
  );

  const onSortEnd = ({ oldIndex, newIndex }) => {
    if (oldIndex !== newIndex) {
      updatePersona({
        personaId: personas?.[oldIndex].id as string,
        values: { rank: newIndex },
      });
    }
  };

  const addNewPersona = useCallback(() => {
    setIsNewPersonaActive(true);
  }, [isNewPersonaActive]);

  const removeNewPersona = useCallback(() => {
    setIsNewPersonaActive(false);
  }, []);

  const handleDeletePersonaClick = useCallback((id: string | number) => {
    setActivePersonaId(String(id));
    toggleRemovePersonaModalOpened();
  }, []);

  const handleRemovePersonaModalSubmit = () => {
    if (!activePersonaId) return;
    removePersona(activePersonaId);
    toggleRemovePersonaModalOpened();
  };

  const handleOpenEditPersonaModal = useCallback(
    (id: string | number) => {
      setActivePersonaId(String(id));
      toggleEditPersonaModalOpened();
    },
    [editPersonaModalOpened]
  );

  const handleCloseEditPersonaModal = useCallback(() => {
    setActivePersonaId(null);
    toggleEditPersonaModalOpened();
  }, [editPersonaModalOpened]);

  const handleOpenManageHistoryModal = useCallback(
    (id: string | number) => {
      setActivePersonaId(String(id));
      toggleManageHistoryModalOpened();
    },
    [manageHistoryModalOpened]
  );

  const handleCloseManageHistoryModal = useCallback(() => {
    setActivePersonaId(null);
    toggleManageHistoryModalOpened();
  }, [manageHistoryModalOpened]);

  const handleClonePersona = (persona) => {
    const { name, isEnabled, items, role, versionId, rank, avatar } = persona;
    const allNames = personas?.map((p) => p.name);
    clonePersona({
      avatar,
      name: getNameForPersonaClone(name, allNames),
      isEnabled,
      items,
      role,
      versionId,
      rank: rank + 1,
    });
  };

  const renderPersonasList = () => {
    if (isLoading) {
      return [...Array(8)].map(() => (
        <Lottie
          key={idGenerator()}
          animationData={
            isMobile ? personaCardAnimationMobile : personaCardAnimation
          }
        />
      ));
    }
    if (personas?.length === 0 && !isNewPersonaActive)
      return (
        <Text component="p">
          Lucky you! There are no personas for this environment yet, so you can{" "}
          <Text
            component="span"
            color="accent"
            className={s.textButton}
            onClick={addNewPersona}
          >
            get started and create some!
          </Text>
        </Text>
      );
    return personas?.map((persona, i) => (
      <SortablePersona
        key={`persona_${persona.name + persona.rank}`}
        persona={persona}
        onDeletePersonaClick={handleDeletePersonaClick}
        onClonePersonaClick={handleClonePersona}
        onEditPersonaClick={handleOpenEditPersonaModal}
        onManageHistoryClick={handleOpenManageHistoryModal}
        index={i}
        dataCy="grid-item"
      />
    ));
  };

  return (
    <div className={s.page}>
      <Tooltip
        showOnMobile
        id="history-item-tooltip"
        className={s.tooltip}
        offset={{ right: 16 }}
        dependencies={[personas]}
      />
      <Tooltip id="button-tooltip" dependencies={[personas]} />
      <header className={s.pageHeader}>
        <Text
          color="primary"
          size="l"
          weight="bold"
          className={s.pageHeaderTitle}
        >
          Select or create the personas you&apos;d like to use:
        </Text>
        <Button
          iconLeft={Icon.icons.filledPlus}
          variant="transparent"
          onClick={addNewPersona}
          className={s.pageHeaderButton}
          data-cy="add-persona"
        >
          Add persona
        </Button>
      </header>
      <SortableRow
        axis="y"
        useDragHandle
        onSortEnd={onSortEnd}
        className={s.grid}
        useWindowAsScrollContainer
      >
        {renderPersonasList()}
      </SortableRow>
      {removePersonaModalOpened && (
        <ConfirmModal
          onClose={toggleRemovePersonaModalOpened}
          title="Delete the persona"
          onSubmit={handleRemovePersonaModalSubmit}
          submitText="Delete"
        >
          <Text>Are you sure you want to delete the persona?</Text>
        </ConfirmModal>
      )}
      {editPersonaModalOpened && activePersonaId && (
        <Modal title="Persona editing" onClose={handleCloseEditPersonaModal}>
          <EditPersona
            onClose={handleCloseEditPersonaModal}
            personaId={activePersonaId}
          />
        </Modal>
      )}
      {manageHistoryModalOpened && activePersonaId && (
        <Modal title="Browsing history" onClose={handleCloseManageHistoryModal}>
          <ManageHistory
            onClose={handleCloseManageHistoryModal}
            personaId={activePersonaId}
          />
        </Modal>
      )}
      {isNewPersonaActive && (
        <CreatePersonaModal
          onClose={removeNewPersona}
          onExitAfterCreatedPersona={scrollToBottom}
        />
      )}
    </div>
  );
};

export default Personas;
