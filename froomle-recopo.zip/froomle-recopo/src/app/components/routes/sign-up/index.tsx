import React, { ReactElement } from "react";
import { PrimaryButton, TextInput, Row, Col, Text, SelectInput } from "ui";
import { Form, FormikProps } from "formik";
import { Link } from "react-router-dom";

import Field from "app/utils/form-field";
import { useTranslation } from "react-i18next";
import { signInPath } from "app/constants/url";
import { SignUpFormValues } from "app/utils/types";
import { CompanyInviteEntity, RoleType } from "data";
import s from "./styles.scss";
import { Divider, PasswordField, PlatformOAuth } from "../helpers";

export interface SignUpProps extends FormikProps<SignUpFormValues> {
  isValid: boolean;
  isLoading: boolean;
  invite?: CompanyInviteEntity;
  linked?: string;
}

const roles = Object.values(RoleType).map((x) => ({ label: x, value: x }));

const SignUp = ({ isLoading, invite, linked }: SignUpProps): ReactElement => {
  const { t } = useTranslation();

  return (
    <div className={s.signUp}>
      <div className={s.signUpContent}>
        <div className={s.signUpHeader}>
          <div className={s.signUpTitle}>
            <Text color="light" size="xl" weight="bold">
              {t("actions.signUp")}
            </Text>
            <div className={s.signUpTitleLink}>
              <Text color="light">{t("alreadyAMember")}</Text>{" "}
              <Link
                to={{ pathname: signInPath, search: window.location.search }}
                data-cy="signUpSignInLink"
              >
                <Text
                  color="light"
                  weight="bold"
                  className={s.signUpTitleLinkItem}
                >
                  {t("actions.login")}
                </Text>
              </Link>
            </div>
          </div>
          <div className={s.signUpSubTitleWrapper}>
            {invite && (
              <Text weight="bold" className={s.signUpSubTitle}>
                {t("youWereInvited", {
                  company: invite.company?.name,
                  role: invite.roles?.[0].name,
                  inviter: `${invite.createdBy?.firstName} ${invite.createdBy?.lastName}`,
                })}
              </Text>
            )}
            <Text className={s.signUpSubTitle}>
              {t("creatingPersonalAccount")}
            </Text>
          </div>
        </div>
        <Form data-cy="signUpForm">
          <PlatformOAuth signUp linked={linked} />
          <Divider />
          <Row spacing="4, 5">
            <Col xs="12">
              <Field
                component={TextInput}
                id="email"
                name="email"
                title={t("titles.email")}
                placeholder="example@example.com"
                data-cy="signUpEmailField"
                disabled={isLoading}
              />
            </Col>
            <Col xs="12" sm="6">
              <Field
                component={TextInput}
                id="firstName"
                name="firstName"
                title={t("titles.firstName")}
                // placeholder="example@example.com"
                data-cy="signUpFirstNameField"
                disabled={isLoading}
              />
            </Col>
            <Col xs="12" sm="6">
              <Field
                component={TextInput}
                id="lastName"
                name="lastName"
                title={t("titles.lastName")}
                // placeholder="example@example.com"
                data-cy="signUpLastNameField"
                disabled={isLoading}
              />
            </Col>
            <Col xs="12" sm="6">
              <PasswordField
                id="password"
                name="password"
                title={t("titles.password")}
                disabled={isLoading}
              />
            </Col>
            <Col xs="12" sm="6">
              <PasswordField
                id="repeatPassword"
                name="repeatPassword"
                title={t("titles.repeatPassword")}
                disabled={isLoading}
              />
            </Col>
            <Col xs="12" sm="6">
              <Field
                component={TextInput}
                id="company"
                name="company"
                title={t("titles.company")}
                data-cy="signUpCompanyField"
                disabled={isLoading}
              />
            </Col>
            <Col xs="12" sm="6">
              <Field
                component={SelectInput}
                id="role"
                name="role"
                title={t("titles.role")}
                options={roles}
                onChangeAdapter={(option) => option.value}
                valueAdapter={(v) => roles?.find((role) => role.value === v)}
                disabled={isLoading}
              />
            </Col>
            <Col>
              <Field
                component={TextInput}
                id="phone"
                name="phone"
                title={t("titles.phone")}
                data-cy="signUpPhoneField"
                disabled={isLoading}
              />
            </Col>

            <Col xs="12">
              <PrimaryButton
                className={s.signUpSubmit}
                type="submit"
                data-cy="signUpSubmitButton"
                isLoading={isLoading}
              >
                {t("actions.createAccount")}
              </PrimaryButton>
            </Col>

            <Col xs="12">
              <Text className={s.signUpTerms} color="primary">
                {t("titles.termsAndConditions")}
              </Text>
            </Col>
          </Row>
        </Form>
      </div>
    </div>
  );
};

export default SignUp;
