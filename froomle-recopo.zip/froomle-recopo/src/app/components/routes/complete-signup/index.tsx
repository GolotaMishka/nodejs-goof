import {
  companiesPath,
  companyWizardPath,
  signInPath,
} from "app/constants/url";
import { CreationStep, useAuth, useRefresh } from "data";
import React, { ReactElement, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { Redirect } from "react-router-dom";
import { Col, PrimaryButton, Row, Text, toast } from "ui";

import s from "./styles.scss";

export const CompleteSignup = (): ReactElement => {
  const { t } = useTranslation();
  const params = new URLSearchParams(window.location.search);
  const companyId = params.get("companyId");
  const step = params.get("step");

  const { user, refreshToken, isAuthenticated } = useAuth();
  const { mutate: refresh, isLoading, isSuccess } = useRefresh();

  useEffect(() => {
    if (refreshToken) {
      refresh({ token: refreshToken });
    }
  }, []);

  useEffect(() => {
    if (isSuccess && !user.email_verified) {
      (toast as any).error(t("emailNotVerifiedYet"));
    }
  }, [isSuccess]);

  if (!isAuthenticated) {
    return <Redirect to={signInPath} />;
  }

  if (user?.email_verified) {
    return (
      <Redirect
        to={
          companyId && step
            ? companyWizardPath(companyId, step as CreationStep)
            : companiesPath
        }
      />
    );
  }

  return (
    <div className={s.forgotPass}>
      <div className={s.forgotPassContent}>
        <div className={s.forgotPassHeader}>
          <div className={s.forgotPassTitle}>
            <Text color="light" size="xl" weight="bold">
              {t("actions.checkYourEmail")}
            </Text>
          </div>
          <Text className={s.forgotPassSubTitle}>
            {t("completeSignUpInstructions", { email: user?.email })}
          </Text>
        </div>
        <form data-cy="forgotPassForm">
          <Row spacing="4, 5">
            <Col xs="12">
              <PrimaryButton
                className={s.forgotPassSubmit}
                onClick={() => refresh({ token: refreshToken })}
                isLoading={isLoading}
              >
                {t("actions.iHaveVerified")}
              </PrimaryButton>
            </Col>
          </Row>
        </form>
      </div>
    </div>
  );
};
