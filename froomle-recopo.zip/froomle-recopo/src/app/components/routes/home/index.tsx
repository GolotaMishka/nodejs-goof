import React, { ReactElement } from "react";
import { useBreakpoints } from "data/hooks/breakpoints";
import { useAuth, useListPersonas, usePersonasInfo, useStore } from "data";
import cx from "classnames";
import {
  personasPath,
  recommendationsPath,
  templatesPath,
  insightsPath,
} from "app/constants/url";
import Lottie from "app/components/core/lottie";
import wizardCardAnimation from "public/animations/wizard-card.json";
import infoCardAnimation from "public/animations/info-card.json";
import infoCardAnimationMobile from "public/animations/info-card-mobile.json";
import { Icon, Button, Text } from "ui";
import useStepFooter from "app/utils/hooks/step-footer";
import { Link } from "react-router-dom";
import colors from "ui/styles/_colors.scss";
import { idGenerator } from "@panenco/ui";
import s from "./styles.scss";

const Home = (): ReactElement => {
  const { isLoading } = useListPersonas();
  const { totalPersonasCount, activePersonasCount } = usePersonasInfo();
  const { env, template } = useStore();
  const { isMobile } = useBreakpoints();
  const { companyId } = useAuth();

  useStepFooter({ hasStepFooter: false });

  const isPersonasCardActive = activePersonasCount > 0;
  const isTemplatesCardActive = !!template;
  const isRecommendationsCardActive =
    isPersonasCardActive && isTemplatesCardActive;

  let recommendationsCardPath = recommendationsPath;
  let recommendaitonsCardLinkTitle = "Explore";

  if (!isTemplatesCardActive) {
    recommendationsCardPath = templatesPath;
    recommendaitonsCardLinkTitle = "Select a module";
  }
  if (!isPersonasCardActive) {
    recommendationsCardPath = personasPath;
    recommendaitonsCardLinkTitle = "Select personas";
  }

  const renderWizardCards = () => {
    if (isLoading) {
      return [...Array(3)].map(() => (
        <div
          key={idGenerator()}
          className={cx(s.wizardCard, s.wizardCardAnimation)}
        >
          <Lottie animationData={wizardCardAnimation} />
        </div>
      ));
    }

    return (
      <>
        <Link
          className={cx(
            s.wizardCard,
            isPersonasCardActive && s.wizardCard_active,
            isPersonasCardActive && s.bottomTrackActive
          )}
          data-tour="personas-wizard-card"
          to={personasPath(companyId!, env?.id as string)}
        >
          <div className={s.wizardCardIcon}>
            <Icon
              icon={Icon.icons.users}
              color={isPersonasCardActive ? colors.light : colors.primary}
            />
          </div>
          <div className={s.wizardCardInfo}>
            <Text className={s.wizardCardTitleWrapper} component="p">
              <Text className={s.wizardCardTitle} weight="bold" color="accent">
                Personas setup
              </Text>
              <Text className={s.wizardCardTitleInfo}>
                {totalPersonasCount > 0 &&
                  `(${activePersonasCount}/${totalPersonasCount} created personas are active)`}
              </Text>
            </Text>
            <Text component="p" size="m" color="primary">
              Manage personas for which you want to simulate recommendations.
            </Text>
          </div>
          <Button
            variant="transparent"
            iconRight={Icon.icons.chevronRight}
            className={s.wizardCardLink}
          >
            Edit
          </Button>
        </Link>

        <Link
          className={cx(
            s.wizardCard,
            isTemplatesCardActive && s.wizardCard_active,
            isPersonasCardActive && s.topTrackActive,
            isPersonasCardActive && isTemplatesCardActive && s.bottomTrackActive
          )}
          data-tour="modules-wizard-card"
          to={templatesPath(companyId!, env?.id as string)}
        >
          <div className={s.wizardCardIcon}>
            <Icon
              icon={Icon.icons.brackets}
              color={isTemplatesCardActive ? colors.light : colors.primary}
            />
          </div>
          <div className={s.wizardCardInfo}>
            <Text className={s.wizardCardTitleWrapper} component="p">
              <Text className={s.wizardCardTitle} weight="bold" color="accent">
                Modules
              </Text>
              <Text className={s.wizardCardTitleInfo}>
                {isTemplatesCardActive && `(${template?.name} chosen)`}
              </Text>
            </Text>
            <Text component="p" size="m" color="primary">
              Have a look at available modules and experience how
              recommendations look like for different personas.
            </Text>
          </div>
          <Button
            variant="transparent"
            iconRight={Icon.icons.chevronRight}
            className={s.wizardCardLink}
          >
            Choose
          </Button>
        </Link>

        <Link
          className={cx(
            s.wizardCard,
            isRecommendationsCardActive && s.wizardCard_active,
            isRecommendationsCardActive && s.topTrackActive
          )}
          data-tour="reccomendations-wizard-card"
          to={recommendationsCardPath(
            companyId!,
            env?.id as string,
            template?.id as string
          )}
        >
          <div className={s.wizardCardIcon}>
            <Icon
              icon={Icon.icons.thumbsUp}
              color={
                isRecommendationsCardActive ? colors.light : colors.secondary
              }
            />
          </div>
          <div className={s.wizardCardInfo}>
            <Text className={s.wizardCardTitleWrapper} component="p">
              <Text
                className={s.wizardCardTitle}
                weight="bold"
                color={isRecommendationsCardActive ? "accent" : "secondary"}
              >
                Recommendations
              </Text>
            </Text>
            <Text
              component="p"
              size="m"
              color={isRecommendationsCardActive ? "primary" : "secondary"}
            >
              To see the recommendations you need to activate at least one
              persona and choose a module.
            </Text>
          </div>
          <Button
            variant="transparent"
            iconRight={Icon.icons.chevronRight}
            className={s.wizardCardLink}
          >
            {recommendaitonsCardLinkTitle}
          </Button>
        </Link>
      </>
    );
  };

  const renderInfoCards = () => {
    if (isLoading) {
      return (
        <div key={idGenerator()} className={cx(s.infoCard)}>
          <Lottie
            animationData={
              isMobile ? infoCardAnimationMobile : infoCardAnimation
            }
          />
        </div>
      );
    }
    return (
      <>
        <Link
          className={s.infoCard}
          to={insightsPath(companyId!, env?.id as string)}
          data-tour="insights-info-card"
        >
          <div className={s.infoCardHeader}>
            <div className={s.infoCardIcon}>
              <Icon icon={Icon.icons.trendingUp} />
            </div>
          </div>
          <Text className={s.infoCardTitle}>Insights</Text>
          <Text
            className={s.infoCardDescription}
            component="p"
            size="m"
            color="primary"
          >
            Obtain insights about your online channels and about the adoption
            and performance of your modules.
          </Text>
          <Button
            className={s.infoCardLink}
            variant="transparent"
            iconRight={Icon.icons.chevronRight}
          >
            Explore
          </Button>
        </Link>
      </>
    );
  };

  return (
    <div className={s.page}>
      <div className={s.pageHeader}>
        <Text className={s.pageHeaderTitle}>Home page</Text>
      </div>
      <div className={s.pageContent}>
        <div className={s.wizard}>{renderWizardCards()}</div>
        <div className={s.infoCardsWrapper}>{renderInfoCards()}</div>
      </div>
    </div>
  );
};

export default Home;
