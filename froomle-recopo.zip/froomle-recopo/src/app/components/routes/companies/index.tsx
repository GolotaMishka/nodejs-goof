import CompanyCard from "app/components/core/company-card";
import { InvitesCard } from "app/components/core/invites-card";
import { SkeletonLoader } from "app/components/core/loader";
import { NoCompanies } from "app/components/core/no-companies";
import SubHeader from "app/components/core/sub-header";
import { companyCreation } from "app/constants/url";
import useStepFooter from "app/utils/hooks/step-footer";
import { useAuth, useListCompanies } from "data";
import React, { ReactElement, useState } from "react";
import { Trans, useTranslation } from "react-i18next";
import { useHistory } from "react-router-dom";
import { Modal, PrimaryButton, SecondaryButton, Text } from "ui";
import s from "./styles.scss";

export const Companies = (): ReactElement => {
  useStepFooter({ hasStepFooter: false });

  const history = useHistory();
  const { t } = useTranslation();
  const { user } = useAuth();
  const { data: companies = [], isLoading } = useListCompanies(user?.id);
  const [isRequestModal, setRequestModal] = useState(false);

  if (isLoading) return <SkeletonLoader />;
  const hasCompanies = companies?.some((c) => !c.isDemo);

  return (
    <>
      <div className={s.page}>
        <SubHeader>
          <div className={s.subHeaderRow}>
            <div className={s.subHeaderLeft}>
              <Text color="light" weight="bold">
                <Trans i18nKey="companyOverview.title" />
              </Text>
              <Text color="light" className={s.subHeaderSubTitle} size="m">
                {hasCompanies ? (
                  <Trans i18nKey="companyOverview.subTitle" />
                ) : (
                  <Trans i18nKey="companyOverview.subTitleNoCompanies" />
                )}
              </Text>
            </div>
            <div className={s.subHeaderRight}>
              <SecondaryButton onClick={() => setRequestModal(true)}>
                <Trans i18nKey="companyOverview.requestAccess.button" />
              </SecondaryButton>
              <PrimaryButton onClick={() => history.push(companyCreation)}>
                <Trans i18nKey="companyOverview.create" />
              </PrimaryButton>
            </div>
          </div>
        </SubHeader>
        <div className={s.companies}>
          {!hasCompanies && <NoCompanies />}
          <InvitesCard />
          {companies?.length && (
            <>
              {companies?.map((company) => (
                <CompanyCard key={company.id} company={company} />
              ))}
            </>
          )}
        </div>
      </div>
      {isRequestModal && (
        <Modal
          title={t("companyOverview.requestAccess.title")}
          onClose={() => setRequestModal(false)}
        >
          <div className={s.requestAccess}>
            <Text>
              <Trans i18nKey="companyOverview.requestAccess.body" />
            </Text>
            <PrimaryButton onClick={() => setRequestModal(false)}>
              <Trans i18nKey="companyOverview.requestAccess.close" />
            </PrimaryButton>
          </div>
        </Modal>
      )}
    </>
  );
};
