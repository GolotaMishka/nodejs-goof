import "@panenco/ui/lib/styles.css";
import "react-toastify/dist/ReactToastify.css";
import "./styles/global.scss";

import "core-js/stable";
import "regenerator-runtime/runtime";

import React, { Suspense, useEffect } from "react";
import { render } from "react-dom";
import WizardProvider from "app/utils/providers/wizard";
import { Router } from "react-router-dom";
import { appTheme, injectIcons, ThemeProvider } from "ui";
import { QueryClient, QueryClientProvider } from "react-query";
import GoogleTagManager from "react-gtm-module";
import StepFooterProvider from "./utils/providers/step-footer";
import TourProvider from "./utils/providers/tour";
import svgSprite from "!file-loader!@panenco/ui/lib/spritesheet.svg";
import FroomleRecopo from "./containers";
import history from "./history";
import NotificationProvider from "./utils/providers/notification";
import "./i18n";
import PageLoader from "./components/core/loader";

injectIcons(svgSprite);

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
    },
  },
});

const App = () => {
  useEffect(() => {
    if (process.env.NODE_ENV === "production") {
      GoogleTagManager.initialize({ gtmId: process.env.GOOGLE_TAG_MANAGER_ID });
    }
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <Router history={history}>
        <WizardProvider>
          <Suspense fallback={PageLoader}>
            <ThemeProvider theme={appTheme}>
              <TourProvider>
                <StepFooterProvider>
                  <FroomleRecopo />
                </StepFooterProvider>
              </TourProvider>
            </ThemeProvider>
          </Suspense>
        </WizardProvider>
        <NotificationProvider />
      </Router>
    </QueryClientProvider>
  );
};

render(<App />, document.getElementById("root"));
