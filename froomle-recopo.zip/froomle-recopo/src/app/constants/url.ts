import { CreationStep } from "data";

type StringOrNum = string | number;

export const basePath = "/";

const applyBasePathTo = (url: StringOrNum): string => `${basePath}${url}`;

export const companiesPath = applyBasePathTo("companies");

export const companyPath = (companyId: string): string =>
  `${companiesPath}/${companyId}`;

export const portalPath = (companyId: string, envId: StringOrNum): string =>
  `${companyPath(companyId)}/environment/${envId}`;

export const homePath = (companyId: string, envId: StringOrNum): string =>
  `${portalPath(companyId, envId)}/home`;

export const personasPath = (companyId: string, envId: StringOrNum): string =>
  `${portalPath(companyId, envId)}/personas`;

export const templatesPath = (companyId: string, envId: StringOrNum): string =>
  `${portalPath(companyId, envId)}/templates`;

export const recommendationsPath = (
  companyId: string,
  envId: StringOrNum,
  templateId: StringOrNum
): string => `${templatesPath(companyId, envId)}/${templateId}/recommendations`;

export const insightsPath = (companyId: string, envId: StringOrNum): string =>
  `${portalPath(companyId, envId)}/insights`;

export const settingsPath = (companyId: string, envId: StringOrNum): string =>
  `${portalPath(companyId, envId)}/settings`;

export const companyCreation = `${companiesPath}/create`;

export const companyWizardPath = (
  companyId: string,
  step: CreationStep | ":step" | null
): string => `${companyPath(companyId)}/onboarding/${step}`;

// public

export const signInPath = applyBasePathTo("sign-in");

export const signUpPath = applyBasePathTo("sign-up");

export const signInInvitationPath = (invitationToken: string): string =>
  `${signInPath}/${invitationToken}`;

export const forgotPasswordPath = applyBasePathTo("forgot-password");
export const completeSignUpPath = applyBasePathTo("complete-sign-up");

export const protect = applyBasePathTo("protect");
