import { PUIColors, PUIModeColors, PUISizes, PUIWeights } from "@panenco/ui";
import colors from "ui/styles/_colors.scss";
import weights from "ui/styles/_weights.scss";

type AppThemeType = {
  colors: PUIColors & {
    darkMode?: PUIModeColors;
    lightMode?: PUIModeColors;
  };
  typography: {
    sizes: PUISizes;
    weights: PUIWeights;
  };
};

const sizes: PUISizes = {
  xs: {
    textSize: "12px",
    lineHeight: "130%",
  },
  s: {
    textSize: "14px",
    lineHeight: "130%",
  },
  m: {
    textSize: "16px",
    lineHeight: "150%",
  },
  l: {
    textSize: "20px",
    lineHeight: "140%",
  },
  xl: {
    textSize: "20px",
    lineHeight: "140%",
  },
  h1: {
    textSize: "20px",
    lineHeight: "140%",
  },
  h2: {
    textSize: "20px",
    lineHeight: "140%",
  },
  h3: {
    textSize: "20px",
    lineHeight: "140%",
  },
};

const appTheme: AppThemeType = {
  colors: {
    ...colors,
    darkMode: colors,
    lightMode: colors,
  },
  typography: { sizes, weights },
};

export default appTheme;

export { AppThemeType, sizes, colors, weights };
