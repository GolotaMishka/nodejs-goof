import { toast } from "@panenco/ui";
import React, { ReactElement, useState } from "react";
import { ButtonIcon, Icon, Text } from "ui";
import { Button } from "../button";
import s from "./styles.scss";

interface IProps {
  value?: string;
  label: string;
  hasObfuscation?: boolean;
}

const CopyField = ({ value, label, hasObfuscation }: IProps): ReactElement => {
  const [isHidden, setHidden] = useState(hasObfuscation);
  return (
    <div className={s.copyField}>
      <div className={s.copyFieldHeader}>
        <Text color="primary" size="m" weight="bold">
          {label}
        </Text>
        {hasObfuscation && (
          <Button
            variant="transparent"
            className={s.copyFieldReveal}
            onClick={() => setHidden(!isHidden)}
          >
            <Text size="s">{isHidden ? "Reveal" : "Hide"} secret</Text>
          </Button>
        )}
      </div>
      <div className={s.copyFieldBox}>
        <span className={s.copyFieldBoxValue}>
          {isHidden ? [...Array(value?.length)].map(() => "*").join("") : value}
        </span>
        <ButtonIcon
          iconLeft
          icon={Icon.icons.copy}
          className={s.cardHeaderButton}
          onClick={() => {
            if (value && navigator?.clipboard) {
              navigator.clipboard.writeText(value);
              (toast as any).success("Successfully copied to clipboard!");
            }
          }}
        />
      </div>
    </div>
  );
};

export default CopyField;
