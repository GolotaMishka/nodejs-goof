import { StampProps, Text } from "@panenco/ui";
import React from "react";
import cx from "classnames";
import s from "./styles.scss";

const Stamp: React.FC<StampProps> = ({
  children,
  color,
  className,
  ...props
}) => {
  return (
    <div className={cx(s.stamp, s[`stamp--${color}`], className)} {...props}>
      <Text color="light" size="xs" weight="bold">
        {children}
      </Text>
    </div>
  );
};

export default Stamp;
