import React, { ReactElement } from "react";
import cx from "classnames";
import { Icon } from "../icon";
import s from "./styles.scss";

type MessageType = "success" | "error";

interface IProps {
  message: string;
  type?: MessageType;
}

const ErrorMessage = ({ message, type = "error" }: IProps): ReactElement => {
  return (
    <div className={s.toast}>
      <Icon
        icon={Icon.icons[type]}
        className={cx(s.toastIcon, s[`toastIcon_${type}`])}
      />
      <div className={s.toastMessage}>{message}</div>
    </div>
  );
};

export default ErrorMessage;
