import React, { ReactElement } from "react";
import { Chip as PUIChip, ChipProps } from "@panenco/ui";
import cx from "classnames";
import { Icon } from "../icon";
import s from "./styles.scss";

export const Chip = ({
  className,
  checked,
  ...props
}: ChipProps): ReactElement => (
  <PUIChip
    icon={Icon.icons.delete}
    uncheckedIcon={Icon.icons.plus}
    className={cx(s.chip, !checked && s.chip_unchecked, className)}
    checked={checked}
    {...props}
  />
);
