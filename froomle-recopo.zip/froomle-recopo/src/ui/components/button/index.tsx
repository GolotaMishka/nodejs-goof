import React, { ReactElement } from "react";
import cx from "classnames";
import {
  SecondaryButton as PUISecondary,
  PrimaryButton as PUIPrimary,
  ButtonProps,
  Button as PUIButton,
} from "@panenco/ui";
import s from "./styles.scss";

export const PrimaryButton = ({
  className,
  children,
  ...props
}: ButtonProps): ReactElement => (
  <PUIPrimary className={cx(s.root, className)} {...props}>
    {children}
  </PUIPrimary>
);

export const SecondaryButton = ({
  className,
  children,
  ...props
}: ButtonProps): ReactElement => (
  <PUISecondary className={cx(s.root, s.secondary, className)} {...props}>
    {children}
  </PUISecondary>
);

export const Button = ({
  className,
  children,
  ...props
}: ButtonProps): ReactElement => (
  <PUIButton className={cx(s.root, className)} {...props}>
    {children}
  </PUIButton>
);
