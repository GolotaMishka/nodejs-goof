import React, { ReactElement } from "react";
import cx from "classnames";
import { Text } from "ui";
import s from "./styles.scss";

interface IProps {
  children: React.ReactNode;
  className?: string;
}

const BoxHeader = ({ children, className }: IProps): ReactElement => {
  const content =
    typeof children === "string" ? (
      <Text color="light" weight="bold">
        {children}
      </Text>
    ) : (
      children
    );

  return <div className={cx(s.root, className)}>{content}</div>;
};

export default BoxHeader;
