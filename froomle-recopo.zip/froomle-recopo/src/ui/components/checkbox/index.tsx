import { Checkbox as PUICheckbox, CheckboxProps } from "@panenco/ui";
import React from "react";
import cx from "classnames";
import s from "./styles.scss";

const Checkbox: React.FC<CheckboxProps> = ({
  wrapperProps,
  className,
  ...props
}) => {
  return (
    <PUICheckbox
      wrapperProps={{
        ...wrapperProps,
        className: cx(s.root, wrapperProps?.className),
      }}
      className={cx(s.checkbox, className)}
      {...props}
    />
  );
};

export default Checkbox;
