import { Icon } from "@panenco/ui";

import bookmark from "./icons/bookmark.svg";
import brackets from "./icons/brackets.svg";
import check from "./icons/check.svg";
import chevronsRight from "./icons/chevrons-right.svg";
import close from "./icons/close.svg";
import code from "./icons/code.svg";
import copy from "./icons/copy.svg";
import editPen from "./icons/edit.svg";
import emptyBox from "./icons/empty-box.svg";
import error from "./icons/error.svg";
import exclude from "./icons/exclude.svg";
import froomle from "./icons/froomle.svg";
import home from "./icons/home.svg";
import logout from "./icons/logout.svg";
import mail from "./icons/mail.svg";
import map from "./icons/map.svg";
import menuClosed from "./icons/menu-closed.svg";
import menuOpened from "./icons/menu-opened.svg";
import move from "./icons/move.svg";
import noCompanies from "./icons/no-companies.svg";
import open from "./icons/open.svg";
import personaCardSkeleton from "./icons/persona-card-skeleton.svg";
import personaProfileSkeleton from "./icons/persona-profile-skeleton.svg";
import plus from "./icons/plus-circle.svg";
import refresh from "./icons/refresh.svg";
import repeat from "./icons/repeat.svg";
import settings from "./icons/settings.svg";
import sliderItemSkeleton from "./icons/slider-item-skeleton.svg";
import sort from "./icons/sort.svg";
import success from "./icons/success.svg";
import templateSkeleton from "./icons/template-skeleton.svg";
import thumbsUp from "./icons/thumbs-up.svg";
import trendingUp from "./icons/trending-up.svg";
import users from "./icons/users.svg";

Icon.icons = {
  ...Icon.icons,
  bookmark,
  brackets,
  check,
  chevronsRight,
  close,
  code,
  copy,
  editPen,
  emptyBox,
  error,
  exclude,
  froomle,
  home,
  logout,
  mail,
  map,
  menuClosed,
  menuOpened,
  move,
  noCompanies,
  open,
  personaCardSkeleton,
  personaProfileSkeleton,
  plus,
  refresh,
  repeat,
  settings,
  sliderItemSkeleton,
  sort,
  success,
  templateSkeleton,
  thumbsUp,
  trendingUp,
  users,
};

export { Icon };
