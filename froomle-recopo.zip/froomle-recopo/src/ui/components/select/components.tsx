import React, { ReactElement } from "react";
import { components } from "react-select";
import { Icon } from "../icon";
import Avatar from "../avatar";
import s from "./styles.scss";

export const Option = (props: any): ReactElement => {
  const { children, isSelected, data: option } = props;

  return (
    <components.Option className={s.option} {...props}>
      {isSelected && <Icon icon={Icon.icons.check} className="icon" />}
      {option?.images?.[0] && (
        <Avatar className={s.optionImage} img={option.images[0]} />
      )}
      {children}
    </components.Option>
  );
};

export const ValueContainer = ({
  children,
  selectProps,
  ...props
}: any): ReactElement => {
  const image = selectProps?.value?.images?.[0];
  return (
    <components.ValueContainer {...props}>
      {image && <Avatar className={s.optionImage} img={image} />}
      {children}
    </components.ValueContainer>
  );
};

export const SingleValue = ({ children, ...props }: any): ReactElement => {
  return (
    <components.SingleValue className={s.singleValue} {...props}>
      {children}
    </components.SingleValue>
  );
};
