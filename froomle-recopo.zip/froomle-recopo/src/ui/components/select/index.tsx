import React, { ReactElement } from "react";
import { SelectInput as PUISelect, SelectInputProps } from "@panenco/ui";
import cx from "classnames";

import { Option, ValueContainer, SingleValue } from "./components";
import s from "./styles.scss";

interface IProps extends SelectInputProps {
  withImage?: boolean;
  usePortal?: boolean;
}

const portalTarget = document.getElementById("menu-root") as HTMLElement;

const SelectInput = ({
  withImage,
  usePortal = true,
  styles,
  className,
  ...props
}: IProps): ReactElement => {
  return (
    <PUISelect
      components={
        withImage ? { Option, ValueContainer, SingleValue } : undefined
      }
      openMenuOnFocus
      menuPortalTarget={usePortal ? portalTarget : undefined}
      styles={{ menuPortal: (base) => ({ ...base, zIndex: 1000 }), ...styles }}
      className={cx(s.root, className)}
      {...props}
    />
  );
};

export default SelectInput;
export { IProps as SelectInputProps };
