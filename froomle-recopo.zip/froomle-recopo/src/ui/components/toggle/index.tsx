import React from "react";
import cx from "classnames";
import { Switch, SwitchProps } from "@panenco/ui";
import s from "./styles.scss";

const Toggle: React.FC<SwitchProps> = ({ className, ...props }) => {
  return <Switch className={cx(className, s.root)} {...props} />;
};

export default Toggle;
