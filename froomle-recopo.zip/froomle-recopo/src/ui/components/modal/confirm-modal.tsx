import React, { ReactElement } from "react";
import { Button, PrimaryButton } from "ui";
import cx from "classnames";
import { Modal, ModalProps } from "./index";
import s from "./styles.scss";

export interface ConfirmModalProps extends ModalProps {
  cancelText?: string;
  submitText?: string;
  onSubmit: () => void;
  submitting?: boolean;
}

export const ConfirmModal = ({
  className,
  onClose,
  cancelText = "Cancel",
  submitText = "Submit",
  children,
  onSubmit,
  submitting,
  ...rest
}: ConfirmModalProps): ReactElement => {
  return (
    <Modal
      className={cx(s.modal, s.confirm, className)}
      onClose={onClose}
      {...rest}
    >
      <div className={s.confirmContent}>{children}</div>
      <div className={s.confirmFooter}>
        <Button variant="transparent" onClick={onClose}>
          {cancelText}
        </Button>
        <PrimaryButton
          isLoading={submitting}
          onClick={onSubmit}
          data-cy="confirm-modal"
        >
          {submitText}
        </PrimaryButton>
      </div>
    </Modal>
  );
};
