import React, { ReactElement, useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { BoxHeader } from "ui";
import { useInsideClick, useDisableBodyScroll } from "app/utils/hooks";
import cx from "classnames";
import s from "./styles.scss";

export interface ModalProps {
  className?: string;
  title?: string | ReactElement;
  onClose: () => void;
  onOpen?: () => void;
  children: React.ReactNode;
}

const modalRoot = document.getElementById("modal-root") as HTMLElement;

export const Modal = ({
  className,
  title,
  onClose,
  children,
  onOpen,
}: ModalProps): ReactElement => {
  const overlayRef = useRef(null);

  useInsideClick(overlayRef, onClose);

  useDisableBodyScroll();

  useEffect(() => {
    if (onOpen) onOpen();
  }, []);

  return createPortal(
    <div ref={overlayRef} className={s.overlay}>
      <div className={cx(s.modal, className)}>
        <BoxHeader>{title}</BoxHeader>
        <div className={s.modalContent}>{children}</div>
      </div>
    </div>,
    modalRoot
  );
};

export { ConfirmModal } from "./confirm-modal";
