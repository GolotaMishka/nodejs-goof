import React, { ReactElement, HTMLProps } from "react";
import { Text } from "@panenco/ui";
import cx from "classnames";
import s from "./styles.scss";

type AvatarSize = "small" | "medium" | "big" | "huge";

interface IProps extends HTMLProps<HTMLDivElement> {
  type?: AvatarSize;
  img?: string | null;
  className?: string;
  text?: string;
}

const Avatar = ({
  type = "small",
  img,
  className,
  text,
  ...props
}: IProps): ReactElement => {
  return (
    <div
      className={cx(
        s.avatar,
        s[`avatar_${type}`],
        !img && s.avatar_empty,
        className
      )}
      style={img ? { backgroundImage: `url(${img})` } : undefined}
      {...props}
    >
      {!text &&
        (img ? null : (
          <Text size="xs" color="secondary">
            Profile avatar
          </Text>
        ))}
      {text && (
        <Text size="s" color="secondary">
          {text.substring(0, 2).toUpperCase()}
        </Text>
      )}
    </div>
  );
};

export default Avatar;
