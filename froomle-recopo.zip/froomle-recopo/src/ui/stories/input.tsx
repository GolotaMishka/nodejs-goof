import React from "react";
import { Meta, Story } from "@storybook/react/types-6-0";
import { TextInput, TextInputProps, Row, Col, Icon } from "ui";

const Template: Story<TextInputProps> = (args) => (
  <div style={{ marginBottom: "100px" }}>
    <Row>
      <Col lg="3" sm="4" xs="4">
        <TextInput {...args} />
      </Col>
    </Row>
  </div>
);

export const InputStory = Template.bind({});

InputStory.args = {
  disabled: false,
  placeholder: "Placeholder",
  title: "Title",
  subTitle: "Subtitle",
  iconAfter: Icon.icons.chevronDown,
};

export default {
  title: "Input",
  component: TextInput,
} as Meta;
