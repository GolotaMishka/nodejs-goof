import React from "react";
import { Meta, Story } from "@storybook/react/types-6-0";
import { Checkbox } from "ui";

const List = () => {
  const [checked1, setChecked1] = React.useState(false);
  const [checked2, setChecked2] = React.useState(false);

  return (
    <div>
      <div style={{ display: "flex", margin: "20px 20px 0 0" }}>
        <Checkbox
          checked={checked1}
          onChange={() => setChecked1((state) => !state)}
          label="Checkbox"
        />
      </div>
      <div style={{ display: "flex", margin: "20px 20px 0 0" }}>
        <Checkbox
          error="Error"
          checked={checked2}
          onChange={() => setChecked2((state) => !state)}
          label="Checkbox with error"
        />
      </div>
      <div style={{ display: "flex", margin: "20px 20px 0 0" }}>
        <Checkbox disabled checked={false} label="Checkbox" />
      </div>
    </div>
  );
};

const Template: Story = (args) => <List {...args} />;

export const CheckboxList = Template.bind({});

export default {
  title: "Checkbox",
  component: Checkbox,
} as Meta;
