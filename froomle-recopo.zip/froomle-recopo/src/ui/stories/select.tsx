import React from "react";
import { Meta, Story } from "@storybook/react/types-6-0";
import { SelectInput, SelectInputProps, Row, Col } from "ui";

const options = [
  { label: "Google", value: "1" },
  { label: "Facebook", value: "2" },
];

const Template: Story<SelectInputProps> = (args) => (
  <div style={{ marginBottom: "100px" }}>
    <Row>
      <Col lg="3" sm="4" xs="4">
        <SelectInput {...args} />
      </Col>
    </Row>
  </div>
);

export const SelectStory = Template.bind({});

SelectStory.args = {
  isDisabled: false,
  options,
  title: "Environment",
  placeholder: "Select environment",
};

export default {
  title: "Select",
  component: SelectInput,
} as Meta;
