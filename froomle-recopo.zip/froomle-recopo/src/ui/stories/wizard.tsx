import React from "react";
import { Meta, Story } from "@storybook/react/types-6-0";
import { WizardTrack, WizardTrackProps } from "ui";

const WizardTemplate: Story<WizardTrackProps> = (args) => (
  <WizardTrack {...args} />
);

const steps = [
  {
    title: "Manage personal",
    stepIndex: 0,
  },
  {
    title: "Page Template",
    stepIndex: 1,
  },
  {
    title: "Recommendations",
    stepIndex: 2,
  },
];

export const WizardFormTracker = WizardTemplate.bind({});

WizardFormTracker.args = {
  stepsMeta: steps,
};

export default {
  title: "Wizard tracker",
  component: WizardTrack,
} as Meta;
