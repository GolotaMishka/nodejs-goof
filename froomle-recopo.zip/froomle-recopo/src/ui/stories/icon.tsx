import React, { ReactElement } from "react";
import { Meta, Story } from "@storybook/react/types-6-0";

import { Icon, IconProps } from "ui";

const IconTemplate: Story<IconProps> = (args) => <Icon {...args} />;

const IconStory = IconTemplate.bind({});

IconStory.args = {
  color: "#000",
};

export const IconsStory = (): ReactElement => (
  <div style={{ display: "flex", flexWrap: "wrap" }}>
    {Object.entries(Icon.icons).map(([key, icon]: [string, any]) => (
      <div
        key={icon.id}
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          marginRight: 8,
        }}
      >
        <IconStory icon={icon} size={16} />
        {key}
      </div>
    ))}
  </div>
);
export default {
  title: "Icon",
  component: Icon,
} as Meta;
