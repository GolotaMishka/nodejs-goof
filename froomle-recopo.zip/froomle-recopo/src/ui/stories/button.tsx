import React from "react";
import { Meta, Story } from "@storybook/react/types-6-0";
import {
  PrimaryButton,
  Button,
  ButtonIcon,
  ButtonIconProps,
  ButtonProps,
  Icon,
} from "ui";

const PrimaryTemplate: Story<ButtonProps> = (args) => (
  <PrimaryButton {...args}>Next</PrimaryButton>
);

const SecondaryTemplate: Story<ButtonProps> = (args) => (
  <>
    <Button {...args}>Prev</Button>
    <Button {...args} iconLeft={Icon.icons.filledPlus} variant="transparent">
      Add persona
    </Button>
  </>
);

const ButtonIconTemplate: Story<ButtonIconProps> = (args) => (
  <ButtonIcon {...args}>Clone</ButtonIcon>
);

export const Primary = PrimaryTemplate.bind({});

Primary.args = {
  disabled: false,
  iconLeft: Icon.icons.chevronLeft,
};

export const Secondary = SecondaryTemplate.bind({});

Secondary.args = {
  disabled: false,
  iconLeft: Icon.icons.chevronLeft,
  variant: "transparent",
};

export const IconButton = ButtonIconTemplate.bind({});

IconButton.args = {
  iconLeft: true,
  icon: Icon.icons.copy,
};

export default {
  title: "Button",
  component: Button,
  argTypes: {
    color: { control: "color" },
  },
} as Meta;
