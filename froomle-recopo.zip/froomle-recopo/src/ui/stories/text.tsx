import React, { ReactElement } from "react";
import { Col, PUIColors, Row, Text } from "@panenco/ui";
import { Meta } from "@storybook/react/types-6-0";
import { idGenerator } from "app/utils";
import { colors, sizes } from "ui";

const getRandomColor = (): string => {
  const arr: string[] = Object.values(colors as PUIColors).filter(
    (item: string) => !item.toLowerCase().includes("mode")
  );

  return arr[Math.floor(Math.random() * arr.length)];
};

export const TextsStory = (): ReactElement => {
  return (
    <Row style={{ display: "flex", flexDirection: "row" }}>
      <Col style={{ display: "flex", flexDirection: "column" }}>
        {Object.keys(colors)
          .filter((item) => !item.includes("Mode"))
          .map((color: string) => (
            <Text component="span" key={idGenerator()} color={colors[color]}>
              {color}
            </Text>
          ))}
      </Col>
      <Col style={{ display: "flex", flexDirection: "column" }}>
        {Object.values(sizes).map(
          (val, i) =>
            i < 4 && (
              <Text component="span" size={val} color={getRandomColor()}>
                Font-size: {val.textSize}, line-height: {val.lineHeight}
              </Text>
            )
        )}
      </Col>
    </Row>
  );
};

export default {
  title: "Text",
  component: Text,
} as Meta;
