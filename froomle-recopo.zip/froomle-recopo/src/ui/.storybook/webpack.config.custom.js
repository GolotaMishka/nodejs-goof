const webpack = require("webpack");
const path = require("path");
const paths = require("../../../config/paths");

const babelLoader = {
  loader: "babel-loader",
  options: {
    rootMode: "upward",
  },
};

module.exports = {
  resolve: {
    extensions: [".js", ".ts", ".tsx"],
    modules: ["node_modules"],
    alias: {
      static: paths.publicFiles,
      public: paths.publicFiles,
      ui: paths.ui,
      app: paths.app,
    },
  },
  module: {
    rules: [
      {
        test: /\.scss$/,
        sideEffects: true,
        use: [
          "style-loader",
          {
            loader: "css-loader",
            options: {
              modules: {
                mode: "local",
                localIdentName: "[local]-[hash:base64:5]",
              },
            },
          },
          {
            loader: "sass-loader",
            options: {
              sassOptions: {
                includePaths: [path.join(paths.ui, "styles")],
              },
            },
          },
        ],
      },
      {
        test: /\.svg$/,
        loader: "svg-sprite-loader",
      },
      {
        include: [paths.publicFiles],
        loader: "file-loader",
      },
    ],
  },
  plugins: [new webpack.HotModuleReplacementPlugin()],
};
