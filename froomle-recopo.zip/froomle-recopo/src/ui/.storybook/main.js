const customWP = require("./webpack.config.custom.js");

module.exports = {
  stories: ["../stories/**/*.@(tsx)"],
  addons: [
    "@storybook/addon-essentials",
    "@storybook/addon-controls",
    "@storybook/addon-knobs/register",
  ],
  webpackFinal: (config) => {
    return {
      ...config,
      resolve: {
        ...config.resolve,
        ...customWP.resolve,
      },
      module: {
        ...config.module,
        rules: [
          ...config.module.rules.map((rule) => {
            if (
              String(rule.test) ===
              String(
                /\.(svg|ico|jpg|jpeg|png|apng|gif|eot|otf|webp|ttf|woff|woff2|cur|ani|pdf)(\?.*)?$/
              )
            ) {
              return {
                ...rule,
                test: /\.(ico|jpg|jpeg|png|apng|gif|eot|otf|webp|ttf|woff|woff2|cur|ani|pdf)(\?.*)?$/,
              };
            }
            return rule;
          }),
          ...customWP.module.rules,
        ],
      },
    };
  },
};
