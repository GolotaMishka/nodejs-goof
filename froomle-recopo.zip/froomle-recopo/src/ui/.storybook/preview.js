import "app/styles/global.scss";
import "@panenco/ui/lib/styles.css";
import React from "react";
import { themes } from "@storybook/theming";
import { ThemeProvider, injectIcons } from "@panenco/ui";
import svgSprite from "!file-loader!@panenco/ui/lib/spritesheet.svg";
import theme from "../utils/theme";

injectIcons(svgSprite);

export const decorators = [
  (Story) => (
    <ThemeProvider theme={theme}>
      <Story />
    </ThemeProvider>
  ),
];

export const parameters = {
  controls: { expanded: true },
  docs: {
    theme: themes.dark,
  },
};
