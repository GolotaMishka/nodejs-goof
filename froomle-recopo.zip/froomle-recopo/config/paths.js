// eslint-disable-next-line @typescript-eslint/no-var-requires
const path = require("path");

const paths = {};

paths.root = path.resolve(__dirname, "..");
paths.nodeModules = path.join(paths.root, "node_modules");
paths.src = path.join(paths.root, "src");
paths.app = path.join(paths.src, "app");
paths.ui = path.join(paths.src, "ui");
paths.data = path.join(paths.src, "data");
paths.outputPath = path.join(paths.root, "dist");
paths.entryPoint = path.join(paths.app, "index.tsx");
paths.scss = path.join(paths.ui, "styles");
paths.publicFiles = path.join(paths.root, "public");
paths.storybook = path.join(paths.ui, "stories");
paths.env = path.join(
  paths.root,
  `.env.${process.env.PROJECT_ENV || "development"}`
);
module.exports = paths;
