/* eslint-disable global-require */
module.exports = {
  // eslint-disable-next-line import/no-extraneous-dependencies
  plugins: [require("autoprefixer")],
};
