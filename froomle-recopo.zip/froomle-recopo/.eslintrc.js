// eslint-disable-next-line @typescript-eslint/no-var-requires
const path = require("path");

module.exports = {
  root: true,
  extends: [
    "airbnb",
    "eslint:recommended",
    "plugin:import/recommended",
    "plugin:react/recommended",
    "plugin:@typescript-eslint/eslint-recommended",
    "plugin:@typescript-eslint/recommended",
    "plugin:react-hooks/recommended",
    "prettier",
    "prettier/react",
    "prettier/@typescript-eslint",
    "plugin:cypress/recommended",
  ],
  parser: "@typescript-eslint/parser",
  env: {
    browser: true,
    es6: true,
  },
  plugins: [
    "react",
    "prettier",
    "@typescript-eslint",
    "react-hooks",
    "cypress",
  ],
  rules: {
    "prettier/prettier": "error",
    "import/prefer-default-export": 0,
    "react/prop-types": 0,
    "react/jsx-props-no-spreading": 0,
    "react/jsx-filename-extension": [1, { extensions: [".tsx", ".ts"] }],
    "react/button-has-type": 0,
    "import/extensions": "off",
    "react/require-default-props": 0,
    "import/no-webpack-loader-syntax": 0,
    "react/jsx-curly-brace-presence": [1, { children: "ignore" }],
    "import/no-extraneous-dependencies": ["error", { devDependencies: true }],
    "@typescript-eslint/no-unused-vars": "error",
    "react-hooks/exhaustive-deps": 0,
    "@typescript-eslint/no-non-null-assertion": 0,
    // note you must disable the base rule as it can report incorrect errors
    "no-shadow": "off",
    "@typescript-eslint/no-shadow": ["error"],
    "no-param-reassign": [
      "error",
      { props: true, ignorePropertyModificationsForRegex: ["^draft"] },
    ],
    "@typescript-eslint/no-explicit-any": 0,
  },
  settings: {
    "import/resolver": {
      node: {},
      typescript: {},
      webpack: {
        config: path.resolve(
          __dirname,
          "./config/webpack.config.development.js"
        ),
      },
    },
  },
};
